#!/bin/bash
#! php
#
# This script generates two sets of zip files which can be used to deploy the API spec in various
# platforms. Specifically:
#
# The API spec is generated in target/api-spec and contains RAML which has been stripped of microservices-level traits.
# This spec is suitable for publishing in the ANypoint Portal for use by API consumers.
#
# The GW spec is generated in target/gw-spec and contains RAML which excludes microservices traits and removes schema validation.
# This spec is suitable for deploying into Anypoint studio for generating API Gateway flows.
#
# Requires zip to be installed.

# List of packages to process
declare -a pkgs=("claims" "policies" "reference" "users" "members" "sessions" "payments" "products" "tokens" "events")

# List of additional schemas to include
declare -a incl=("members" "products" "payments")

# List of targets to generate
declare -a targets=("api" "gw")

# List of RAML resources to merge
declare -a resources=("schemas:" "resourceTypes:" "securitySchemes:" "traits:" "securedBy:")

src=`pwd`/src/main/resources/raml

mergeddirname="medibank"
mergedraml="medibank.raml"
stagedraml="$mergedraml.staged"
ramlheader=$'#%RAML 0.8\nbaseUri: http://medibank.com.au/api/{version}\ntitle: Medibank API\nversion: v1\nmediaType: application/json\n'

for  tgt in "${targets[@]}"
do
	tgtdir=`pwd`/target/$tgt-spec

	mkdir -p $tgtdir
	for i in "${pkgs[@]}"
	do
		echo "processing $i"
		cp -r $src/$i $tgtdir
	
		# Copy general files
		cp -r $src/general $tgtdir/$i/general

		if [ $tgt = "api" ]
		then
		    mkdir -p $tgtdir/$mergeddirname
		    cp -r $src/general $tgtdir/$mergeddirname/general
			mkdir -p $tgtdir/$mergeddirname/schema
		    cp -r $src/$i/schema/* $tgtdir/$mergeddirname/schema
		    mkdir -p $tgtdir/$mergeddirname/examples
		    cp -r $src/$i/examples/* $tgtdir/$mergeddirname/examples
		fi
	
		# Copy included schemas
		for j in "${incl[@]}"
		do
			mkdir -p $tgtdir/$i/$j/schema
			cp -r $src/$j/schema/* $tgtdir/$i/$j/schema

			if [ $tgt = "api" ]
			then
			   mkdir -p $tgtdir/$mergeddirname/$j/schema
			   cp -r $src/$j/schema/* $tgtdir/$mergeddirname/$j/schema
			fi
		done

		# if an include is same as current, then remove the include
		rm -rf $tgtdir/$i/$i  
	
		# Fix up includes and remove trackable trait
		sed -f ramlfix_$tgt $tgtdir/$i/$i.raml > $tgtdir/$i/out.raml
		mv $tgtdir/$i/out.raml $tgtdir/$i/$i.raml

		if [ $tgt = "api" ]
		then
			cp $tgtdir/$i/$i.raml $tgtdir/$mergeddirname/$i.raml
		fi
        
        if [ $tgt = "gw" ]
		then
		     if [ $i = "users" ]
		     then
		        sed -i -e "/\/migrationStatus:/ {
       						   h
                               r ramlfix_gw_version
                               g
                               N
                               }" $tgtdir/$i/$i.raml
	        else
             	cat ramlfix_gw_version >> $tgtdir/$i/$i.raml
             fi
        fi

		# If target is gateway then remove schemas from resourceTypes
		if [ $tgt = "gw" ]
		then
			for k in `ls $tgtdir/$i/general/resourceTypes/*.yaml`
			do
				sed -e "/schema: /d" $k > out.yaml
				mv out.yaml $k
			done
		fi
	
		# zip-it-up
		wd=`pwd`
		cd $tgtdir/$i
		zip -r ../$i.zip *
		cd ..
		rm -rf $i
		cd $wd
	done

done

#Merge the RAMLs
tgtdir=`pwd`/target/api-spec
mergeddir=$tgtdir/$mergeddirname

if [ -f $tgtdir/${mergedraml} ] ; then
    rm $tgtdir/${mergedraml}
fi

printf "%s\n" "$ramlheader" >> $mergeddir/$stagedraml

for res in "${resources[@]}"
do
	if [ $res = "securedBy:" ]
		then
		 	i=1
	    else
			i=2
	fi 
     awk '/'$res'/,/^\s*$/' $mergeddir/*.raml | awk -v K=$i '!a[$K]++' >> $mergeddir/$stagedraml
     printf "\n" >> $mergeddir/$stagedraml
done

for i in "${pkgs[@]}"
do
     awk '/\/claims:|\/members:|\/payments:|\/policies:|\/products:|\/reference:|\/sessions:|\/tokens:|\/events:|\/users:/,0' $mergeddir/$i.raml >> $mergeddir/$stagedraml
     printf "\n" >> $mergeddir/$stagedraml
done

mv $mergeddir/$stagedraml $mergeddir/$mergedraml


#Flatten out the RAML
php ramlMerge.php $mergeddir/$mergedraml > ${tgtdir}/$mergedraml
#php ramlMerge.php $(cygpath -aw ${mergeddir})/$mergedraml > $(cygpath -aw ${tgtdir})/$mergedraml  #Use this line instead if running on cygwin

rm -rf $mergeddir
