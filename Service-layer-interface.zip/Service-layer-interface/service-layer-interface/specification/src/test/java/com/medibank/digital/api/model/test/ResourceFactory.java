package com.medibank.digital.api.model.test;

import java.util.UUID;

import com.medibank.digital.api.model.Self;
import com.medibank.digital.api.model.Links;
import com.medibank.digital.api.model.Resource;

class ResourceFactory {

	protected String id;

	public ResourceFactory() {
		id = generateID();
	}

	public static String generateID() {
		String id = UUID.randomUUID().toString();
		id = id.substring(id.length()-8, id.length());
		return id;
	}

	public String getId() {
		return id;
	}

	public Links getLinks(String type) {
		String url = "/api/v1/"+type+"/"+id;
		Links links = new Links().withSelf(new Self().withHref(url));
		return links;
	}

	public Resource getResource(String type) {
		Resource r = new Resource()
				  				.withId(id)
								.withLinks(this.getLinks(type));
		return r;
	}

}
