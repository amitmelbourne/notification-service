package com.medibank.digital.api.model.test;

import com.medibank.digital.api.model.MediumEntry;
import com.medibank.digital.api.model.Phone;
import com.medibank.digital.api.model.Address;
import com.medibank.digital.api.model.Contact;
import com.medibank.digital.api.model.Medium;
import com.medibank.digital.api.model.Preferences;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

public class TestContact {

	private static String exampleRoot = "src/main/resources/raml/members/examples/";

	@Test
	public void serializeContact() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		ResourceFactory f1 = new ResourceFactory();
		SubresourceFactory f2 = new SubresourceFactory(f1);

		Contact c = new Contact();
		c.setLinks(f2.getLinks("members","contact"));
		c.setResidentialAddress(addressFactory("31 Smith St"));
		c.setMailingAddress(addressFactory("PO Box 31415"));
		c.setHomePhone(phoneFactory("03 555 1234"));
		c.setMobilePhone(phoneFactory("0410555123"));
		c.setSensitiveInformationProtection(false);
		c.setPreferences(prefsFactory());
		
		String json = null;
		try {
			json = mapper.writeValueAsString(c);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "members", "contact.json");
		assertTrue(json.length()>0);
	}


	@Test
	public void parseContact() {
		String json = ExampleFile.read(exampleRoot+"contact.json");

		try {
			Contact c = new ObjectMapper().readValue(json,Contact.class);
			assertEquals(c.getResidentialAddress().getAddressLine1(),"31 Smith St");
			assertEquals(c.getMailingAddress().getAddressLine1(),"PO Box 31415");
			assertEquals(c.getMobilePhone().getPhoneNumber(),"0410555123");
			assertEquals(c.getSensitiveInformationProtection(),false);
			
			//test marketing types
			assertEquals(c.getPreferences().getAdditionalProperties().get("marketing").getAdditionalProperties().get("phone").getPreference(),false);
			assertEquals(c.getPreferences().getAdditionalProperties().get("marketing").getAdditionalProperties().get("phone").getUpdateable(),true);
			
			assertEquals(c.getPreferences().getAdditionalProperties().get("marketing").getAdditionalProperties().get("post").getPreference(),true);
			assertEquals(c.getPreferences().getAdditionalProperties().get("marketing").getAdditionalProperties().get("post").getUpdateable(),false);
			
			assertEquals(c.getPreferences().getAdditionalProperties().get("marketing").getAdditionalProperties().get("email").getPreference(),true);
			assertEquals(c.getPreferences().getAdditionalProperties().get("marketing").getAdditionalProperties().get("email").getUpdateable(),true);

			assertEquals(c.getPreferences().getAdditionalProperties().get("marketing").getAdditionalProperties().get("sms").getPreference(),false);
			assertEquals(c.getPreferences().getAdditionalProperties().get("marketing").getAdditionalProperties().get("sms").getUpdateable(),true);
					
			//test marketing types
			assertEquals(c.getPreferences().getAdditionalProperties().get("service").getAdditionalProperties().get("phone").getPreference(),false);
			assertEquals(c.getPreferences().getAdditionalProperties().get("service").getAdditionalProperties().get("phone").getUpdateable(),true);
			
			assertEquals(c.getPreferences().getAdditionalProperties().get("service").getAdditionalProperties().get("post").getPreference(),true);
			assertEquals(c.getPreferences().getAdditionalProperties().get("service").getAdditionalProperties().get("post").getUpdateable(),false);
			
			assertEquals(c.getPreferences().getAdditionalProperties().get("service").getAdditionalProperties().get("email").getPreference(),true);
			assertEquals(c.getPreferences().getAdditionalProperties().get("service").getAdditionalProperties().get("email").getUpdateable(),true);

			assertEquals(c.getPreferences().getAdditionalProperties().get("service").getAdditionalProperties().get("sms").getPreference(),false);
			assertEquals(c.getPreferences().getAdditionalProperties().get("service").getAdditionalProperties().get("sms").getUpdateable(),true);
			
			//test publication types
			assertEquals(c.getPreferences().getAdditionalProperties().get("publication").getAdditionalProperties().get("phone").getPreference(),false);
			assertEquals(c.getPreferences().getAdditionalProperties().get("publication").getAdditionalProperties().get("phone").getUpdateable(),true);
			
			assertEquals(c.getPreferences().getAdditionalProperties().get("publication").getAdditionalProperties().get("post").getPreference(),true);
			assertEquals(c.getPreferences().getAdditionalProperties().get("publication").getAdditionalProperties().get("post").getUpdateable(),false);
			
			assertEquals(c.getPreferences().getAdditionalProperties().get("publication").getAdditionalProperties().get("email").getPreference(),true);
			assertEquals(c.getPreferences().getAdditionalProperties().get("publication").getAdditionalProperties().get("email").getUpdateable(),true);

			assertEquals(c.getPreferences().getAdditionalProperties().get("publication").getAdditionalProperties().get("sms").getPreference(),false);
			assertEquals(c.getPreferences().getAdditionalProperties().get("publication").getAdditionalProperties().get("sms").getUpdateable(),true);
						
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Phone phoneFactory(String number) {
		Phone p = new Phone().withCountryCode("AU").withPhoneNumber(number);
		return p;
	}
	public static Preferences prefsFactory() {
		
		Medium me = new Medium();
		me.setAdditionalProperty("sms", new MediumEntry().withPreference(false).withUpdateable(true));
		me.setAdditionalProperty("email", new MediumEntry().withPreference(true).withUpdateable(true));
		me.setAdditionalProperty("post", new MediumEntry().withPreference(true).withUpdateable(false));
		me.setAdditionalProperty("phone", new MediumEntry().withPreference(false).withUpdateable(true));
			
		Preferences prefs = new Preferences();
		prefs.setAdditionalProperty("service", me);
		prefs.setAdditionalProperty("marketing", me);
		prefs.setAdditionalProperty("publication", me);

		return prefs;
	}
	public static Address addressFactory(String street) {
		Address a = new Address()
				  .withPostCode("3000")
				  .withState("VIC")
				  .withTownName("Melbourne")
				  .withCountryCode("AU")
				  .withAddressLine1(street);
		return a;
	}
}
