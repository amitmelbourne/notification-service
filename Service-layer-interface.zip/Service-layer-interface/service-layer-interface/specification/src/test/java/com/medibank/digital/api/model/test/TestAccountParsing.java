package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.*;

public class TestAccountParsing {

	private static String exampleRoot = "src/main/resources/raml/members/examples/";

	@Test
	public void parsePaymentAccountCardForPayment() {
		String json = ExampleFile.read(exampleRoot+"post-creditcard-directdebit-example.json");

		try {
			PostAccountForDirectDebit post = new ObjectMapper().readValue(json,PostAccountForDirectDebit.class);
			PaymentAccount acct = post.getAccount();
			assertTrue(acct instanceof CreditCardAccount);
			CreditCardAccount cc = (CreditCardAccount) acct;

			assertEquals(cc.getCardRefID(),"fhskdjhgsdgh");
			assertEquals(cc.getCardExpiry(),"03/16");

			ResourceLink ref = post.getPolicyRef();
			assertEquals(ref.getId(),"778899");
			assertEquals(ref.getType(),"policies");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void parseBankAccountForBenefits() {
		String json = ExampleFile.read(exampleRoot+"post-account-benefits-example.json");

		try {
			PostAccountForBenefits post = new ObjectMapper().readValue(json, PostAccountForBenefits.class);
			PaymentAccount acct = post.getAccount();
			assertTrue(acct instanceof BankAccount);
			BankAccount ba = (BankAccount) acct;

			assertEquals(ba.getBsb(),"123-456");
			assertEquals(ba.getAccountNum(),"123456");
			assertEquals(ba.getAccountHolderName(),"John Smith");

			ResourceLink ref = post.getPolicyRef();
			assertEquals(ref.getId(),"778899");
			assertEquals(ref.getType(),"policies");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void parseChequeAccountForBenefits() {
		String json = ExampleFile.read(exampleRoot+"post-cheque-account-benefits-example.json");

		try {
			PostAccountForBenefits post = new ObjectMapper().readValue(json,PostAccountForBenefits.class);

			PaymentAccount acct = post.getAccount();
			assertTrue(acct instanceof ChequeAccount);
			ChequeAccount ca = (ChequeAccount) acct;

			assertEquals(ca.getPayByCheque(),Boolean.valueOf(true));

			ResourceLink ref = post.getPolicyRef();
			assertEquals(ref.getId(),"778899");
			assertEquals(ref.getType(),"policies");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void parseGetAccountsResponse() {
		String json = ExampleFile.read(exampleRoot+"accountList.json");

		try {
			AccountList accountList = new ObjectMapper().readValue(json,AccountList.class);
			List<PaymentAccount> list = accountList.getAccounts();
			assertTrue(list.size()==2);

			for (PaymentAccount acct: list) {
				if (acct instanceof BankAccount) {
					BankAccount ba = (BankAccount) acct;
					assertNotNull(ba.getBsb());
				}
				if (acct instanceof CreditCardAccount) {
					CreditCardAccount cc = (CreditCardAccount) acct;
					assertNotNull(cc.getCardToken());
				}
				if (acct instanceof PayrollAccount) {
					PayrollAccount pr = (PayrollAccount) acct;
					assertNotNull(pr.getEmployeeNumber());
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
