package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestEventsParsing {

	private static String exampleRoot = "src/main/resources/raml/events/examples/";

	@Test
	public void parseStreamEventlogRequest() throws IOException {

		String json = ExampleFile.read(exampleRoot + "eventlogRequest.json");
		assertTrue(json.length() > 0);

		Eventlog el = new ObjectMapper().readValue(json, Eventlog.class);
		assertEquals(el.getTag(),"Rate Change Viewed");
		assertEquals(el.getSource(),"OMS");
		assertEquals(el.getSourceTime(),"2014-01-01T16:56:54+11:00");
		assertEquals(el.getEntityRef(),"https://members.medibank.com.au/policies/99981");

		assertEquals(el.getContext().getAdditionalProperties().get("userId"),"c9999@medibank.com.au");
	}

	@Test
	public void parseStreamEventlogResponse() throws IOException {

		String json = ExampleFile.read(exampleRoot + "eventlogResponse.json");
		assertTrue(json.length() > 0);

		EventLogResponse elr = new ObjectMapper().readValue(json, EventLogResponse.class);
		assertEquals(elr.getId(),"069d70a8");
        assertEquals(elr.getEventRef().getLink(),"/api/v1/events/OMS/069d70a8");
	}

	@Test
	public void parseStreamEventlogList() throws IOException {

		String json = ExampleFile.read(exampleRoot + "eventlogList.json");
		assertTrue(json.length() > 0);

		EventlogList ell = new ObjectMapper().readValue(json, EventlogList.class);
        Eventlog el = ell.getEvents().get(0);

        assertEquals(el.getId(),"069d70a8");
        assertEquals(el.getType(),"events");
        assertEquals(el.getTag(),"Rate Change Viewed");
		assertEquals(el.getSource(),"OMS");
		assertEquals(el.getSourceTime(),"2016-01-02T11:56:54+11:00");
		assertEquals(el.getEntityRef(),"https://members.medibank.com.au/policies/99971");

		assertEquals(el.getContext().getAdditionalProperties().get("userId"),"c9997@medibank.com.au");
	}

	@Test
	public void parseStreamEventlogResource() throws IOException {

		String json = ExampleFile.read(exampleRoot + "eventlogResource.json");
		assertTrue(json.length() > 0);

		Eventlog el = new ObjectMapper().readValue(json, Eventlog.class);
        assertEquals(el.getId(),"069d70a8");
        assertEquals(el.getType(),"events");
        assertEquals(el.getTag(),"Rate Change Viewed");
        assertEquals(el.getSource(),"OMS");
        assertEquals(el.getSourceTime(),"2016-01-02T11:56:54+11:00");
        assertEquals(el.getEntityRef(),"https://members.medibank.com.au/policies/99971");

        assertEquals(el.getContext().getAdditionalProperties().get("userId"),"c9997@medibank.com.au");
	}

}