package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.PostUpdatePaymentFrequency;
import com.medibank.digital.api.model.ResourceLink;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertEquals;

public class TestPaymentFrequencyParsing {

	private static String exampleRoot = "src/main/resources/raml/members/examples/";

	@Test
	public void parsePaymentAccountCardForPayment() {
		String json = ExampleFile.read(exampleRoot+"post-update-payment-frequency-example.json");

		try {
			PostUpdatePaymentFrequency post = new ObjectMapper().readValue(json,PostUpdatePaymentFrequency.class);

			assertEquals(post.getPaymentFrequency(),"monthly");
			assertEquals(post.getEffectiveDate(),"2015-08-23");
			assertEquals(post.getDeductionDay(),"14");

			ResourceLink ref = post.getPolicyRef();
			assertEquals(ref.getId(),"778899");
			assertEquals(ref.getType(),"policies");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
