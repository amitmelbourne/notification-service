package com.medibank.digital.api.model.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import com.medibank.digital.api.model.*;
import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;

public class TestUserParsing {

	private static String exampleRoot = "src/main/resources/raml/users/examples/";

	@Test
	public void parseActivateRequest() throws IOException {

		String json = ExampleFile.read(exampleRoot+"activateRequest.json");
		assertTrue(json.length()>0);

		ActivateRequest ar = new ObjectMapper().readValue(json,ActivateRequest.class);
		assertEquals(ar.getTokenID(),"U3VjaCBpcyBsaWZlLg==");
	}

	@Test
	public void parseActivateResponse() throws IOException {

		String json = ExampleFile.read(exampleRoot+"activateResponse.json");
		assertTrue(json.length()>0);

		ActivateResponse ar = new ObjectMapper().readValue(json, ActivateResponse.class);
		assertEquals(ar.getTokenID(),"U3VjaCBpcyBsaWZlLg==");
		assertEquals(ar.getLinks().getNext().getHref(), "/api/v1/users/user@test.com/nextStep");
		assertEquals(ar.getLinks().getNext().getTitle(),"Next");
	}

	@Test
	public void parseCredentialsRequest() throws IOException {

		String json = ExampleFile.read(exampleRoot + "credentialsRequest.json");
		assertTrue(json.length() > 0);

		CredentialsRequest cr = new ObjectMapper().readValue(json,CredentialsRequest.class);
		assertEquals(cr.getTokenID(),"U3VjaCBpcyBsaWZlLg==");
		assertEquals(cr.getPassword(),"newPassword");
	}

	@Test
	public void parseCredentialsResponse() throws IOException {

		String json = ExampleFile.read(exampleRoot+"credentialsResponse.json");
		assertTrue(json.length()>0);

		CredentialsResponse cr = new ObjectMapper().readValue(json,CredentialsResponse.class);
		assertEquals(cr.getTokenID(),"U3VjaCBpcyBsaWZlLg==");
		assertEquals(cr.getLinks().getNext().getHref(),"/api/v1/users/user@test.com/nextStep");
		assertEquals(cr.getLinks().getNext().getTitle(),"Next");
	}

	@Test
	public void parseConfirmEmailRequest() throws IOException {

		String json = ExampleFile.read(exampleRoot + "confirmEmailRequest.json");
		assertTrue(json.length() > 0);

		ConfirmEmailRequest cer = new ObjectMapper().readValue(json,ConfirmEmailRequest.class);
		assertEquals(cer.getTokenID(),"U3VjaCBpcyBsaWZlLg==");
	}

	@Test
	public void parseVerifyTokenRequest() throws IOException {

		String json = ExampleFile.read(exampleRoot + "verifyTokenRequest.json");
		assertTrue(json.length() > 0);

		VerifyTokenRequest vtr = new ObjectMapper().readValue(json,VerifyTokenRequest.class);
		assertEquals(vtr.getTokenID(),"U3VjaCBpcyBsaWZlLg==");
	}

	@Test
	public void parseConfirmEmailResponse() throws IOException {

		String json = ExampleFile.read(exampleRoot+"confirmEmailResponse.json");
		assertTrue(json.length()>0);

		ConfirmEmailResponse cer = new ObjectMapper().readValue(json,ConfirmEmailResponse.class);
		assertEquals(cer.getLinks().getNext().getHref(),"/api/v1/users/user@test.com/nextStep");
		assertEquals(cer.getLinks().getNext().getTitle(),"Next");
	}

	@Test
	public void parseChangeUsername() throws IOException {

		String json = ExampleFile.read(exampleRoot + "changeUsernameRequest.json");
		assertTrue(json.length() > 0);

		ChangeUsernameRequest cu = new ObjectMapper().readValue(json,ChangeUsernameRequest.class);
		assertEquals(cu.getNewUsername(),"newUser@test.com");
	}

	@Test
	public void parseGetUserResponse() throws IOException {
		String json = ExampleFile.read(exampleRoot+"getUsernameResponse.json");
		assertTrue(json.length()>0);

		GetUsernameResponse user = new ObjectMapper().readValue(json,GetUsernameResponse.class);
		assertEquals(user.getUsername(),"testy_tester@medibank.com.au");
		assertEquals(user.getErrorCode(),"0");
	}

	@Test
	public void parseRegisterUserRequest() throws IOException {
		String json = ExampleFile.read(exampleRoot+"registerUserRequest.json");
		assertTrue(json.length()>0);

		RegisterUserRequest ur = new ObjectMapper().readValue(json,RegisterUserRequest.class);
		assertEquals(ur.getDob(),"2015-06-07");
		assertEquals(ur.getEmail(),"testy_tester@medibank.com.au");
		assertEquals(ur.getFirstName(),"Sam");
		assertEquals(ur.getLastName(),"Customer");
		assertEquals(ur.getPolicyNum(), "POL123");
		assertEquals(ur.getPassword(),"ssshhhhh");
		assertEquals(ur.getEmailOverride(),true);
	}

	@Test
	public void parseRecoverPasswordRequest() throws IOException {
		String json = ExampleFile.read(exampleRoot+"requestPasswordRecovery.json");
		assertTrue(json.length() > 0);

		PasswordRecovery pr = new ObjectMapper().readValue(json,PasswordRecovery.class);
		assertEquals(pr.getUsername(),"testy_tester@medibank.com.au");
	}

	@Test
	public void parseChangePasswordRequest() throws IOException {
		String json = ExampleFile.read(exampleRoot+"requestPasswordChange.json");
		assertTrue(json.length()>0);

		PasswordChange pchange = new ObjectMapper().readValue(json,PasswordChange.class);
		assertEquals(pchange.getOldPassword(),"oldPassword");
		assertEquals(pchange.getNewPassword(),"newPassword");
	}

	@Test
	public void parseResetPasswordRequest() throws IOException {

		String json = ExampleFile.read(exampleRoot + "resetPasswordRequest.json");
		assertTrue(json.length() > 0);

		ResetPasswordRequest rpr = new ObjectMapper().readValue(json,ResetPasswordRequest.class);
		assertEquals(rpr.getTokenID(),"U3VjaCBpcyBsaWZlLg==");
	}

	@Test
	public void generateResetPasswordResponse() throws IOException {

		String json = ExampleFile.read(exampleRoot+"resetPasswordResponse.json");
		assertTrue(json.length()>0);

		ResetPasswordResponse rpr = new ObjectMapper().readValue(json, ResetPasswordResponse.class);
		assertEquals(rpr.getTokenID(),"U3VjaCBpcyBsaWZlLg==");
		assertEquals(rpr.getLinks().getNext().getHref(), "/api/v1/users/user@test.com/nextStep");
		assertEquals(rpr.getLinks().getNext().getTitle(),"Next");
	}





	@Test
	public void parseGetMigrationStatusResponse() throws IOException {
		String json = ExampleFile.read(exampleRoot+"get-migration-status-response.json");
		assertTrue(json.length() > 0);

		MigrationStatus msResp = new ObjectMapper().readValue(json,MigrationStatus.class);

		assertEquals(msResp.getMigrated(), Boolean.valueOf(true));
	}

	@Test
	public void parseRecoverPasswordResponse() throws IOException {

		String json = ExampleFile.read(exampleRoot + "recoverPasswordResponse.json");
		assertTrue(json.length() > 0);

		RecoverPasswordResponse recoverPass = new ObjectMapper().readValue(json,RecoverPasswordResponse.class);
		assertEquals("/api/v1/users/user@test.com/nextStep", recoverPass.getLinks().getNext().getHref());
		assertEquals("Next", recoverPass.getLinks().getNext().getTitle());
		assertEquals("bob@example.com", recoverPass.getUsername() );
	}

}
