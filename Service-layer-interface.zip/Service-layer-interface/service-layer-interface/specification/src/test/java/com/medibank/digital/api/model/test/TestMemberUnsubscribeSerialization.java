package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class TestMemberUnsubscribeSerialization {
	
	@Test
	public void generateActivateRequest() {
		
		UnsubscribeRequest ur = new UnsubscribeRequest();
		
		ur.setTokenID("U3VjaCBpcyBsaWZlLg==");
		
		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(ur);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "members", "memberUnsubscribeRequest.json");
		assertTrue(json.length()>0);

	}

}
