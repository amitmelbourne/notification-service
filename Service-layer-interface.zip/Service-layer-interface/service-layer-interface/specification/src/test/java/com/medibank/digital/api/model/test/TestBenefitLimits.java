package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.BenefitLimits;
import com.medibank.digital.api.model.CommonCoverage;
import com.medibank.digital.api.model.CoverType;
import com.medibank.digital.api.model.CoverTypeVersionLimitGroup;
import com.medibank.digital.api.model.PresentationLayerGroup;
import com.medibank.digital.api.model.CommonCoverageWaitingPeriod;
import com.medibank.digital.api.model.BenefitReplacementPeriodSummary;

import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestBenefitLimits {

	private static String exampleRoot = "src/main/resources/raml/policies/examples/";

	@Test
	public void serializeBenefitLimits() {

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		List<CoverTypeVersionLimitGroup> coverTypeVersionLimitGroupList = new ArrayList<CoverTypeVersionLimitGroup>();
		CoverTypeVersionLimitGroup coverTypeVersionLimitGroup = new CoverTypeVersionLimitGroup();
		coverTypeVersionLimitGroup.setCoverTypeVersionLimitGroupCode("51");
		coverTypeVersionLimitGroup.setLimitRuleCode("1");
		coverTypeVersionLimitGroup.setLimitAmount(100.00);
		coverTypeVersionLimitGroup.setAvailableLimitAmount(55.00);
		coverTypeVersionLimitGroup.setRemainingAvailableLimitAmount(45.00);
		coverTypeVersionLimitGroup.setEquityRuleCode("13");
		coverTypeVersionLimitGroup.setEquityRuleCodeDescription("CROWNS AND BRIDGES");
		coverTypeVersionLimitGroup.setEquityYear(2015);
		coverTypeVersionLimitGroup.setEquityAmount(50.00);
		coverTypeVersionLimitGroupList.add(coverTypeVersionLimitGroup);

		List<CommonCoverage> commonCoverageList = new ArrayList<CommonCoverage>();
		CommonCoverage commonCoverage = new CommonCoverage();
		commonCoverage.setCommonCoverageCode("CCE0010");
		commonCoverage.setCommonCoverageName("ENDDOTIC SERVICES FRAMES");
		commonCoverage.setWaitingRuleCodeDescription("Sample Description");
		commonCoverage.setWaitingPeriodApplicable(true);
		commonCoverage.setWaitingPeriodEndDate("2015-09-25");

		commonCoverageList.add(commonCoverage);

		List<PresentationLayerGroup> presentationLayerGroupList = new ArrayList<PresentationLayerGroup>();
		PresentationLayerGroup presentationLayerGroup = new PresentationLayerGroup();
		presentationLayerGroup.setPresentationLayerGroupCode("PLG00080");
		presentationLayerGroup.setPresentationLayerGroupName("OCCUPATIONAL THERAPY");
		presentationLayerGroup.setPresentationLayerGroupDesc("OCCUPATIONAL THERAPY");
		presentationLayerGroup.setParentGroup("Sample Parent Group");
		presentationLayerGroup.setPresentationLayerGroupType("LIFETIME");

		CommonCoverageWaitingPeriod waitingPeriod = new CommonCoverageWaitingPeriod();
		waitingPeriod.setCommonCoverageName("ABCDE");
		waitingPeriod.setWaitingPeriodEndDate("2016-10-27");
		List<CommonCoverageWaitingPeriod> waitingPeriods = new ArrayList<CommonCoverageWaitingPeriod>();
		waitingPeriods.add(waitingPeriod);
		presentationLayerGroup.setWaitingPeriods(waitingPeriods);

		BenefitReplacementPeriodSummary benefitReplacementPeriod = new BenefitReplacementPeriodSummary();
		benefitReplacementPeriod.setBenefitReplacementApplicable(true);
		benefitReplacementPeriod.setBenefitReplacementPeriod("24");
		benefitReplacementPeriod.setBenefitReplacementPeriodUnits("MONTHS");
		presentationLayerGroup.setBenefitReplacementPeriod(benefitReplacementPeriod);

		presentationLayerGroup.setGroupTier(1);
		presentationLayerGroup.setDisplayOrder(802);
		presentationLayerGroup.setCoverTypeVersionLimitGroups(coverTypeVersionLimitGroupList);
		presentationLayerGroup.setCommonCoverages(commonCoverageList);
		presentationLayerGroupList.add(presentationLayerGroup);

		List<CoverType> coverTypeList = new ArrayList<CoverType>();
		CoverType coverType = new CoverType();
		coverType.setCoverTypeCode("Sample Cover Code");
		coverType.setPresentationLayerGroups(presentationLayerGroupList);
		coverTypeList.add(coverType);

		BenefitLimits benefitLimits = new BenefitLimits();
		benefitLimits.setEffectiveDate("2015-09-25");
		benefitLimits.setProductOptionId("PA023");
		benefitLimits.setCoverType(coverTypeList);

		String json = null;
		try {
			json = mapper.writeValueAsString(benefitLimits);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "get-benefit-limits-response.json");
		assertTrue(json.length()>0);
	}


	@Test
	public void parseBenefitLimits() {
		String json = ExampleFile.read(exampleRoot + "get-benefit-limits-response.json");

		BenefitLimits benefitLimits = null;
		try {
			benefitLimits = new ObjectMapper().readValue(json,BenefitLimits.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		assertEquals(benefitLimits.getProductOptionId(),"PA023");
		assertEquals(benefitLimits.getCoverType().get(0).getCoverTypeCode(),"Sample Cover Code");
		assertEquals(benefitLimits.getCoverType().get(0).getPresentationLayerGroups().get(0).getPresentationLayerGroupCode(),"PLG00080");
		assertEquals(benefitLimits.getCoverType().get(0).getPresentationLayerGroups().get(0).getCoverTypeVersionLimitGroups().get(0).getCoverTypeVersionLimitGroupCode(),"51");
		assertEquals(benefitLimits.getCoverType().get(0).getPresentationLayerGroups().get(0).getCommonCoverages().get(0).getCommonCoverageCode(),"CCE0010");

	}
}
