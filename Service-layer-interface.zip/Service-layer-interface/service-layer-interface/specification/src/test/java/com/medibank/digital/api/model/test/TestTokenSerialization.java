package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Created by M45129 on 16/07/2015.
 */
public class TestTokenSerialization {

    @Test
    public void testSerializeCreateTokenRequest() throws Exception {

        CreateTokenRequest createTokenRequest = new CreateTokenRequest();
        createTokenRequest.setSecret("AAB334CCC");
        TokenProperties tokenProperties = new TokenProperties();
        createTokenRequest.setTokenProperties(tokenProperties);
        tokenProperties.setAdditionalProperty("bpId", "C1234");

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        String json = mapper.writeValueAsString(createTokenRequest);
        assertTrue(json.length()>0);
	ExampleFile.write(json, "tokens", "post-create-token-request.json");
    }

    @Test
    public void testSerializeCreateTokenResponse() throws Exception {

        CreateTokenResponse createTokenResponse = new CreateTokenResponse();
        createTokenResponse.setToken("AACCC-D3434-aeafd");

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        String json = mapper.writeValueAsString(createTokenResponse);
        assertTrue(json.length()>0);
	ExampleFile.write(json, "tokens", "post-create-token-response.json");
    }

    @Test
    public void testSerializeUseTokenRequest() throws Exception {

        UseTokenRequest useTokenRequest = new UseTokenRequest();

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        String json = mapper.writeValueAsString(useTokenRequest);
        assertTrue(json.length()>0);
	ExampleFile.write(json, "tokens", "post-use-token-request.json");
    }

    @Test
    public void testSerializeUseTokenResponse() throws Exception {

        UseTokenResponse useTokenResponse = new UseTokenResponse();
        TokenProperties tokenProperties = new TokenProperties();
        useTokenResponse.setTokenProperties(tokenProperties);
        tokenProperties.setAdditionalProperty("bpId", "C1234");
        useTokenResponse.setTokenType("password-reset");

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        String json = mapper.writeValueAsString(useTokenResponse);
        assertTrue(json.length()>0);
	ExampleFile.write(json, "tokens", "post-use-token-response.json");
    }

    @Test
    public void generateVerifyTokenRequest() throws Exception {

        VerifyTokenRequest vtr= new VerifyTokenRequest();

        vtr.setTokenID("U3VjaCBpcyBsaWZlLg==");

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        String json = mapper.writeValueAsString(vtr);

        ExampleFile.write(json, "tokens", "post-verify-token-request.json");
        assertTrue(json.length() > 0);

    }
}
