package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.MemberSummary;
import com.medibank.digital.api.model.PolicySummaryList;
import com.medibank.digital.api.model.ProductSummary;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import com.medibank.digital.api.model.PolicySummary;

import static org.junit.Assert.assertTrue;

public class TestPolicySerialization {

	@Test
	public void GeneratePolicyList() {

		List<PolicySummary> list = new ArrayList<PolicySummary>();

		PolicySummary p = policyFactory("active","2014-01-01");
		ProductSummary prod = productFactory("Top 85 Working Visa Health Insurance with Excess", "family", "VIC");
		p.setProduct(prod);
		MemberSummary m = memberFactory("John Smith");
		p.setMember(m);
		list.add(p);

		p = policyFactory("active","2013-05-01");
		prod = productFactory("Basic Hospital and Basic Extras", "family", "VIC");
		p.setProduct(prod);
		m = memberFactory("Mary Jones");
		p.setMember(m);
		list.add(p);

		p = policyFactory("active","2015-03-15");
		prod = productFactory("Settled Families Essentials", "family", "VIC");
		p.setProduct(prod);
		m = memberFactory("James P. Quigley");
		p.setMember(m);
		list.add(p);

		PolicySummaryList psl = new PolicySummaryList().withPolicies(list);

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(psl);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "policiesList.json");

		assertTrue(json.length()>0);

	}

	public static PolicySummary policyFactory(String status, String startDate) {
		ResourceFactory f = new ResourceFactory();
		PolicySummary p = new PolicySummary();
		p.setId(f.getId());
		p.setLinks(f.getLinks("policies"));
		p.setStatus(status);
		p.setFuturePolicy(false);
		p.setStartDate(startDate);
		return p;
	}

	public static ProductSummary productFactory(String name, String scale, String state) {
		ResourceFactory f = new ResourceFactory();
		ProductSummary p = new ProductSummary();
		p.setId(f.getId());
		p.setLinks(f.getLinks("products"));
		p.setName(name);
		p.setScale(scale);
		p.setState(state);
		return p;
	}

	public static MemberSummary memberFactory(String name) {
		ResourceFactory f = new ResourceFactory();
		MemberSummary p = new MemberSummary();
		p.setId(f.getId());
		p.setLinks(f.getLinks("members"));
		p.setName(name);
		p.setPartyStatus("active");
		p.setPartyType("main");
		List<String> roles = new ArrayList<String>();
		roles.add("policy holder");
		p.setPartyRole(roles);
		return p;
	}
}
