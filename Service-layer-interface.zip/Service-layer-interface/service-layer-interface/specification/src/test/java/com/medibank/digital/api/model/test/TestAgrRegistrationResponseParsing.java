package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class TestAgrRegistrationResponseParsing {

	private static String exampleRoot = "src/main/resources/raml/policies/examples/";

	@Test
	public void parseAgrRegistrationResponse() {
		String json = ExampleFile.read(exampleRoot+"post-agr-registration-response.json");
		assertTrue(json.length()>0);

		try {
			AgrRegistrationResponse agrRegistrationResponse = new ObjectMapper().readValue(json, AgrRegistrationResponse.class);

			assertEquals(agrRegistrationResponse.getPaymentFrequency(),"MONTHLY");
			assertEquals(agrRegistrationResponse.getDatePaidTo(), "2015-12-15");

			assertEquals(agrRegistrationResponse.getAusgovRebate().getRegistrationEffectiveFromDate(), "2015-09-15");
			assertEquals(agrRegistrationResponse.getAusgovRebate().getAgrPercentage(), "5");

			assertEquals(agrRegistrationResponse.getPremiums().getCurrent().get(0).getCoverPeriod(),"MONTHLY");
			assertEquals(agrRegistrationResponse.getPremiums().getCurrent().get(0).getBaseAmount(),Double.valueOf(512.10));
			assertEquals(agrRegistrationResponse.getPremiums().getCurrent().get(0).getPaymentAmount(),Double.valueOf(345.67));
			assertEquals(agrRegistrationResponse.getPremiums().getCurrent().get(0).getCoverageStartDate(),"2015-30-15");

			assertEquals(agrRegistrationResponse.getPremiums().getFuture().get(0).getCoverPeriod(),"MONTHLY");
			assertEquals(agrRegistrationResponse.getPremiums().getFuture().get(0).getBaseAmount(),Double.valueOf(712.10));
			assertEquals(agrRegistrationResponse.getPremiums().getFuture().get(0).getPaymentAmount(),Double.valueOf(445.67));
			assertEquals(agrRegistrationResponse.getPremiums().getFuture().get(0).getCoverageStartDate(),"2015-30-15");
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
