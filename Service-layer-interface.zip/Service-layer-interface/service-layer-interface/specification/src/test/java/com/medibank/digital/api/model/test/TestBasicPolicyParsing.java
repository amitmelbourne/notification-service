package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.*;

public class TestBasicPolicyParsing {

	private static String exampleRoot = "src/main/resources/raml/policies/examples/";

	@Test
	public void parsePolicyList() {
		String json = ExampleFile.read(exampleRoot+"basicPoliciesList.json");
		assertTrue(json.length()>0);

		try {
			BasicPolicySummaryList psl = new ObjectMapper().readValue(json,BasicPolicySummaryList.class);
			List<BasicPolicySummary> list = psl.getPolicies();
			assertEquals(list.size(),3);

			for (BasicPolicySummary p : list) {
				assertEquals(p.getType(),"policies");
				assertEquals(p.getFuturePolicy(),Boolean.FALSE);
				assertNotNull(p.getProductName());
				assertNotNull(p.getProdOptcode());
				assertNotNull(p.getEffectiveDt());
				assertNotNull(p.getStartDate());
				assertNotNull(p.getPersonJoinDt());
				assertEquals(p.getStatus(),"active");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
