package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.*;
import com.sun.org.apache.xpath.internal.operations.Bool;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class TestClaimsParsing {

    private static String exampleRoot = "src/main/resources/raml/claims/examples/";

    @Test
    public void parseSearchProviderResponse() throws Exception {
        String json = ExampleFile.read(exampleRoot + "get-search-provider-response.json");
        assertTrue(json.length() > 0);

        SearchProviders sProviderResp = new ObjectMapper().readValue(json, SearchProviders.class);

        assertEquals(sProviderResp.getProviders().get(0).getId(), "P123");
        assertEquals(sProviderResp.getProviders().get(0).getPersonName().getFirstName(), "John");
        assertEquals(sProviderResp.getProviders().get(0).getPersonName().getLastName(), "Snow");
        assertEquals(sProviderResp.getProviders().get(0).getMemberChoice(), Boolean.valueOf(true));

        assertEquals(sProviderResp.getProviders().get(0).getAddress().getAddressLine1(), "Office 1");
        assertEquals(sProviderResp.getProviders().get(0).getAddress().getAddressLine2(), "Level 15");
        assertEquals(sProviderResp.getProviders().get(0).getAddress().getAddressLine3(), "250 Collins St.");
        assertEquals(sProviderResp.getProviders().get(0).getAddress().getTownName(), "Melbourne");
        assertEquals(sProviderResp.getProviders().get(0).getAddress().getState(), "VIC");
        assertEquals(sProviderResp.getProviders().get(0).getAddress().getPostCode(), "3000");


        assertEquals(sProviderResp.getProviders().get(0).getPractices().get(0).getCode(), "01");
        assertEquals(sProviderResp.getProviders().get(0).getPractices().get(0).getDescription(), "General Medicine");
        assertEquals(sProviderResp.getProviders().get(0).getPractices().get(1).getCode(), "02");
        assertEquals(sProviderResp.getProviders().get(0).getPractices().get(1).getDescription(), "Pathology");
        assertEquals(sProviderResp.getProviders().get(0).getPractices().get(2).getCode(), "03");
        assertEquals(sProviderResp.getProviders().get(0).getPractices().get(2).getDescription(), "Chiropractic");

        assertEquals(sProviderResp.getProviders().get(1).getId(), "P456");
        assertEquals(sProviderResp.getProviders().get(1).getOrgName(), "First Choice Medical Center");
        assertEquals(sProviderResp.getProviders().get(1).getMemberChoice(), Boolean.valueOf(false));

        assertEquals(sProviderResp.getProviders().get(1).getAddress().getAddressLine1(), "Medical Services");
        assertEquals(sProviderResp.getProviders().get(1).getAddress().getAddressLine2(), "Unit 3");
        assertEquals(sProviderResp.getProviders().get(1).getAddress().getAddressLine3(), "400 La Trobe St.");
        assertEquals(sProviderResp.getProviders().get(1).getAddress().getTownName(), "Melbourne");
        assertEquals(sProviderResp.getProviders().get(1).getAddress().getState(), "VIC");
        assertEquals(sProviderResp.getProviders().get(1).getAddress().getPostCode(), "3000");


        assertEquals(sProviderResp.getProviders().get(1).getPractices().get(0).getCode(), "01");
        assertEquals(sProviderResp.getProviders().get(1).getPractices().get(0).getDescription(), "General Medicine");
        assertEquals(sProviderResp.getProviders().get(1).getPractices().get(1).getCode(), "02");
        assertEquals(sProviderResp.getProviders().get(1).getPractices().get(1).getDescription(), "Pathology");
        assertEquals(sProviderResp.getProviders().get(1).getPractices().get(2).getCode(), "03");
        assertEquals(sProviderResp.getProviders().get(1).getPractices().get(2).getDescription(), "Chiropractic");


        assertEquals(sProviderResp.getLinks().getSelf().getHref(), "/api/v1/claims/providers?postcode=3000&page_number=1");
        assertEquals(sProviderResp.getLinks().getFirst().getHref(), "/api/v1/claims/providers?postcode=3000");
        assertEquals(sProviderResp.getLinks().getNext().getHref(), "/api/v1/claims/providers?postcode=3000&page_number=2");
        assertEquals(sProviderResp.getLinks().getPrev().getHref(), "/api/v1/claims/providers?postcode=3000");
        assertEquals(sProviderResp.getLinks().getLast().getHref(), "/api/v1/claims/providers?postcode=3000&page_number=3");


    }

    @Test
    public void parseReadByProviderIDResponse() throws Exception {
        String json = ExampleFile.read(exampleRoot + "get-provider-by-id.json");
        assertTrue(json.length() > 0);


        ServiceProvider sProviderResp = new ObjectMapper().readValue(json, ServiceProvider.class);

        assertEquals(sProviderResp.getId(), "P123");
        assertEquals(sProviderResp.getPersonName().getFirstName(), "John");
        assertEquals(sProviderResp.getPersonName().getLastName(), "Snow");
        assertEquals(sProviderResp.getMemberChoice(), Boolean.valueOf(true));

        assertEquals(sProviderResp.getAddress().getAddressLine1(), "Office 1");
        assertEquals(sProviderResp.getAddress().getAddressLine2(), "Level 15");
        assertEquals(sProviderResp.getAddress().getAddressLine3(), "250 Collins St.");
        assertEquals(sProviderResp.getAddress().getTownName(), "Melbourne");
        assertEquals(sProviderResp.getAddress().getState(), "VIC");
        assertEquals(sProviderResp.getAddress().getPostCode(), "3000");

        assertEquals(sProviderResp.getValidFromDate(), "2013-06-25");
        assertEquals(sProviderResp.getValidToDate(), "2018-06-31");


        assertEquals(sProviderResp.getPractices().get(0).getCode(), "01");
        assertEquals(sProviderResp.getPractices().get(0).getDescription(), "General Medicine");
        assertEquals(sProviderResp.getPractices().get(1).getCode(), "02");
        assertEquals(sProviderResp.getPractices().get(1).getDescription(), "Pathology");
        assertEquals(sProviderResp.getPractices().get(2).getCode(), "03");
        assertEquals(sProviderResp.getPractices().get(2).getDescription(), "Chiropractic");

        assertEquals(sProviderResp.getLinks().getSelf().getHref(), "/api/v1/claims/providers/P123?include=type");


    }

    @Test
    public void parseSearchServiceItemResponse() throws Exception {
        String json = ExampleFile.read(exampleRoot + "get-search-service-item-response.json");
        assertTrue(json.length() > 0);

        ServiceItems sServiceItemResp = new ObjectMapper().readValue(json, ServiceItems.class);

        assertEquals(sServiceItemResp.getPolicyNumber(), "P1234");
        assertEquals(sServiceItemResp.getProviderId(), "SP123");
        assertEquals(sServiceItemResp.getPractices().get(0).getPracticeType().getCode(), "EYE101");
        assertEquals(sServiceItemResp.getPractices().get(0).getPracticeType().getDescription(), "General Medicine");
        assertEquals(sServiceItemResp.getPractices().get(0).getCoPaymentAmount(), Double.valueOf(100));
        assertEquals(sServiceItemResp.getPractices().get(0).getPharmacyItems().get(0).getDrugBrandName(), "DrugRUS");
        assertEquals(sServiceItemResp.getPractices().get(0).getPharmacyItems().get(0).getDrugGenericName(), "DrugName1");
        assertEquals(sServiceItemResp.getPractices().get(0).getPharmacyItems().get(0).getItemDetails().get(0).getCode(), "D911");
        assertEquals(sServiceItemResp.getPractices().get(0).getPharmacyItems().get(0).getItemDetails().get(0).getType(), "NC233");
        assertEquals(sServiceItemResp.getPractices().get(0).getPharmacyItems().get(0).getItemDetails().get(0).getStrength(), "20mg");
        assertEquals(sServiceItemResp.getPractices().get(0).getPharmacyItems().get(0).getItemDetails().get(0).getPackNumberSize(), "6");
        assertEquals(sServiceItemResp.getPractices().get(0).getPharmacyItems().get(0).getItemDetails().get(0).getEffectiveStartDate(), "2013-06-25");
        assertEquals(sServiceItemResp.getPractices().get(0).getPharmacyItems().get(0).getItemDetails().get(0).getEffectiveEndDate(), "2019-06-25");
        assertEquals(sServiceItemResp.getPractices().get(0).getServiceItems().get(0).getCode(), "C123");
        assertEquals(sServiceItemResp.getPractices().get(0).getServiceItems().get(0).getDescription(), "Service Item Desc text");
        assertEquals(sServiceItemResp.getPractices().get(0).getServiceItems().get(0).getIsValidForPolicy(), Boolean.valueOf(true));

        assertEquals(sServiceItemResp.getLinks().getSelf().getHref(), "/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101&page_number=1");
        assertEquals(sServiceItemResp.getLinks().getFirst().getHref(), "/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101");
        assertEquals(sServiceItemResp.getLinks().getNext().getHref(), "/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101&page_number=2");
        assertEquals(sServiceItemResp.getLinks().getPrev().getHref(), "/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101");
        assertEquals(sServiceItemResp.getLinks().getLast().getHref(), "/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101&page_number=3");


    }

    @Test
    public void parseClaimRequest() throws Exception {
        String json = ExampleFile.read(exampleRoot + "post-submit-claim-request.json");
        assertTrue(json.length() > 0);

        ClaimRequest cr = new ObjectMapper().readValue(json, ClaimRequest.class);

        assertEquals(cr.getPolicyRef().getId(), "P1234");
        assertEquals(cr.getPolicyRef().getType(), "policies");
        assertEquals(cr.getPolicyRef().getLink(), "/v1/policies/P1234");

        assertEquals(cr.getItems().get(0).getCode(), "39128A");
        assertEquals(cr.getItems().get(0).getDateOfService(), "2015-06-25");
        assertEquals(cr.getItems().get(0).getToothId(), "12A");
        assertEquals(cr.getItems().get(0).getPharmacyScriptNumber(), "12345");
        assertEquals(cr.getItems().get(0).getPrescribingDoctor(), "Dr. Strangelove");
        assertEquals(cr.getItems().get(0).getQuantity(), Integer.valueOf(12));
        assertEquals(cr.getItems().get(0).getChargeAmount(), Double.valueOf(10.00));

        assertEquals(cr.getCategory(), "ANCILLARY");
        assertEquals(cr.getPracticeTypeCode(), "400089276A");
        assertEquals(cr.getReferenceNumber(), "REF-00001");
        assertEquals(cr.getIsBonusClaim(), Boolean.FALSE);
        assertEquals(cr.getAccountPaid(), Boolean.TRUE);
        assertEquals(cr.getNotionalClaim(), Boolean.FALSE);
        assertEquals(cr.getPatientMemberId(), "4000013838A");
        assertEquals(cr.getProviderNumber(), "0990111K");
        assertEquals(cr.getPharmacyName(), "First Choice Pharmacy Berwick");
        assertEquals(cr.getTotalChargeAmount(), Double.valueOf(40.00));
        assertEquals(cr.getTotalDiscountAmount(), Double.valueOf(4));

        assertEquals(cr.getPolicyRef().getId(), "P1234");
        assertEquals(cr.getPolicyRef().getLink(), "/v1/policies/P1234");
        assertEquals(cr.getPolicyRef().getType(), "policies");

    }

    @Test
    public void parseClaimResponse() throws Exception {
        String json = ExampleFile.read(exampleRoot + "post-submit-claim-response.json");
        assertTrue(json.length() > 0);

        ClaimResponse cr = new ObjectMapper().readValue(json, ClaimResponse.class);

        assertEquals(cr.getPolicyRef().getId(), "P1234");
        assertEquals(cr.getPolicyRef().getType(), "policies");
        assertEquals(cr.getPolicyRef().getLink(), "/v1/policies/P1234");
        assertEquals(cr.getLinks().getSelf().getHref(), "/api/v1/claims/12345");

        assertEquals(cr.getItems().get(0).getAssessments().get(0).getCode(), "001A");
        assertEquals(cr.getItems().get(0).getAssessments().get(0).getDescription(), "Item Description 1");

        assertEquals(cr.getItems().get(0).getId(), "001");
        assertEquals(cr.getItems().get(0).getCode(), "39128A");
        assertEquals(cr.getItems().get(0).getDateOfService(), "2015-06-25");
        assertEquals(cr.getItems().get(0).getStatus(), "PROCESSING");
        assertEquals(cr.getItems().get(0).getBenefitPaidAmount(), Double.valueOf(25.0));
        assertEquals(cr.getItems().get(0).getBonusPaidAmount(), Double.valueOf(50.0));

        assertEquals(cr.getId(), "12345");
        assertEquals(cr.getType(), "claims");
        assertEquals(cr.getReferenceNumber(), "REF-00001");
        assertEquals(cr.getStatus(), "2-PROCESSING");
        assertEquals(cr.getPayToWho(), "MEMBER");
        assertEquals(cr.getProcessedDateTime(), "2002-05-30T09:30:10.000Z");
        assertEquals(cr.getTotalBonusPaidAmount(), Double.valueOf(100.0));
        assertEquals(cr.getTotalBenefitPaidAmount(), Double.valueOf(50.0));
        assertEquals(cr.getTotalPaidAmount(), Double.valueOf(150.0));

    }

}
