package com.medibank.digital.api.model.test;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import com.medibank.digital.api.model.MigrationStatus;
import com.sun.org.apache.xpath.internal.operations.Bool;
import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.BankBsbResponse;

public class TestReferenceParsing {

	private static String exampleRoot = "src/main/resources/raml/reference/examples/";

	@Test
	public void parseGetUserResponse() throws IOException {
		String json = ExampleFile.read(exampleRoot+"bankBsbResponse.json");
		assertTrue(json.length()>0);


			BankBsbResponse bsbResp = new ObjectMapper().readValue(json,BankBsbResponse.class);
			
			assertEquals(bsbResp.getType(),"bank");
			assertEquals(bsbResp.getId(),"032-132");
			assertEquals(bsbResp.getBsbNum(),"032-123");
			assertEquals(bsbResp.getName(),"Westpac Banking Corporation");
			assertEquals(bsbResp.getBranchName(),"Frenchs Forest");
			assertEquals(bsbResp.getAddress().getAddressLine1(), "Shop 20 Forestway Shopping Centre");
			assertEquals(bsbResp.getAddress().getTownName(), "Frenchs Forest");
			assertEquals(bsbResp.getAddress().getPostCode(), "2086");
			assertEquals(bsbResp.getAddress().getState(), "NSW");
			assertEquals(bsbResp.getLinks().getSelf().getHref(),"/api/v1/references/bank/032-123");

	}

}
