package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.MemberTypes;
import org.junit.Test;

import java.io.IOException;
import java.util.Arrays;

import static org.junit.Assert.assertTrue;

public class TestMemberTypes {

    private static String exampleRoot = "src/main/resources/raml/members/examples/";

    private final String ELEVATE = "elevate";
    private final String OSHC    = "oshc";

    @Test
    public void serializeMemberTypes() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        MemberTypes memberTypes = new MemberTypes();
        memberTypes.setTypes(Arrays.asList(ELEVATE, OSHC));

        String json = null;
        try {
            json = mapper.writeValueAsString(memberTypes);
        } catch (JsonProcessingException e) {
            e.printStackTrace();

        }
        ExampleFile.write(json, "memberTypes", "memberTypes.json");
        assertTrue(json.length()>0);
    }

    @Test
    public void parseMemberTypes() {
        String json = ExampleFile.read(exampleRoot + "get-member-types.json");

        try {
            MemberTypes memberTypes = new ObjectMapper().readValue(json, MemberTypes.class);
            assert(memberTypes.getTypes().contains(ELEVATE));
            assert(memberTypes.getTypes().contains(OSHC));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
