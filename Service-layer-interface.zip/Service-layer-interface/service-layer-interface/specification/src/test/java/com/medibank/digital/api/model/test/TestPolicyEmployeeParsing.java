package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.medibank.digital.api.model.Policy;
import com.medibank.digital.api.model.PolicyMember;
import org.junit.Test;

import java.util.List;
import java.io.IOException;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class TestPolicyEmployeeParsing {

    private static String exampleRoot = "src/main/resources/raml/policies/examples/";

    @Test
    public void parsePolicyEmployee() {
        String json = ExampleFile.read(exampleRoot+"get-policy-employee.json");
        assertNotNull(json);

        try {
            Policy p = new ObjectMapper().readValue(json, Policy.class);
            assertNotNull(p);

            List<PolicyMember> msL = p.getMembers();
            assertEquals(msL.size(),2);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}