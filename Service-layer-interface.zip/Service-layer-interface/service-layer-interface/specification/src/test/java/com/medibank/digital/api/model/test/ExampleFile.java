package com.medibank.digital.api.model.test;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;

public class ExampleFile{

	private static String generatedExampleRoot = "target/examples/";

	public static String read(String filename) {
		StringBuffer buff = new StringBuffer();
		FileReader fr = null;
		try {
			fr = new FileReader(filename);
		} catch (FileNotFoundException ex) {
		 	ex.printStackTrace();
			System.err.println("FIle '"+filename+"' not found");
			return "";
		}

		try {
			BufferedReader reader = new BufferedReader(fr);
			String s;
			while ((s = reader.readLine()) != null) {
				buff.append(s);
				buff.append("\n");
			}
			fr.close();
		} catch (IOException ex) {
				  ex.printStackTrace();
				  return "";
		}
		return buff.toString();
	}

	public static void write(String json, String folder, String filename) {

		File dir = null;
		File file = null;
		FileWriter fw = null;

		try {
			dir = new File(generatedExampleRoot+folder+"/");
			dir.mkdirs();
			file = new File(dir, filename);
			fw = new FileWriter(file);
			fw.write(json);
			fw.flush();
			fw.close();
		} catch (IOException ex) {
		 	ex.printStackTrace();
			System.err.println("Error writing to example file '"+dir+"/"+filename+"'");
		}
	}
}
