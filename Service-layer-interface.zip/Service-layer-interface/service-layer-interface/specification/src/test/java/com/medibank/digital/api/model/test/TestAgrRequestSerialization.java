package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.AgrIncomeTier;
import com.medibank.digital.api.model.AusGovRebate;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class TestAgrRequestSerialization {

	@Test
	public void generateUpdateAGRResponse() {

		AusGovRebate agr = new AusGovRebate()
				.withEffectiveAGR("true")
				.withRegistrationStatus("true")
				.withAgrPercentage("5")
				.withRegistrationEffectiveFromDate("2015-08-23")
				.withRegistrationEffectiveToDate("2016-08-23");

		AgrIncomeTier tier = new AgrIncomeTier().withIncomeType("1")
				.withIncomeTier("2");
		agr.setAgrIncomeTier(tier);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(agr);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "put-agr-request.json");
		assertTrue(json.length()>0);

	}
}
