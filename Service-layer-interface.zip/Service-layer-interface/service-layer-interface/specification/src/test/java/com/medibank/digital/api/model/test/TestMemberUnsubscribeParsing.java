package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestMemberUnsubscribeParsing {

	private static String exampleRoot = "src/main/resources/raml/members/examples/";

	@Test
	public void parseActivateRequest() {
		
		String json = ExampleFile.read(exampleRoot+"memberUnsubscribeRequest.json");
		assertTrue(json.length()>0);

		try {
			UnsubscribeRequest ur = new ObjectMapper().readValue(json,UnsubscribeRequest.class);
			
			assertEquals(ur.getTokenID(),"U3VjaCBpcyBsaWZlLg==");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
