package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static java.util.Collections.singletonList;
import static org.junit.Assert.assertTrue;

public class TestAgrRegistrationResponseSerialization {

	@Test
	public void generateAgrRegistrationResponse() {

		AgrRegistrationResponse agrRegistrationResponse = new AgrRegistrationResponse();
		agrRegistrationResponse.setPaymentFrequency("MONTHLY");
		agrRegistrationResponse.setDatePaidTo("2015-12-15");

		AusGovRebate agrRebateResp = new AusGovRebate().withAgrPercentage("5").withRegistrationEffectiveFromDate("2015-09-15");
		agrRegistrationResponse.setAusgovRebate(agrRebateResp);

		Premium current = new Premium()
				.withCoverPeriod("MONTHLY")
				.withBaseAmount(512.10)
				.withPaymentAmount(345.67)
				.withCoverageStartDate("2015-30-15");

		Premium future = new Premium()
				.withCoverPeriod("MONTHLY")
				.withBaseAmount(712.10)
				.withPaymentAmount(445.67)
				.withCoverageStartDate("2015-30-15");

		Premiums premiums = new Premiums();
		premiums.setCurrent(singletonList(current));
		premiums.setFuture(singletonList(future));

		agrRegistrationResponse.setPremiums(premiums);


		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(agrRegistrationResponse);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "post-agr-registration-response.json");
		assertTrue(json.length()>0);

	}
}
