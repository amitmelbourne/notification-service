package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.AmountToPay;
import com.medibank.digital.api.model.PaymentOption;
import com.medibank.digital.api.model.Premium;
import com.medibank.digital.api.model.Premiums;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import static java.util.Arrays.asList;
import static java.util.Calendar.DAY_OF_MONTH;
import static java.util.Calendar.MONTH;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Created by M45129 on 7/09/2015.
 */
public class TestAmountToPay {

    private ObjectMapper mapper = MapperFactory.createMapper();

    public static AmountToPay createSample() {
        AmountToPay amountToPay = new AmountToPay();

        List<PaymentOption> current = asList(
                createPaymentOption(213.45, 12, false),
                createPaymentOption(224.55, 20, false),
                createPaymentOption(200.35, 3, false),
                createPaymentOption(220.74, 18, false)
        );
        amountToPay.setCurrent(current);

        List<PaymentOption> future = asList(
                createPaymentOption(213.45, 12, true),
                createPaymentOption(224.55, 20, true),
                createPaymentOption(200.35, 3, true),
                createPaymentOption(220.74, 18, true)
        );
        amountToPay.setFuture(future);

        return amountToPay;
    }

    private static PaymentOption createPaymentOption(double amount, int dayOfMonth, boolean isFuture) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Calendar effective = Calendar.getInstance();
        effective.set(MONTH, isFuture ? 8 : 6);
        effective.set(DAY_OF_MONTH, dayOfMonth);

        Calendar paidTo = Calendar.getInstance();
        paidTo.set(MONTH, isFuture ? 10 : 8);
        paidTo.set(DAY_OF_MONTH, dayOfMonth);

        String datePaidTo = formatter.format(paidTo.getTime()),
                effectiveDate = formatter.format(effective.getTime()),
                paymentDate = formatter.format(effective.getTime());
        return new PaymentOption()
                .withDatePaidTo(datePaidTo)
                .withEffectiveDate(effectiveDate)
                .withPaymentDate(paymentDate)
                .withPaymentAmount(isFuture ? amount + 2d : amount);
    }

    @Test
    public void generateExampleFile() throws IOException {
        AmountToPay amountToPay = createSample();
        String json = mapper.writeValueAsString(amountToPay);

        ExampleFile.write(json, "policies", "amount-to-pay.json");
        Assert.assertTrue(json.length() > 0);
    }

    @Test
    public void verifyMarshallingRoundTrip() throws IOException {
        AmountToPay amountToPayOut = createSample();
        String json = mapper.writeValueAsString(amountToPayOut);

        AmountToPay amountToPayIn = mapper.readValue(json, AmountToPay.class);
        assertMatch(amountToPayOut, amountToPayIn);
    }

    public static void assertMatch(AmountToPay expected, AmountToPay actual) {
        List<PaymentOption> expectedCurrent = expected.getCurrent();
        List<PaymentOption> actualCurrent = actual.getCurrent();
        assertEquals(expectedCurrent.size(), actualCurrent.size());
        for (int i = 0; i < expectedCurrent.size(); i++) {
            assertPaymentOptionMatch(expectedCurrent.get(i), actualCurrent.get(i));
        }

        List<PaymentOption> expectedFuture = expected.getFuture();
        List<PaymentOption> actualFuture = actual.getFuture();
        assertEquals(expectedFuture.size(), actualFuture.size());
        for (int i = 0; i < expectedFuture.size(); i++) {
            assertPaymentOptionMatch(expectedFuture.get(i), actualFuture.get(i));
        }
    }

    public static void assertPaymentOptionMatch(PaymentOption expected, PaymentOption actual) {
        assertEquals(expected.getDatePaidTo(), actual.getDatePaidTo());
        assertEquals(expected.getEffectiveDate(), actual.getEffectiveDate());
        assertEquals(expected.getPaymentDate(), actual.getPaymentDate());
        assertEquals(expected.getPaymentAmount(), actual.getPaymentAmount());
    }

    @Test
    public void testExampleFile() throws IOException {
        String exampleRoot = "src/main/resources/raml/policies/examples/";
        String json = ExampleFile.read(exampleRoot + "amount-to-pay.json");

        AmountToPay amountToPay = new ObjectMapper().readValue(json, AmountToPay.class);

        assertEquals(4, amountToPay.getCurrent().size());
        assertEquals(4, amountToPay.getFuture().size());

        for (PaymentOption p : amountToPay.getCurrent()) {
            assertFullPaymentOption(p);
        }

        for (PaymentOption p : amountToPay.getFuture()) {
            assertFullPaymentOption(p);
        }
    }

    protected static void assertFullPaymentOption(PaymentOption p) {
        assertNotNull(p.getPaymentAmount());
        assertNotNull(p.getEffectiveDate());
        assertNotNull(p.getPaymentDate());
        assertNotNull(p.getDatePaidTo());
    }
}
