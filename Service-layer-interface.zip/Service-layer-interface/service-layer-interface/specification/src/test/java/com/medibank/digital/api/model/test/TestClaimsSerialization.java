package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class TestClaimsSerialization {

	@Test
	public void generateSearchProviderResponse() throws Exception {

		PracticeType p1 = new PracticeType().withCode("01").withDescription("General Medicine");
		PracticeType p2 = new PracticeType().withCode("02").withDescription("Pathology");
		PracticeType p3 = new PracticeType().withCode("03").withDescription("Chiropractic");

		List<PracticeType> typeList = new ArrayList<>();
		typeList.add(p1);
		typeList.add(p2);
		typeList.add(p3);

		Address a1 = new Address().withAddressLine1("Office 1").withAddressLine2("Level 15").withAddressLine3("250 Collins St.").withTownName("Melbourne").withState("VIC").withPostCode("3000");
		Address a2 = new Address().withAddressLine1("Medical Services").withAddressLine2("Unit 3").withAddressLine3("400 La Trobe St.").withTownName("Melbourne").withState("VIC").withPostCode("3000");

		Name n1 = new Name().withFirstName("John").withLastName("Snow");

		ServiceProvider sp1 = new ServiceProvider()
				.withId("P123")
				.withPersonName(n1)
				.withMemberChoice(true)
				.withAddress(a1)
				.withPractices(typeList);

		ServiceProvider sp2 = new ServiceProvider()
				.withId("P456")
				.withOrgName("First Choice Medical Center")
				.withMemberChoice(false)
				.withAddress(a2)
				.withPractices(typeList);

		List<ServiceProvider> serviceProvderList = new ArrayList<>();
		serviceProvderList.add(sp1);
		serviceProvderList.add(sp2);

		Links sLinks = new Links().withSelf(new Self().withHref("/api/v1/claims/providers?postcode=3000&page_number=1")).withFirst(new First().withHref("/api/v1/claims/providers?postcode=3000")).withNext(new Next().withHref("/api/v1/claims/providers?postcode=3000&page_number=2")).withPrev(new Prev().withHref("/api/v1/claims/providers?postcode=3000")).withLast(new Last().withHref("/api/v1/claims/providers?postcode=3000&page_number=3"));

		SearchProviders searchProviderResponse = new SearchProviders();
		searchProviderResponse.setProviders(serviceProvderList);
		searchProviderResponse.setLinks(sLinks);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(searchProviderResponse);

		ExampleFile.write(json, "claims", "get-search-provider-response.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateReadByProviderIDResponse()  throws Exception {

		PracticeType p1 = new PracticeType().withCode("01").withDescription("General Medicine");
		PracticeType p2 = new PracticeType().withCode("02").withDescription("Pathology");
		PracticeType p3 = new PracticeType().withCode("03").withDescription("Chiropractic");

		List<PracticeType> typeList = new ArrayList<>();
		typeList.add(p1);
		typeList.add(p2);
		typeList.add(p3);

		Address a1 = new Address().withAddressLine1("Office 1").withAddressLine2("Level 15").withAddressLine3("250 Collins St.").withTownName("Melbourne").withState("VIC").withPostCode("3000");

		Name n1 = new Name().withFirstName("John").withLastName("Snow");

		ServiceProvider sp1 = new ServiceProvider()
				.withId("P123")
				.withPersonName(n1)
				.withMemberChoice(true)
				.withAddress(a1)
				.withPractices(typeList)
				.withValidFromDate("2013-06-25")
				.withValidToDate("2018-06-31");

		Links sLinks = new Links().withSelf(new Self().withHref("/api/v1/claims/providers/P123?include=type"));

		sp1.setLinks(sLinks);


		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(sp1);

		ExampleFile.write(json, "claims", "get-provider-by-id.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateSearchServiceItemResponse()  throws Exception {

		PracticeType p1 = new PracticeType().withCode("EYE101").withDescription("General Medicine");
		PracticeType p2 = new PracticeType().withCode("EYE101").withDescription("Optometry");

		PharmacyItemDetail pItemDetail1 = new PharmacyItemDetail()
				.withCode("D911")
				.withType("NC233")
				.withStrength("20mg")
				.withPackNumberSize("6")
				.withEffectiveStartDate("2013-06-25")
				.withEffectiveEndDate("2019-06-25");
		PharmacyItemDetail pItemDetail2 = new PharmacyItemDetail()
				.withCode("d67fd")
				.withType("NC76765")
				.withStrength("100mg")
				.withPackNumberSize("12")
				.withEffectiveStartDate("2012-06-25")
				.withEffectiveEndDate("2018-06-25");
		PharmacyItemDetail pItemDetail3 = new PharmacyItemDetail()
				.withCode("c347ud")
				.withType("NC74389")
				.withStrength("50mg")
				.withPackNumberSize("24")
				.withEffectiveStartDate("2011-06-25")
				.withEffectiveEndDate("2022-06-25");

		List<PharmacyItemDetail> pharmacyItemDetailList = new ArrayList<>();
		pharmacyItemDetailList.add(pItemDetail1);
		pharmacyItemDetailList.add(pItemDetail2);
		pharmacyItemDetailList.add(pItemDetail3);

		PharmacyItem pItem1 = new PharmacyItem()
				.withDrugBrandName("DrugRUS")
				.withDrugGenericName("DrugName1")
				.withItemDetails(pharmacyItemDetailList);
		PharmacyItem pItem2 = new PharmacyItem()
				.withDrugBrandName("ACME")
				.withDrugGenericName("DrugName2")
				.withItemDetails(pharmacyItemDetailList);

		List<PharmacyItem> pItemList = new ArrayList<>();
		pItemList.add(pItem1);
		pItemList.add(pItem2);

		ServiceItem sItem1 = new ServiceItem()
				.withCode("C123")
				.withDescription("Service Item Desc text")
				.withIsValidForPolicy(true);
		ServiceItem sItem2 = new ServiceItem()
				.withCode("C456")
				.withDescription("Service Item Desc text")
				.withIsValidForPolicy(false);
		List<ServiceItem> sItemList = new ArrayList<>();
		sItemList.add(sItem1);
		sItemList.add(sItem2);

		PracticeItem practiceItem1 = new PracticeItem()
				.withCoPaymentAmount(100.0)
				.withPracticeType(p1)
				.withPharmacyItems(pItemList)
				.withServiceItems(sItemList);

		PracticeItem practiceItem2 = new PracticeItem()
				.withCoPaymentAmount(50.0)
				.withPracticeType(p2)
				.withPharmacyItems(pItemList)
				.withServiceItems(sItemList);

		List<PracticeItem> practiceItemList = new ArrayList<>();
		practiceItemList.add(practiceItem1);
		practiceItemList.add(practiceItem2);

		Links sLinks = new Links().withSelf(new Self().withHref("/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101&page_number=1")).withFirst(new First().withHref("/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101")).withNext(new Next().withHref("/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101&page_number=2")).withPrev(new Prev().withHref("/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101")).withLast(new Last().withHref("/api/v1/claims/serviceItems?effectiveDate=2015-09-14&policyNumber=P1234&practiceTypeCode=EYE101&page_number=3"));

		ServiceItems sp1 = new ServiceItems()
				.withPolicyNumber("P1234")
				.withProviderId("SP123")
				.withPractices(practiceItemList);

		sp1.setLinks(sLinks);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(sp1);

		ExampleFile.write(json, "claims", "get-search-service-item-response.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateClaimRequest()  throws Exception {

		ClaimRequestItem ci1 = new ClaimRequestItem()
				.withCode("39128A")
				.withDateOfService("2015-06-25")
				.withToothId("12A")
				.withPharmacyScriptNumber("12345")
				.withPrescribingDoctor("Dr. Strangelove")
				.withQuantity(12)
				.withChargeAmount(10.0);

		ClaimRequestItem ci2 = new ClaimRequestItem()
				.withCode("40128A")
				.withDateOfService("2015-04-25")
				.withToothId("2B")
				.withPharmacyScriptNumber("67890")
				.withPrescribingDoctor("Dr. Bruce Banner")
				.withQuantity(6)
				.withChargeAmount(30.0);

		List<ClaimRequestItem> ciList = new ArrayList<>();
		ciList.add(ci1);
		ciList.add(ci2);

		ClaimRequest cr = new ClaimRequest()
				.withCategory("ANCILLARY")
				.withPracticeTypeCode("400089276A")
				.withReferenceNumber("REF-00001")
				.withIsBonusClaim(Boolean.FALSE)
				.withAccountPaid(true)
				.withNotionalClaim(false)
				.withPatientMemberId("4000013838A")
				.withProviderNumber("0990111K")
				.withPharmacyName("First Choice Pharmacy Berwick")
				.withItems(ciList)
				.withTotalChargeAmount(40.00)
				.withTotalDiscountAmount(4.0)
				.withPolicyRef(
						new ResourceLink()
								.withId("P1234")
								.withLink("/v1/policies/P1234")
								.withType("policies")
				);


		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(cr);

		ExampleFile.write(json, "claims", "post-submit-claim-request.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateClaimResponse()  throws Exception {

		Links cLinks = new Links().withSelf(new Self().withHref("/api/v1/claims/12345"));

		ClaimResponseItemAssessment claimResItem1 = new ClaimResponseItemAssessment()
				.withCode("001A")
				.withDescription("Item Description 1");
		ClaimResponseItemAssessment claimResItem2 = new ClaimResponseItemAssessment()
				.withCode("002A")
				.withDescription("Item Description 2");
		List <ClaimResponseItemAssessment> claimRespItemAssessList = new ArrayList<>();
		claimRespItemAssessList.add(claimResItem1);
		claimRespItemAssessList.add(claimResItem2);

		ClaimResponseItem ci1 = new ClaimResponseItem()
				.withId("001")
				.withCode("39128A")
				.withDateOfService("2015-06-25")
				.withAssessments(claimRespItemAssessList)
				.withStatus("PROCESSING")
				.withBenefitPaidAmount(25.0)
				.withBonusPaidAmount(50.00);
		ClaimResponseItem ci2 = new ClaimResponseItem()
				.withId("002")
				.withCode("40128A")
				.withDateOfService("2015-04-25")
				.withAssessments(claimRespItemAssessList)
				.withStatus("PAID")
				.withBenefitPaidAmount(25.0)
				.withBonusPaidAmount(50.00);
		List <ClaimResponseItem> claimRespItemList = new ArrayList<>();
		claimRespItemList.add(ci1);
		claimRespItemList.add(ci2);

		ClaimResponse cr = new ClaimResponse()
				.withId("12345")
				.withType("claims")
				.withReferenceNumber("REF-00001")
				.withPayToWho("MEMBER")
				.withStatus("2-PROCESSING")
				.withProcessedDateTime("2002-05-30T09:30:10.000Z")
				.withTotalBonusPaidAmount(100.0)
				.withTotalBenefitPaidAmount(50.0)
				.withTotalPaidAmount(150.0)
				.withItems(claimRespItemList)
				.withPolicyRef(
						new ResourceLink()
								.withId("P1234")
								.withLink("/v1/policies/P1234")
								.withType("policies")
				);
		cr.setLinks(cLinks);


		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(cr);

		ExampleFile.write(json, "claims", "post-submit-claim-response.json");
		assertTrue(json.length()>0);

	}

}
