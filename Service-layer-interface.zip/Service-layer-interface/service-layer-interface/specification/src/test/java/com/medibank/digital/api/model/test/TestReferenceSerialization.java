package com.medibank.digital.api.model.test;

import static org.junit.Assert.assertTrue;

import com.medibank.digital.api.model.*;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class TestReferenceSerialization {

    @Test
    public void generateGetUserResponse() throws JsonProcessingException{

        BankBsbResponse bsbResp = new BankBsbResponse();
        Address address = new Address().withAddressLine1("Shop 20 Forestway Shopping Centre").withTownName("Frenchs Forest").withPostCode("2086").withState("NSW");

        String url = "/api/v1/references/bank/032-123";
        Links links = new Links().withSelf(new Self().withHref(url));

        bsbResp.setType("bank");
        bsbResp.setId("032-132");
        bsbResp.setBsbNum("032-123");
        bsbResp.setName("Westpac Banking Corporation");
        bsbResp.setBranchName("Frenchs Forest");
        bsbResp.setAddress(address);
        bsbResp.setLinks(links);

        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        String json = mapper.writeValueAsString(bsbResp);
        ExampleFile.write(json, "reference", "bankBsbResponse.json");
        assertTrue(json.length() > 0);
    }
}
