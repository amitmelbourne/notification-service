package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.Premiums;
import com.medibank.digital.api.model.Premium;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class TestPremiums {

    private ObjectMapper mapper = MapperFactory.createMapper();

    public static Premiums createSample() {
        Premiums premiums = new Premiums();

        List<Premium> current = Arrays.asList(
                TestPremium.createFullSampleFortnightly(),
                TestPremium.createFullSampleMonthly(),
                TestPremium.createFullSampleQuarterly(),
                TestPremium.createFullSampleYearly()
        );
        premiums.setCurrent(current);

        List<Premium> future = Arrays.asList(
                TestPremium.createFullSampleFortnightly(1),
                TestPremium.createFullSampleMonthly(2),
                TestPremium.createFullSampleQuarterly(6),
                TestPremium.createFullSampleYearly(24)
        );
        premiums.setFuture(future);

        return premiums;
    }

    public static void assertMatch(Premiums expected, Premiums actual) {
        List<Premium> expectedCurrent = expected.getCurrent();
        List<Premium> actualCurrent = actual.getCurrent();
        Assert.assertEquals(expectedCurrent.size(), actualCurrent.size());
        for (int i = 0; i < expectedCurrent.size(); i++) {
            TestPremium.assertMatch(expectedCurrent.get(i), actualCurrent.get(i));
        }

        List<Premium> expectedFuture = expected.getFuture();
        List<Premium> actualFuture = actual.getFuture();
        Assert.assertEquals(expectedFuture.size(), actualFuture.size());
        for (int i = 0; i < expectedFuture.size(); i++) {
            TestPremium.assertMatch(expectedFuture.get(i), actualFuture.get(i));
        }
    }

    @Test
    public void generateExampleFile() throws IOException {
        Premiums premiumsOut = createSample();
        String json = mapper.writeValueAsString(premiumsOut);

        ExampleFile.write(json, "policies", "premiums.json");
        Assert.assertTrue(json.length() > 0);
    }

    @Test
    public void verifyMarshallingRoundTrip() throws IOException {
        Premiums premiumsOut = createSample();
        String json = mapper.writeValueAsString(premiumsOut);

        Premiums premiumsIn = mapper.readValue(json, Premiums.class);
        assertMatch(premiumsOut, premiumsIn);
    }

    @Test
    public void testExampleFile() throws IOException {
        String exampleRoot = "src/main/resources/raml/policies/examples/";
        String json = ExampleFile.read(exampleRoot + "premiums.json");

        Premiums premiums = new ObjectMapper().readValue(json, Premiums.class);

        Assert.assertEquals(4, premiums.getCurrent().size());
        Assert.assertEquals(4, premiums.getFuture().size());

        for (Premium p : premiums.getCurrent()) {
            assertFullPremium(p);
        }

        for (Premium p : premiums.getFuture()) {
            assertFullPremium(p);
        }
    }

    protected static void assertFullPremium(Premium p) {
        Assert.assertNotNull(p.getCoverPeriod());
        Assert.assertNotNull(p.getBaseAmount());
        Assert.assertNotNull(p.getPaymentAmount());
        Assert.assertNotNull(p.getCoverageStartDate());
        Assert.assertNotNull(p.getCoverageEndDate());
        Assert.assertNotNull(p.getDiscountAmount());
        Assert.assertNotNull(p.getLhcAmount());
        Assert.assertNotNull(p.getAgrAmount());
    }
}
