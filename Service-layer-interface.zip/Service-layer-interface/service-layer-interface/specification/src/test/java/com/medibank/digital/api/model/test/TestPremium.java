package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.Premium;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class TestPremium {

    private ObjectMapper mapper = MapperFactory.createMapper();

    public static Premium createPolicySample() {

        Premium premium = new Premium()
					.withCoverPeriod("MONTHLY")
					.withBaseAmount(512.10)
					.withPaymentAmount(345.67);

        return premium;
    }

    public static Premium createFullSampleFortnightly() {
        return createFullSampleFortnightly(0);
    }

    public static Premium createFullSampleFortnightly(int increase) {
        String startDate = "2015-04-15";
        String endDate = "2015-04-30";

		BigDecimal base = new BigDecimal("256.10").add(new BigDecimal(increase));

        Premium premium = new Premium()
			 .withCoverPeriod("FORTNIGHTLY")
			 .withCoverageStartDate(startDate)
			 .withCoverageEndDate(endDate)
			 .withBaseAmount(base.setScale(2, RoundingMode.HALF_UP).doubleValue());
		premium = calculatePayments(premium);

        return premium;
    }

    public static Premium createFullSampleMonthly() {
        return createFullSampleMonthly(0);
    }

    public static Premium createFullSampleMonthly(int increase) {
        String startDate = "2015-04-15";
        String endDate = "2015-05-14";

		BigDecimal base = new BigDecimal("512.10").add(new BigDecimal(increase));

        Premium premium = new Premium()
			 .withCoverPeriod("MONTHLY")
			 .withDeductionDay("14")
			 .withCoverageStartDate(startDate)
			 .withCoverageEndDate(endDate)
			 .withBaseAmount(base.setScale(2, RoundingMode.HALF_UP).doubleValue());

		premium = calculatePayments(premium);

        return premium;
    }

    public static Premium createFullSampleQuarterly() {
        return createFullSampleQuarterly(0);
    }

    public static Premium createFullSampleQuarterly(int increase) {
        String startDate = "2015-04-15";
        String endDate = "2015-07-14";

		BigDecimal base = new BigDecimal("1400.20").add(new BigDecimal(increase));

        Premium premium = new Premium()
			 .withCoverPeriod("QUARTERLY")
			 .withCoverageStartDate(startDate)
			 .withCoverageEndDate(endDate)
			 .withBaseAmount(base.setScale(2, RoundingMode.HALF_UP).doubleValue());

        premium = calculatePayments(premium);

        return premium;
    }

    public static Premium createFullSampleYearly() {
        return createFullSampleYearly(0);
    }

    public static Premium createFullSampleYearly(int increase) {
        String startDate = "2015-04-15";
        String endDate = "2016-04-14";

		BigDecimal base = new BigDecimal("5024.20").add(new BigDecimal(increase));

        Premium premium = new Premium()
			 .withCoverPeriod("YEARLY")
			 .withCoverageStartDate(startDate)
			 .withCoverageEndDate(endDate)
			 .withBaseAmount(base.setScale(2, RoundingMode.HALF_UP).doubleValue());
		premium = calculatePayments(premium);

        return premium;
    }

	private static Premium calculatePayments(Premium p) {
		BigDecimal base = new BigDecimal(p.getBaseAmount());
		BigDecimal disc = base.multiply(new BigDecimal(0.10));
		BigDecimal lhc = base.multiply(new BigDecimal(0.15));
		BigDecimal agr = base.multiply(new BigDecimal(0.30));
		BigDecimal net = base.subtract(disc).add(lhc).subtract(agr);
	 	p.setDiscountAmount(disc.setScale(2,RoundingMode.HALF_UP).doubleValue());
		p.setLhcAmount(lhc.setScale(2,RoundingMode.HALF_UP).doubleValue());
		p.setAgrAmount(agr.setScale(2,RoundingMode.HALF_UP).doubleValue());
		p.setPaymentAmount(net.setScale(2,RoundingMode.HALF_UP).doubleValue());
		return p;
	}

    public static void assertMatch(Premium expected, Premium actual) {
        Assert.assertEquals(expected.getCoverageStartDate(), actual.getCoverageStartDate());
        Assert.assertEquals(expected.getCoverageEndDate(), actual.getCoverageEndDate());
        Assert.assertEquals(expected.getPaymentAmount(), actual.getPaymentAmount());
    }

    @Test
    public void verifyMarshallingRoundTrip() throws IOException {
        Premium premiumOut = createFullSampleMonthly();
        String json = mapper.writeValueAsString(premiumOut);

        Premium premiumIn = mapper.readValue(json, Premium.class);
        assertMatch(premiumOut, premiumIn);
    }
}
