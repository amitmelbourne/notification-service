package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class TestEventsSerialization {
	
	@Test
	public void generateStreamEventlogRequest() throws JsonProcessingException {
		
		Eventlog el = new Eventlog();

		el.setTag("Rate Change Viewed");
		el.setSource("OMS");
		el.setSourceTime("2014-01-01T16:56:54+11:00");
		el.setEntityRef("https://members.medibank.com.au/policies/99981");

		Context ctx = new Context();
		ctx.setAdditionalProperty("userId","c9999@medibank.com.au");
		ctx.setAdditionalProperty("currentRate","180.00");
		ctx.setAdditionalProperty("futureRate","192.00");

		el.setContext(ctx);

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(el);

		ExampleFile.write(json, "events", "eventlogRequest.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateStreamEventlogResponse() throws JsonProcessingException {

		String url = "/api/v1/events/OMS/069d70a8";
		ResourceLink rl = new ResourceLink()
				.withLink(url);

		EventLogResponse elr = new EventLogResponse();

		elr.setId("069d70a8");
		elr.setEventRef(rl);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(elr);

		ExampleFile.write(json, "events", "eventlogResponse.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateStreamEventlogList() throws JsonProcessingException {

		String url = "/api/v1/events/OMS/069d70a8";
		ResourceLink rl = new ResourceLink()
				.withLink(url);

		EventlogList ell = new EventlogList();

		Eventlog el1 = new Eventlog();

		el1.setId("069d70a8");
		el1.setTag("Rate Change Viewed");
		el1.setSource("OMS");
		el1.setSourceTime("2016-01-02T11:56:54+11:00");
		el1.setEntityRef("https://members.medibank.com.au/policies/99971");

		Context ctx1 = new Context();
		ctx1.setAdditionalProperty("userId","c9997@medibank.com.au");
		ctx1.setAdditionalProperty("currentRate","200.00");
		ctx1.setAdditionalProperty("futureRate","220.00");

		el1.setContext(ctx1);

		Eventlog el2 = new Eventlog();

		el2.setId("079d70a8");
		el2.setTag("Rate Change Viewed");
		el2.setSource("OMS");
		el2.setSourceTime("2016-02-01T12:56:54+11:00");
		el2.setEntityRef("https://members.medibank.com.au/policies/99981");

		Context ctx2 = new Context();
		ctx2.setAdditionalProperty("userId","c9998@medibank.com.au");
		ctx2.setAdditionalProperty("currentRate","180.00");
		ctx2.setAdditionalProperty("futureRate","192.00");

		el2.setContext(ctx2);

		Eventlog el3 = new Eventlog();

		el3.setId("099d70a8");
		el3.setTag("Rate Change Viewed");
		el3.setSource("OMS");
		el3.setSourceTime("2016-01-02T13:56:54+11:00");
		el3.setEntityRef("https://members.medibank.com.au/policies/99991");

		Context ctx3 = new Context();
		ctx3.setAdditionalProperty("userId","c9999@medibank.com.au");
		ctx3.setAdditionalProperty("currentRate","330.00");
		ctx3.setAdditionalProperty("futureRate","250.00");

		el3.setContext(ctx3);

		List<Eventlog> evlList = new ArrayList<>();
		evlList.add(el1);
		evlList.add(el2);
		evlList.add(el3);

		ell.setEvents(evlList);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(ell);

		ExampleFile.write(json, "events", "eventlogList.json");
		assertTrue(json.length() > 0);

	}

	@Test
	public void generateStreamEventlogResource() throws JsonProcessingException {

		Eventlog el = new Eventlog();

		el.setId("069d70a8");
		el.setTag("Rate Change Viewed");
		el.setSource("OMS");
		el.setSourceTime("2016-01-02T11:56:54+11:00");
		el.setEntityRef("https://members.medibank.com.au/policies/99971");

		Context ctx = new Context();
		ctx.setAdditionalProperty("userId","c9997@medibank.com.au");
		ctx.setAdditionalProperty("currentRate","200.00");
		ctx.setAdditionalProperty("futureRate","220.00");

		el.setContext(ctx);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(el);

		ExampleFile.write(json, "events", "eventlogResource.json");
		assertTrue(json.length()>0);

	}

	
}
