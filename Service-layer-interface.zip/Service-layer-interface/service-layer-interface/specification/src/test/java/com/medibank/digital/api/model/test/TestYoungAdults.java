package com.medibank.digital.api.model.test;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.youngadults.ValidatePolicyRequest;
import com.medibank.digital.api.model.youngadults.ValidatePolicyResponse;
import com.medibank.digital.api.model.youngadults.YoungAdultForm;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestYoungAdults {

    private static String exampleRoot = "src/main/resources/raml/members/examples/";

    @Test
    public void serializeValidationRequest() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        ValidatePolicyRequest request = new ValidatePolicyRequest()
                .withMembershipNumber("12345679")
                .withFirstName("Peter")
                .withLastName("Griffin")
                .withDateOfBirth("1970-01-01");

        String json = mapper.writeValueAsString(request);
        assertTrue(json.length() > 0);

        ExampleFile.write(json, "YoungAdults", "validationRequest.json");
    }

    @Test
    public void serializeValidationResponse() throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        List<YoungAdultForm> children = new ArrayList<>();
        children.add(
                new YoungAdultForm()
                        .withId("123456789")
                        .withEtag("20160913111545")
                        .withName("Stewie")
                        .withAge(21)
                        .withIsStudent(true)
                        .withEmail("stewie@griffin.com")
                        .withDeclaredBy("12345679")
                        .withLastUpdate("2015-06-25T09:42:00.517Z")
                        .withIntent(YoungAdultForm.Intent.KEEP)
        );

        ValidatePolicyResponse response = new ValidatePolicyResponse()
                .withChildren(children)
                .withRegistered(true)
                .withUpToDate(false);

        String json = mapper.writeValueAsString(response);
        assertTrue(json.length() > 0);

        ExampleFile.write(json, "YoungAdults", "validationResponse.json");
    }

    @Test
    public void parseValidationRequest() throws IOException {
        String json = ExampleFile.read(exampleRoot + "fwac-validate-policy-request-example.json");

        ValidatePolicyRequest request = new ObjectMapper().readValue(json, ValidatePolicyRequest.class);

        assertEquals("Correct membership number", request.getMembershipNumber(),"4100049625");
        assertEquals("Correct first name", request.getFirstName(), "Lois");
        assertEquals("Correct last name", request.getLastName(), "Griffin");
        assertEquals("Correct date of birth", request.getDateOfBirth(), "01/01/1970");
    }

    @Test
    public void parseValidationResponse() throws IOException {
        String json = ExampleFile.read(exampleRoot + "fwac-validate-policy-response-example.json");

        ValidatePolicyResponse response = new ObjectMapper().readValue(json,ValidatePolicyResponse.class);

        assertEquals("Has child data", response.getChildren().size(), 3);
        assertEquals("Correct registered value", response.getRegistered(), false);
        assertEquals("Correct up-to-date value", response.getUpToDate(), false);

        YoungAdultForm firstChild = response.getChildren().get(0);
        assertEquals("Correct BPID", firstChild.getId(), "1000001");
        assertEquals("Correct eTag", firstChild.getEtag(), "20160913111545");
        assertEquals("Correct name", firstChild.getName(), "Chris");
        assertEquals("Correct age",  firstChild.getAge(), new Integer(23));
    }

}
