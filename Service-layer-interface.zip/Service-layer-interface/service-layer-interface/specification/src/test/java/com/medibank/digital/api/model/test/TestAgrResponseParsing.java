package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.AusGovRebate;
import com.medibank.digital.api.model.AusGovRebateResponse;
import com.medibank.digital.api.model.Premiums;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


public class TestAgrResponseParsing {

	private static String exampleRoot = "src/main/resources/raml/policies/examples/";

	@Test
	public void parseUpdateAgrResponse() {
		String json = ExampleFile.read(exampleRoot+"put-agr-response.json");
		assertTrue(json.length()>0);

		try {

			AusGovRebateResponse ausgovRebateResp = new ObjectMapper().readValue(json,AusGovRebateResponse.class);

			AusGovRebate agr = ausgovRebateResp.getAusgovRebate();
			Premiums premiums = ausgovRebateResp.getPremiums();

			assertEquals(agr.getAgrIncomeTier().getIncomeTier(),"2");
			assertEquals(agr.getAgrIncomeTier().getIncomeType(),"1");
			assertEquals(agr.getAgrPercentage(),"5");
			assertEquals(agr.getEffectiveAGR(),"true");
			assertEquals(agr.getRegistrationEffectiveFromDate(),"2015-08-23");
			assertEquals(agr.getRegistrationEffectiveToDate(),"2016-08-23");
			assertEquals(agr.getRegistrationStatus(),"true");

			assertEquals(premiums.getCurrent().get(0).getPaymentAmount(),Double.valueOf(2375.56));
			assertEquals(premiums.getCurrent().get(0).getCoverPeriod(),"MONTHLY");
			assertEquals(premiums.getCurrent().get(0).getCoverageStartDate(),"2015-07-22");
			assertEquals(premiums.getCurrent().get(0).getCoverageEndDate(),"2015-08-22");

			assertEquals(premiums.getFuture().get(0).getPaymentAmount(),Double.valueOf(2500.5));
			assertEquals(premiums.getFuture().get(0).getCoverPeriod(),"MONTHLY");
			assertEquals(premiums.getFuture().get(0).getCoverageStartDate(),"2015-07-22");
			assertEquals(premiums.getFuture().get(0).getCoverageEndDate(),"2015-08-22");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
