package com.medibank.digital.api.model.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.Claim;
import com.medibank.digital.api.model.ClaimsHistory;
import com.medibank.digital.api.model.ClaimsItem;
import com.medibank.digital.api.model.ItemAssessment;

public class TestClaimsHistory {

	private static String exampleRoot = "src/main/resources/raml/claims/examples/";

	@Test
	public void serializeClaimsHistory() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		List<ItemAssessment> itemAssessmentList = new ArrayList<ItemAssessment>();
		ItemAssessment itemAssessment = new ItemAssessment();
        itemAssessment.setCode("Sample Code");
        itemAssessment.setDescription("Sample Description");
        itemAssessmentList.add(itemAssessment);
        
        List<ClaimsItem> claimsItemList = new ArrayList<ClaimsItem>();
        ClaimsItem claimsItem = new ClaimsItem();
        claimsItem.setId("I1234");
        claimsItem.setCode("Sample Item Code");
        claimsItem.setDescription("Sample Description");
        claimsItem.setServiceDate("2015-09-25");
        claimsItem.setStatus("PAID");
        claimsItem.setToothId("Sample Tooth ID");
        claimsItem.setScriptNumber("Sample Script Number");
		claimsItem.setPharmacyName("PharmacyX");
        claimsItem.setPrescribingDoctor("Dr.John ");
        claimsItem.setAssessments(itemAssessmentList);
        claimsItemList.add(claimsItem);
        
        List<Claim> claimList = new ArrayList<Claim>();
        Claim claim = new Claim();
        claim.setId("C11223344");
        claim.setType("MEDICAL");
        claim.setReferenceNumber("Sample Reference Number");
        claim.setStatus("PROCESSING");
        claim.setBonusClaim(true);
        claim.setCompensationDamage(true);
        claim.setBpId("C1234");
        claim.setSourceChannel("OMS");
        
        claim.setItems(claimsItemList);
        claim.setPatientName("JLee");
        claimList.add(claim);
		
		ClaimsHistory claimsHistory = new ClaimsHistory();
		claimsHistory.setClaims(claimList);
		claimsHistory.setMoreRecordsPresent(true);

		String json = null;
		try {
			json = mapper.writeValueAsString(claimsHistory);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "claims", "get-claims-history-response.json");
		assertTrue(json.length()>0);
	}


	@Test
	public void parseClaimsHistory() {
		String json = ExampleFile.read(exampleRoot + "get-claims-history-response.json");

		ClaimsHistory claimsHistory = null;
		try {
			claimsHistory = new ObjectMapper().readValue(json,ClaimsHistory.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		assertTrue(claimsHistory.getClaims().size()>0);
		assertNotNull(claimsHistory.getMoreRecordsPresent());
		assertEquals(claimsHistory.getClaims().get(0).getId(),"235194");
		assertEquals(claimsHistory.getClaims().get(0).getPatientName(),"Fenton Hardy");
		assertEquals(claimsHistory.getClaims().get(0).getItems().get(0).getId(),"1");
		assertEquals(claimsHistory.getClaims().get(0).getItems().get(0).getPharmacyName(),"ABC 3123");
		assertEquals(claimsHistory.getClaims().get(0).getItems().get(0).getAssessments().get(0).getCode(),"0014");
	}
}
