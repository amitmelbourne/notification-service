package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;
import com.medibank.digital.api.model.Error;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestError {

	private static String exampleRoot = "src/main/resources/raml/general/examples/";

	@Test
	public void serializeError() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		Error error = new Error();
		error.setErrorCode("01");
		error.setErrorDescription("The AGR Registration was invalid.");

		List<ErrorDetail> eDetailList = new ArrayList<>();
		ErrorDetail e1 = new ErrorDetail();
		e1.setErrorCode("02");
		e1.setErrorDescription("Invalid Medicare Number");
		e1.setErrorSeverity("HIGH");
		e1.setErrorStackTrace("com.error.ErrorStackTrace");

		ErrorDetail e2 = new ErrorDetail();
		e2.setErrorCode("03");
		e2.setErrorDescription("Invalid Address");
		e2.setErrorSeverity("HIGH");
		e2.setErrorStackTrace("com.error.ErrorStackTrace");

		eDetailList.add(e1);
		eDetailList.add(e2);

		error.setDetails(eDetailList);

		String json = null;
		try {
			json = mapper.writeValueAsString(error);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "general", "error.json");
		ExampleFile.write(json, "policies", "invalidAgrApplication.json");
		assertTrue(json.length()>0);
	}


	@Test
	public void parseError() {
		String json = ExampleFile.read(exampleRoot + "error.json");

		try {
			Error e = new ObjectMapper().readValue(json,Error.class);

			assertEquals(e.getErrorCode(),"01");
			assertEquals(e.getErrorDescription(),"The AGR Registration was invalid.");
			assertEquals(e.getDetails().get(0).getErrorCode(),"02");
			assertEquals(e.getDetails().get(0).getErrorDescription(),"Invalid Medicare Number");
			assertEquals(e.getDetails().get(0).getErrorSeverity(),"HIGH");
			assertEquals(e.getDetails().get(0).getErrorStackTrace(),"com.error.ErrorStackTrace");

			assertEquals(e.getDetails().get(1).getErrorCode(),"03");
			assertEquals(e.getDetails().get(1).getErrorDescription(),"Invalid Address");
			assertEquals(e.getDetails().get(1).getErrorSeverity(),"HIGH");
			assertEquals(e.getDetails().get(1).getErrorStackTrace(),"com.error.ErrorStackTrace");

						
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void serializeProductError() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		Error error = new Error();
		error.setErrorCode("01");
		error.setErrorDescription("The Product ID could not be found or is invalid.");

		String json = null;
		try {
			json = mapper.writeValueAsString(error);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "products", "invalidProductError.json");
		assertTrue(json.length()>0);
	}

	@Test
	public void serializeBsbError() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		Error error = new Error();
		error.setErrorCode("01");
		error.setErrorDescription("The BSB number could not be found or has an invalid format.");

		String json = null;
		try {
			json = mapper.writeValueAsString(error);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "reference", "invalidBsbError.json");
		assertTrue(json.length()>0);
	}
}
