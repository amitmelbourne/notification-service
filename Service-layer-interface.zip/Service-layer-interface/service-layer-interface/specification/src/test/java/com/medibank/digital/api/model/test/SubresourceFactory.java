package com.medibank.digital.api.model.test;

import java.util.UUID;

import com.medibank.digital.api.model.Self;
import com.medibank.digital.api.model.Links;

class SubresourceFactory {

	protected ResourceFactory parent;
	protected String id;

	public SubresourceFactory(ResourceFactory parent) {
		this.parent=parent;
		id="";
	}

	public String generateID() {
		id = UUID.randomUUID().toString();
		id = id.substring(id.length()-8, id.length());
		return id;
	}

	public Links getLinks(String parentType, String subresourceType) {
		String url = "/api/v1/"+parentType
				  			+"/"+parent.getId()+"/"+subresourceType;
		if (id.length()>0) {
			url = url+"/"+id;
		}
		Links links = new Links().withSelf(new Self().withHref(url));
		return links;
	}

}
