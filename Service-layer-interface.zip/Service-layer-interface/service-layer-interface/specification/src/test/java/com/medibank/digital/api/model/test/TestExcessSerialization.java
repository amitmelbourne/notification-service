package com.medibank.digital.api.model.test;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.medibank.digital.api.model.Excess;
import com.medibank.digital.api.model.ExcessResponse;
import com.medibank.digital.api.model.Premium;
import com.medibank.digital.api.model.Premiums;

public class TestExcessSerialization {

    @Test
    public void testUpdateExcess() throws Exception {
        Excess request = new Excess().withCode("EL");
        
        String json = MapperFactory.createMapper().writeValueAsString(request);
        ExampleFile.write(json, "policies", "put-excess-request.json");
        assertTrue(json.length()>0);
    }
    
    @Test
    public void testUpdateExcessResponse() throws Exception {
        List<Premium> currentPremiums = new ArrayList<Premium>();
        currentPremiums.add(
                new Premium()
                        .withPaymentAmount(43.61));

        List<Premium> futurePremiums = new ArrayList<Premium>();
        futurePremiums.add(
                new Premium()
                        .withPaymentAmount(60.61));
        
        ExcessResponse response = new ExcessResponse()
            .withDatePaidTo("2015-09-07")
            .withPremiums(
                    new Premiums()
                    .withCurrent(currentPremiums)
                    .withFuture(futurePremiums));
            
        
        String json = MapperFactory.createMapper().writeValueAsString(response);
        ExampleFile.write(json, "policies", "put-excess-response.json");
        assertTrue(json.length()>0);
    }

}
