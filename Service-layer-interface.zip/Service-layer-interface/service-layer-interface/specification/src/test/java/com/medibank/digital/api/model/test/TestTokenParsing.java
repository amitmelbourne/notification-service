package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by M45129 on 16/07/2015.
 */
public class TestTokenParsing {

    private static String exampleRoot = "src/main/resources/raml/tokens/examples/";

    @Test
    public void testParseCreateTokenRequest() throws Exception {
        String json = ExampleFile.read(exampleRoot + "post-create-token-request.json");
        assertTrue(json.length() > 0);

        CreateTokenRequest createTokenRequest = new ObjectMapper().readValue(json, CreateTokenRequest.class);

        assertEquals(createTokenRequest.getSecret(), "XXDFDFDERERERERERERER");
        TokenProperties tokenProperties = createTokenRequest.getTokenProperties();
        assertTrue(tokenProperties.getAdditionalProperties().containsKey("bpId"));
        assertEquals(tokenProperties.getAdditionalProperties().get("bpId"), "C1234");
    }

    @Test
    public void testParseCreateTokenResponse() throws Exception {
        String json = ExampleFile.read(exampleRoot + "post-create-token-response.json");
        assertTrue(json.length() > 0);

        CreateTokenResponse createTokenResponse = new ObjectMapper().readValue(json, CreateTokenResponse.class);
        assertEquals(createTokenResponse.getToken(), "ab3clj-ere3243-dfldjf3-22");
    }

    @Test
    public void testParseUseTokenRequest() throws Exception {
        String json = ExampleFile.read(exampleRoot + "post-use-token-request.json");
        assertTrue(json.length() > 0);

        UseTokenRequest useTokenRequest = new ObjectMapper().readValue(json, UseTokenRequest.class);
        assertEquals(useTokenRequest.getToken(), "ab3clj-ere3243-dfldjf3-22");
    }

    @Test
    public void testParseUseTokenResponse() throws Exception {
        String json = ExampleFile.read(exampleRoot + "post-use-token-response.json");
        assertTrue(json.length() > 0);

        UseTokenResponse useTokenResponse = new ObjectMapper().readValue(json, UseTokenResponse.class);
        assertEquals(useTokenResponse.getTokenType(), "activate-account");
        TokenProperties tokenProperties = useTokenResponse.getTokenProperties();
        assertTrue(tokenProperties.getAdditionalProperties().containsKey("bpId"));
        assertEquals(tokenProperties.getAdditionalProperties().get("bpId"), "C1234");
    }

    @Test
    public void parseVerifyTokenRequest() throws Exception {

        String json = ExampleFile.read(exampleRoot + "post-verify-token-request.json");
        assertTrue(json.length() > 0);

        VerifyTokenRequest vtr = new ObjectMapper().readValue(json,VerifyTokenRequest.class);
        assertEquals(vtr.getTokenID(),"U3VjaCBpcyBsaWZlLg==");
    }
}
