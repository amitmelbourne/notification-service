package com.medibank.digital.api.model.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.Links;
import com.medibank.digital.api.model.QuoteOption;
import com.medibank.digital.api.model.QuoteOptionCover;
import com.medibank.digital.api.model.QuoteOptionPremium;
import com.medibank.digital.api.model.QuoteRequest;
import com.medibank.digital.api.model.QuoteRequestApplicant;
import com.medibank.digital.api.model.QuoteResponse;
import com.medibank.digital.api.model.Self;

public class TestQuote {

	private static String exampleRoot = "src/main/resources/raml/quotes/examples/";

	@Test
	public void serializeQuoteRequest() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);
	
		QuoteRequest q = new QuoteRequest();
		q.setChannel("RETAIL");
		q.setQuoteNumber("Q12345");
		q.setCommencementDate("2015-06-25");
		q.setScale("COUPLE");
		q.setState("VIC");
		q.setPaymentFrequency("MONTHLY");
		q.setConcessionCode("PENSIONERCARD");
		q.setCorporateAgreementID("345433");
		q.setAgrIncomeType("COUPLE");
		q.setAgrIncomeTier(2);
		
		List<QuoteRequestApplicant> qra = new ArrayList<QuoteRequestApplicant>();
		
		QuoteRequestApplicant husband = new QuoteRequestApplicant();
		husband.setMemberID("C123");
		husband.setDateOfBirth("1980-06-25");
		husband.setApplicantType("MAIN");
		husband.setLhcLoading((double) 10);
		husband.setLhcAgeOfEntry(32);
		
		QuoteRequestApplicant wife = new QuoteRequestApplicant();
		wife.setMemberID("C456");
		wife.setDateOfBirth("1977-06-25");
		wife.setApplicantType("PARTNER");
		wife.setLhcLoading((double) 10);
		wife.setLhcAgeOfEntry(33);		
		
		qra.add(husband);
		qra.add(wife);
		q.setApplicants(qra);
		
		List<QuoteOption> qro = new ArrayList<QuoteOption>();
		
		QuoteOption requestOption1 = new QuoteOption();
		requestOption1.setSelected(true);
		requestOption1.setProductCode("P0001");
		requestOption1.setExcessCode("E06");
		requestOption1.setCampaignID(Arrays.asList("FLYBUYS", "FITBIT"));
		
		QuoteOption requestOption2 = new QuoteOption();
		requestOption2.setSelected(false);
		requestOption2.setProductCode("P0003");
		requestOption2.setExcessCode("E07");
		requestOption2.setCampaignID(Arrays.asList("FITBIT"));
		
		qro.add(requestOption1);
		qro.add(requestOption2);
		q.setOptions(qro);
		
		String json = null;
		try {
			json = mapper.writeValueAsString(q);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "quotes", "quoteRequest.json");
		System.out.println(json);
		assertTrue(json.length()>0);
	}

	@Test
	public void serializeQuoteResponse() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);
		
		String url = "/v1/quotes";
		Links links = new Links().withSelf(new Self().withHref(url));
	
// Create Quote Response	
		QuoteResponse q = new QuoteResponse();
		q.setLinks(links);
		q.setQuoteNumber("Q12345");
		q.setPaymentFrequency("MONTHLY");
		q.setAppliedLHC((double) 10);
		q.setAppliedAGR((double) 5);
		q.setCorporateAgreementID("A12345");
		
//Create Quote Response Option 1	
		QuoteOption qro1 = new QuoteOption();
		qro1.setOptionID("O1234");
		qro1.setSelected(true);
		qro1.setProductCode("P0001");
		qro1.setExcessCode("E06");
		qro1.setCampaignID(Arrays.asList("FLYBUYS", "FITBIT"));
		
// Set Quote Reponse Premiums		
		List<QuoteOptionPremium> qro1p = new ArrayList<QuoteOptionPremium>();
		
		QuoteOptionPremium qro1p1 = new QuoteOptionPremium();
		qro1p1.setPremiumType("CURRENT");
		qro1p1.setDiscount((double) 15);
		qro1p1.setSubsidyAmount((double) 8);
		qro1p1.setLhcLoading((double) 2);
		qro1p1.setAgrAmount((double) 15);
		qro1p1.setNetPrice(155.50);	
		qro1p.add(qro1p1);
		
		QuoteOptionPremium qro1p2 = new QuoteOptionPremium();
		qro1p2.setPremiumType("FUTURE");
		qro1p2.setPremiumStartDate("2015-09-25");
		qro1p2.setDiscount((double) 10);
		qro1p2.setSubsidyAmount((double) 5);
		qro1p2.setLhcLoading((double) 5);
		qro1p2.setAgrAmount((double) 10);
		qro1p2.setNetPrice(155.50);		
		qro1p.add(qro1p2);		
		
		qro1.setPremiums(qro1p);
		
// Set Quote Response Covers		
		List<QuoteOptionCover> qro1c = new ArrayList<QuoteOptionCover>();
		
		QuoteOptionCover qro1c1 = new QuoteOptionCover();
		qro1c1.setCoverID("C100");
		qro1c1.setCoverType("HOSPITAL");
		qro1c1.setPremiumType("CURRENT");
		qro1c1.setPremiumNetPrice(125.50);
	
		qro1c.add(qro1c1);
		
		QuoteOptionCover qro1c2 = new QuoteOptionCover();
		qro1c2.setCoverID("C200");
		qro1c2.setCoverType("EXTRA");
		qro1c2.setPremiumType("FUTURE");
		qro1c2.setPremiumNetPrice(125.50);
	
		qro1c.add(qro1c2);		
		
		qro1.setPremiums(qro1p);		
		qro1.setCover(qro1c);
		
		
//Create Quote Response Option 2	
		QuoteOption qro2 = new QuoteOption();
		qro2.setOptionID("O5678");
		qro2.setSelected(false);
		qro2.setProductCode("P0002");
		qro2.setExcessCode("E07");
		qro2.setCampaignID(Arrays.asList( "FITBIT"));
		
		qro2.setPremiums(qro1p);		
		qro2.setCover(qro1c);

//Add Options to Quote Response
		List<QuoteOption> qro = new ArrayList<QuoteOption>();
		qro.add(qro1);
		qro.add(qro2);
		
		q.setOptions(qro);
		
		
		String json = null;
		try {
			json = mapper.writeValueAsString(q);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "quotes", "quoteResponse.json");
		assertTrue(json.length()>0);
	}

	@Test
	public void parseQuoteRequest() {
		String json = ExampleFile.read(exampleRoot+"quoteRequest.json");

		try {
			QuoteRequest c = new ObjectMapper().readValue(json,QuoteRequest.class);
			
			assertEquals("Correct Channel", c.getChannel(),"RETAIL");
			assertEquals("Correct QuoteNumber", c.getQuoteNumber(),"Q12345");
			assertEquals("Correct commence data", c.getCommencementDate(),"2015-06-25");
			assertEquals("Correct scale",c.getScale(),"COUPLE");
			assertEquals(c.getState(),"VIC");
			assertEquals(c.getPaymentFrequency(),"MONTHLY");
			assertEquals(c.getConcessionCode(),"PENSIONERCARD");
			assertEquals(c.getCorporateAgreementID(),"345433");
			assertEquals(c.getAgrIncomeType(),"COUPLE");
			assertEquals(c.getAgrIncomeTier(),Integer.valueOf(2));
			
			//check applicant details
			assertEquals(c.getApplicants().get(0).getMemberID(),"C123");
			assertEquals(c.getApplicants().get(0).getDateOfBirth(),"1980-06-25");
			assertEquals(c.getApplicants().get(0).getApplicantType(),"MAIN");
			assertEquals(c.getApplicants().get(0).getLhcLoading(),Double.valueOf(10.0));
			assertEquals(c.getApplicants().get(0).getLhcAgeOfEntry(),Integer.valueOf(32));
			
			//check options
			assertEquals(c.getOptions().get(0).getSelected(),Boolean.valueOf(true));
			assertEquals(c.getOptions().get(0).getProductCode(),"P0001");
			assertEquals(c.getOptions().get(0).getExcessCode(),"E06");
			assertEquals(c.getOptions().get(0).getCampaignID().get(0),"FLYBUYS");
			assertEquals(c.getOptions().get(0).getCampaignID().get(1),"FITBIT");

						
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void parseQuoteResponse() {
		String json = ExampleFile.read(exampleRoot+"quoteResponse.json");

		try {
			QuoteResponse c = new ObjectMapper().readValue(json,QuoteResponse.class);
			
			assertEquals("Correct Quote Number", c.getQuoteNumber(),"Q12345");
			assertEquals("Correct Payment Frequency", c.getPaymentFrequency(),"MONTHLY");
			assertEquals("Correct appliedLHC",c.getAppliedLHC(),Double.valueOf(10.0));
			assertEquals("Correct appliedAGR",c.getAppliedAGR(),Double.valueOf(5.0));
			assertEquals("Correct corpAgreementID",c.getCorporateAgreementID(),"A12345");			
			
			//check options
			assertEquals(c.getOptions().get(0).getSelected(),Boolean.valueOf(true));
			assertEquals(c.getOptions().get(0).getProductCode(),"P0001");
			assertEquals(c.getOptions().get(0).getExcessCode(),"E06");
			assertEquals(c.getOptions().get(0).getCampaignID().get(0),"FLYBUYS");
			assertEquals(c.getOptions().get(0).getCampaignID().get(1),"FITBIT");
			
			//check options premium
			assertEquals(c.getOptions().get(0).getPremiums().get(0).getPremiumType(),"CURRENT");
			assertEquals(c.getOptions().get(0).getPremiums().get(0).getDiscount(),Double.valueOf(15.0));
			assertEquals(c.getOptions().get(0).getPremiums().get(0).getSubsidyAmount(),Double.valueOf(8.0));
			assertEquals(c.getOptions().get(0).getPremiums().get(0).getLhcLoading(),Double.valueOf(2.0));
			assertEquals(c.getOptions().get(0).getPremiums().get(0).getAgrAmount(),Double.valueOf(15.0));
			assertEquals(c.getOptions().get(0).getPremiums().get(0).getNetPrice(),Double.valueOf(155.5));
			
			//check options cover
			assertEquals(c.getOptions().get(0).getCover().get(0).getCoverID(),"C100");
			assertEquals(c.getOptions().get(0).getCover().get(0).getCoverType(),"HOSPITAL");
			assertEquals(c.getOptions().get(0).getCover().get(0).getPremiumType(),"CURRENT");
			assertEquals(c.getOptions().get(0).getCover().get(0).getPremiumNetPrice(),Double.valueOf(125.5));
						
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


}
