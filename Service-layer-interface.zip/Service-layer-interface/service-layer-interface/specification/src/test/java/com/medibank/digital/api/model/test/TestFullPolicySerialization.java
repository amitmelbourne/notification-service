package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class TestFullPolicySerialization {


	@Test
	public void GeneratePolicy() {

		Policy p = policyFactory("active","2014-05-21","2015-06-30");

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(p);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "get-policy-individual.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void GeneratePolicyOfFamily() {

		Policy p = policyFactory("active","2014-05-21","2015-06-30");
		List<PolicyMember> members = p.getMembers();

		// Add a second member who is not a payer
		List<String> roles = new ArrayList<String>();
		roles.add("insured");

		Name marySmith = new Name().withFirstName("Mary").withMiddleName("Jane").withLastName("Smith");
		Beneficiary ben = beneficiaryFactory(marySmith);
		PolicyMember m = secondMemberFactory(marySmith,"F","1985-07-12",roles,ben);
		m.setBeneficiary(ben);
		members.add(m);

		// Add a third member who is not a payer
		Name bobby = new Name().withFirstName("Bobby").withLastName("Smith");
		m = thirdMemberFactory(bobby,"M","2004-03-30",roles,ben);
		m.setBeneficiary(ben); //his mum
		members.add(m);

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(p);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "get-policy-family.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void GeneratePolicyWithMultiPayers() {

		PolicyMember m = null;

		Policy p = policyFactory("active","2014-05-21","2015-06-30");
		List<PolicyMember> members = p.getMembers();

		// Adjust the share of the first member
		m = members.get(0);
		Name name = m.getIndividual().getName();
		PolicyPayment pmt = policyPaymentFactory(name,"200","40%",false,"Bank");
		m.setPayment(pmt);

		// Add a second member who is also a payer
		List<String> roles = new ArrayList<String>();
		roles.add("premium payer");
		roles.add("insured");

		Name marySmith = new Name().withFirstName("Mary").withMiddleName("Jane").withLastName("Smith");
		Beneficiary ben = beneficiaryFactory(marySmith);
		pmt = policyPaymentFactory(marySmith,"300","60%",false,"CreditCard");
		m = secondMemberFactory(marySmith,"F","1985-07-12",roles,ben);
		m.setBeneficiary(ben);
		m.setPayment(pmt);
		members.add(m);

		// Add a third member who is not a payer
		roles = new ArrayList<String>();
		roles.add("insured");
		Name bobby = new Name().withFirstName("Bobby").withLastName("Smith");
		m = thirdMemberFactory(bobby,"M","2004-03-30",roles,ben);
		m.setBeneficiary(ben); //his mum
		members.add(m);

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(p);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "get-policy-multipayers.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void GeneratePolicyOfEmployee() {

		Policy p = policyFactory("active","2014-05-21","2015-06-30");
		p.setMasterPolicyID("M12345");

		// Extract the policy member so we can adjust a few things
		List<PolicyMember> members = p.getMembers();

		// TODO: I don't think relationship to employer is required.
		// Payroll account should hold all needed information.
		//
		// Add the relationship to their employer
		ResourceFactory f = new ResourceFactory();
		f.getResource("members");
		//MemberRelationship rel = new MemberRelationship()
				  //.withMemberRef(res)
				  //.withCode("E")
				  //.withEmployeeNumber("12345")
				  //.withEmployeeDepartment("Marketing");
		//m.setRelationship(rel);

		// Adjust the share of the first member
		PolicyMember m = members.get(0);
		Name name = m.getIndividual().getName();
		PolicyPayment pmt = policyPaymentFactory(name,"200","40%",false,"Bank");
		m.setPayment(pmt);

		// Add a second member who is also a payer but not an insured person
		String orgName = "Acme Corp.";
		m = organizationMemberFactory(orgName);
		name = new Name().withFirstName(orgName);
		pmt = policyPaymentFactory(name,"300","60%",false,"Payroll");
		m.setPayment(pmt);
		members.add(m);

		//Add a master policy to the response
		MasterPolicy masterPolicy = new MasterPolicy();

		masterPolicy.setType("masterpolicies");

		masterPolicy.setMasterPolicyName("Policy Name");
        masterPolicy.setMasterPolicyID("M12345");
		masterPolicy.setStatus("ACTIVE");
		masterPolicy.setEffectiveDate("2015-08-23");
		masterPolicy.setBusinessPartnerID("C.TC3.A");
		masterPolicy.setMigrationAgentContractIndicator(false);

		MasterPolicyGroupingCategory mpGroupingCat = new MasterPolicyGroupingCategory();
		mpGroupingCat.setCategoryCode("PARTIAL_SUBSIDY");
		mpGroupingCat.setCategoryDescription("Grouping category description text");
		masterPolicy.setGroupingCategory(mpGroupingCat);

		MasterPolicyDiscountType discountType1 = new MasterPolicyDiscountType();
		discountType1.setComponent("HOSPITAL");
		discountType1.setDiscountCode("H");
		MasterPolicyDiscountType discountType2 = new MasterPolicyDiscountType();
		discountType2.setComponent("EXTRAS");
		discountType2.setDiscountCode("E");
		List<MasterPolicyDiscountType> mpDiscountList = new ArrayList<>();
		mpDiscountList.add(discountType1);
		mpDiscountList.add(discountType2);

		MasterPolicyGenericDiscount mpGenericDiscount = new MasterPolicyGenericDiscount();
		mpGenericDiscount.setMarketableProductOnlyIndicator(false);
		mpGenericDiscount.setDiscountType(mpDiscountList);

		//add Generic Discount
		masterPolicy.setGenericDiscount(mpGenericDiscount);

		//create Subsidy structure
		MasterPolicySubsidy mpSubsidy = new MasterPolicySubsidy();
		mpSubsidy.setSubsidyPercent(Double.valueOf(50));
		mpSubsidy.setSubsidyAmount(Double.valueOf(120.00));
		mpSubsidy.setSubsidyAmountCurrency("AUD");
		mpSubsidy.setSubsidyPercent(Double.valueOf(20));
		mpSubsidy.setPaymentFrequency("MONTHLY");
		mpSubsidy.setIncomeTier(1);
		mpSubsidy.setAllProductSubsidizedIndicator(false);
		mpSubsidy.setLhcSubsidizedIndicator(true);
		mpSubsidy.setFwacSubsidizedIndicator(true);
		mpSubsidy.setExtrasSubsidizedIndicator(true);
		mpSubsidy.setHospitalSubsidizedIndicator(true);

		List<MasterPolicyAvailability> mpAvailabilityList = new ArrayList<>();
		MasterPolicyAvailability mpAvailability1 = new MasterPolicyAvailability();
		MasterPolicyAvailability mpAvailability2 = new MasterPolicyAvailability();
		mpAvailability1.setState("VIC");
		mpAvailability1.setScale("1");
		mpAvailability1.setSubsidyAmount(Double.valueOf(100));
		mpAvailability1.setSubsidyCurrency("AUD");
		mpAvailability2.setState("NSW");
		mpAvailability2.setScale("1");
		mpAvailability2.setSubsidyAmount(Double.valueOf(50));
		mpAvailability2.setSubsidyCurrency("AUD");

		mpAvailabilityList.add(mpAvailability1);
		mpAvailabilityList.add(mpAvailability2);

		mpSubsidy.setAvailability(mpAvailabilityList);

		masterPolicy.setSubsidy(mpSubsidy);

		//create Product Structure
		List<MasterPolicyProduct> mpProductList = new ArrayList<>();
		MasterPolicyProduct product1 = new MasterPolicyProduct();
		product1.setProductCode("P0000001");
		product1.setDeductibleCode("1");
		product1.setDiscountCode("2");
		product1.setSubsidizedIndicator(true);
		MasterPolicyProduct product2 = new MasterPolicyProduct();
		product2.setProductCode("P0000002");
		product2.setDeductibleCode("3");
		product2.setDiscountCode("4");
		product2.setSubsidizedIndicator(true);
		mpProductList.add(product1);
		mpProductList.add(product2);
		masterPolicy.setProduct(mpProductList);

		//create Claim Structure
		MasterPolicyClaim masterPolicyClaim = new MasterPolicyClaim();

		MasterPolicyClawbackLimit masterPolicyClawbackLimit = new MasterPolicyClawbackLimit();
		masterPolicyClawbackLimit.setClawbackLimitCode("1");
		masterPolicyClawbackLimit.setClawbackLimitDescription("Description for the code");
		List<MasterPolicyClawbackLimit> masterPolicyClawbackLimitList = new ArrayList<>();
		masterPolicyClawbackLimitList.add(masterPolicyClawbackLimit);

		MasterPolicyClawback masterPolicyClawback = new MasterPolicyClawback();
		masterPolicyClawback.setClawbackPercent(Double.valueOf(10));
		masterPolicyClawback.setClawbackLimit(masterPolicyClawbackLimitList);
		List<MasterPolicyClawback> masterPolicyClawbackList = new ArrayList<>();
		masterPolicyClawbackList.add(masterPolicyClawback);


		masterPolicyClaim.setClawback(masterPolicyClawbackList);
		masterPolicyClaim.setToleranceDuration(15);
		masterPolicy.setClaim(masterPolicyClaim);

		//create Payment Structure
		MasterPolicyPayment mpPayment = new MasterPolicyPayment();
		List<String> paymentMethods = new ArrayList<>();
		paymentMethods.add("MONTHLY");
		paymentMethods.add("WEEKLY");
		mpPayment.setPaymentType(paymentMethods);

		MasterPolicyFrequency mpFrequency = new MasterPolicyFrequency();
		mpFrequency.setTotalOccurenceNumber(1);
		mpFrequency.setPaymentFrequency("MONTHLY");
		mpFrequency.setFrequencyIntervalValue(1);
		List<String> dDays = new ArrayList<>();
		dDays.add("WED");
		dDays.add("THU");
		mpFrequency.setDeductionDay(dDays);
		mpFrequency.setDeductionDayOfMonth(15);
		mpFrequency.setDeductionMonth("JUNE");
		mpPayment.setFrequency(mpFrequency);

		MasterPolicyValidityPeriod mpValidityPeriod = new MasterPolicyValidityPeriod();
		mpValidityPeriod.setStartDate("2015-03-03");
		mpValidityPeriod.setEndDate("2018-03-03");

		mpPayment.setValidityPeriod(mpValidityPeriod);

		masterPolicy.setPayment(mpPayment);
		masterPolicy.setValidityPeriod(mpValidityPeriod);

        p.setMasterPolicy(masterPolicy);

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(p);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "get-policy-employee.json");
		assertTrue(json.length()>0);

	}

	public static Policy policyFactory(String status, String startDate, String paidDate) {

		// Build the core policy structure
		ResourceFactory f = new ResourceFactory();
		Policy p = new Policy();
		p.setId(f.getId());
		p.setLinks(f.getLinks("policies"));
		p.setStatus(status);
		p.setStartDate(startDate);
		p.setPaidUpToDate(paidDate);
		p.setFuturePolicy(false);
		p.setCoverType("BOTH");
		p.setTotalLHCLoading("10");


		AusGovRebate rebate = new AusGovRebate()
				  						.withEffectiveAGR("true")
										.withRegistrationStatus("true")
										.withAgrPercentage("5")
										.withRegistrationEffectiveFromDate(startDate)
										.withRegistrationEffectiveToDate(paidDate);
		AgrIncomeTier tier = new AgrIncomeTier().withIncomeType("1")
				  						.withIncomeTier("2");
		rebate.setAgrIncomeTier(tier);

		// Create and set members of this policy
		List<PolicyMember> members = new ArrayList<PolicyMember>();
		List<String> roles = new ArrayList<String>();
		roles.add("policy holder");
		roles.add("insured");
		roles.add("premium payer");
		Name name = new Name().withFirstName("John").withMiddleName("Gomer").withLastName("Smith");
		Beneficiary ben = beneficiaryFactory(name);
		PolicyMember m = memberFactory(name,"M","1981-01-15",roles,ben);
		members.add(m);
		p.setMembers(members);

		// Create and set product
		Product prod = productFactory("TOP HOSPITAL 250 EXCESS + BASIC EXTRAS 70",
				  "FAMILY", "VIC");
		p.setProduct(prod);

		// Add premiums
		p.setPremium(TestPremium.createPolicySample());

		// add payment schedule
		p.setPaymentSchedule(TestPayment.generatePaymentSchedule(345.67,5,"2015-09-01",p.getId(),false));

		return p;
	}

	public static Product productFactory(String name, String scale, String state) {
		ResourceFactory f = new ResourceFactory();
		Product p = new Product();
		p.setId(f.getId());
		p.setLinks(f.getLinks("products"));
		p.setName(name);
		p.setScale(scale);
		p.setState(state);
		p.setExcessCode("10");
		p.setAvailability("RETAIL");
		p.setPackage(true);
		p.setLifeCycle("MARKETABLE");

		List<Coverage> list = new ArrayList<Coverage>();
		Coverage c = new Coverage().withCoverTypeCode("CT00001")
				  				.withResidencyType("RESIDENT")
								.withCoverTypeClassification("PRIVATE HEALTH INSURANCE")
								.withContractTypeSubClass("Hospital")
								.withCoverTypeName("BASIC HOSPITAL")
								.withBenefitStructure("70% Claim Back");
		list.add(c);
		p.setCoverage(list);

		return p;
	}


	public static PolicyMember memberFactory(Name name,String gender, String birthDate, List<String> roles, Beneficiary ben) {
		ResourceFactory f = new ResourceFactory();
		PolicyMember p = new PolicyMember();
		p.setId(f.getId());
		p.setLinks(f.getLinks("members"));

		Individual ind = new Individual().withName(name);
		ind.setGender(gender);
		ind.setBirthDate(birthDate);

		p.setIndividual(ind);
		p.setPartyStatus("active");
		p.setPartyType("main");
		p.setPartyRole(roles);
		p.setJoinDate("2013-01-01");
		p.setPensionCardHolderInd(false);

		Lhc lhc = new Lhc().withLhcPercentage("10")
				  				.withBaseCAE("5")
								.withEffectiveCAE("7")
								.withDwhc("0")
								.withPaidHospitalDays("200")
								.withPreviousHospitalEndDate("2009-08-23")
								.withConcessionCode("12345")
								.withConcessionDiscountCode("12345");
		p.setLhc(lhc);
				  			
		Suspension s = new Suspension().withSuspendId("12345")
							 			.withReason("001 - Overseas Travel")
										.withStartDate("2015-08-23")
										.withEndDate("2015-09-23");
		p.setSuspension(s);

		PolicyPayment pmt = policyPaymentFactory(name,"500.00","100%",false,"CreditCard");
		p.setPayment(pmt);
		p.setBeneficiary(ben);

		return p;
	}

	public static PolicyMember secondMemberFactory(Name name,String gender, String birthDate, List<String> roles, Beneficiary ben) {
		ResourceFactory f = new ResourceFactory();
		PolicyMember p = new PolicyMember();
		p.setId(f.getId());
		p.setLinks(f.getLinks("members"));

		Individual ind = new Individual().withName(name);
		ind.setGender(gender);
		ind.setBirthDate(birthDate);

		p.setIndividual(ind);
		p.setPartyStatus("active");
		p.setPartyType("partner");
		p.setPartyRole(roles);
		p.setJoinDate("2013-01-01");
		p.setPensionCardHolderInd(false);
		p.setBeneficiary(ben);

		return p;
	}

	public static PolicyMember thirdMemberFactory(Name name,String gender, String birthDate, List<String> roles, Beneficiary ben) {
		ResourceFactory f = new ResourceFactory();
		PolicyMember p = new PolicyMember();
		p.setId(f.getId());
		p.setLinks(f.getLinks("members"));

		Individual ind = new Individual().withName(name);
		ind.setGender(gender);
		ind.setBirthDate(birthDate);

		p.setIndividual(ind);
		p.setPartyStatus("active");
		p.setPartyType("child");
		p.setPartyRole(roles);
		p.setJoinDate("2013-01-01");
		p.setPensionCardHolderInd(false);
		p.setBeneficiary(ben);

		return p;
	}

	public static PolicyMember organizationMemberFactory(String name) {
		ResourceFactory f = new ResourceFactory();
		PolicyMember p = new PolicyMember();
		p.setId(f.getId());
		p.setLinks(f.getLinks("members"));

		Organization org = new Organization().withCorporateName(name);
		p.setOrganization(org);

		p.setPartyStatus("active");
		p.setPartyType("???");
		List<String> roles = new ArrayList<String>();
		roles.add("premium payer");
		p.setPartyRole(roles);

		return p;
	}

	public static Beneficiary beneficiaryFactory(Name name)
	{
		String holderName = name.getFirstName()+" "+name.getLastName();
		BankAccount acct = AccountFactory.generateBankAccount(holderName);
		Beneficiary b = new Beneficiary()
				  				.withName(name)
								.withAccount(acct);
		return b;
	}

	public static PolicyPayment policyPaymentFactory(Name name, String share, String percent, boolean payRemaining, String acctType)
	{
		PaymentAccount acct = null;
		String paymentMethod = null;
		String holderName = name.getFirstName()+" "+name.getLastName();

		switch (acctType) {
			case "Bank":
				acct = AccountFactory.generateBankAccount(holderName);
				paymentMethod = "BANK";
				break;
			case "CreditCard":
				acct = AccountFactory.generateCreditCardAccount(holderName);
				paymentMethod = "CARD";
				break;
			case "Payroll":
				ResourceFactory f = new ResourceFactory();
				Resource res = f.getResource("members");
				acct = AccountFactory.generatePayrollAccount(res, holderName.trim());
				paymentMethod = "PAYROLL";
				break;
		}

		PolicyPayment payment = new PolicyPayment()
					.withShareAmount(share)
					.withSharePercentage(percent)
					.withPayRemainingAmount(payRemaining)
				    .withPaymentMethod(paymentMethod)
					.withAccount(acct);
		if (acctType.equals("Payroll"))
			payment.setCollectionType("CORPORATE");
		return payment;
	}

}
