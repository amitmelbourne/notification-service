package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.*;

public class TestFullPolicyParsing {

	private static String exampleRoot = "src/main/resources/raml/policies/examples/";

	@Test
	public void parsePolicyIndividual() {
		String json = ExampleFile.read(exampleRoot+"get-policy-individual.json");
		assertTrue(json.length()>0);

		try {
			Policy p = new ObjectMapper().readValue(json,Policy.class);

			assertEquals(p.getFuturePolicy(),Boolean.FALSE);
			assertEquals(p.getCoverType(),"BOTH");
			assertPolicyPremium(p);

			assertEquals(p.getType(),"policies");
			Product prod=p.getProduct();
			assertNotNull(prod);
			assertEquals(prod.getType(),"products");

			List<PolicyMember> members = p.getMembers();
			assertEquals(members.size(),1);
			PolicyMember m = members.get(0);
			assertIsIndividual(m);
			assertHasBeneficiary(m);
			assertPaysWith(m, CreditCardAccount.class);

			PaymentSchedule schedule = p.getPaymentSchedule();
			assertNotNull(schedule);
			int limit = schedule.getLimit();
			int n = schedule.getPayments().size();
			assertEquals(limit,n);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void parsePolicyFamily() {
		String json = ExampleFile.read(exampleRoot+"get-policy-family.json");
		assertTrue(json.length()>0);

		try {
			Policy p = new ObjectMapper().readValue(json,Policy.class);

			assertEquals(p.getFuturePolicy(),Boolean.FALSE);
			assertPolicyPremium(p);

			assertEquals(p.getType(),"policies");
			Product prod=p.getProduct();
			assertNotNull(prod);
			assertEquals(prod.getType(),"products");

			List<PolicyMember> members = p.getMembers();
			assertEquals(members.size(),3);

			for (PolicyMember m : members) {
				assertIsIndividual(m);
				assertHasBeneficiary(m);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return;
	}

	@Test
	public void parsePolicyEmployee() {
		String json = ExampleFile.read(exampleRoot+"get-policy-employee.json");
		assertTrue(json.length()>0);

		try {
			Policy p = new ObjectMapper().readValue(json, Policy.class);

			assertEquals(p.getType(),"policies");
			assertEquals(p.getFuturePolicy(), Boolean.FALSE);
			Product prod=p.getProduct();
			assertNotNull(prod);
			assertEquals(prod.getType(), "products");
			assertPolicyPremium(p);

			List<PolicyMember> members = p.getMembers();
			assertEquals(members.size(), 2);

			PolicyMember m = members.get(0);
			assertIsIndividual(m);
			assertHasBeneficiary(m);
			assertPaysWith(m, BankAccount.class);

			m = members.get(1);
			assertIsOrganization(m);
			assertHasNoBeneficiary(m);
			assertPaysWith(m, PayrollAccount.class);
			assertEquals(m.getPayment().getCollectionType(), "CORPORATE");

            MasterPolicy mPolicy = p.getMasterPolicy();
			assertEquals(mPolicy.getMasterPolicyName(),"Policy Name");
            assertEquals(mPolicy.getMasterPolicyID(),"M12345");
			assertEquals(mPolicy.getStatus(),"ACTIVE");
			assertEquals(mPolicy.getEffectiveDate(),"2015-08-23");
			assertEquals(mPolicy.getBusinessPartnerID(),"C.TC3.A");
			assertEquals(mPolicy.getMigrationAgentContractIndicator(),false);

			assertEquals(mPolicy.getGroupingCategory().getCategoryCode(), "PARTIAL_SUBSIDY");
			assertEquals(mPolicy.getGroupingCategory().getCategoryDescription(),"Grouping category description text");

			assertEquals(mPolicy.getGenericDiscount().getDiscountType().get(0).getComponent(),"HOSPITAL");
			assertEquals(mPolicy.getGenericDiscount().getDiscountType().get(0).getDiscountCode(),"H");
			assertEquals(mPolicy.getGenericDiscount().getDiscountType().get(1).getComponent(),"EXTRAS");
			assertEquals(mPolicy.getGenericDiscount().getDiscountType().get(1).getDiscountCode(),"E");

			assertEquals(mPolicy.getSubsidy().getSubsidyPercent(),Double.valueOf(20));
			assertEquals(mPolicy.getSubsidy().getSubsidyAmount(),Double.valueOf(120.00));
			assertEquals(mPolicy.getSubsidy().getSubsidyAmountCurrency(),"AUD");
			assertEquals(mPolicy.getSubsidy().getSubsidyPercent(),Double.valueOf(20));
			assertEquals(mPolicy.getSubsidy().getPaymentFrequency(),"MONTHLY");
			assertEquals(mPolicy.getSubsidy().getIncomeTier(),Integer.valueOf(1));
			assertEquals(mPolicy.getSubsidy().getAllProductSubsidizedIndicator(),false);
			assertEquals(mPolicy.getSubsidy().getLhcSubsidizedIndicator(),true);
			assertEquals(mPolicy.getSubsidy().getFwacSubsidizedIndicator(),true);
			assertEquals(mPolicy.getSubsidy().getExtrasSubsidizedIndicator(),true);
			assertEquals(mPolicy.getSubsidy().getHospitalSubsidizedIndicator(),true);

			assertEquals(mPolicy.getSubsidy().getAvailability().get(0).getState(),"VIC");
			assertEquals(mPolicy.getSubsidy().getAvailability().get(0).getScale(),"1");
			assertEquals(mPolicy.getSubsidy().getAvailability().get(0).getSubsidyAmount(),Double.valueOf(100));
			assertEquals(mPolicy.getSubsidy().getAvailability().get(0).getSubsidyCurrency(),"AUD");
			assertEquals(mPolicy.getSubsidy().getAvailability().get(1).getState(),"NSW");
			assertEquals(mPolicy.getSubsidy().getAvailability().get(1).getScale(),"1");
			assertEquals(mPolicy.getSubsidy().getAvailability().get(1).getSubsidyAmount(),Double.valueOf(50));
			assertEquals(mPolicy.getSubsidy().getAvailability().get(1).getSubsidyCurrency(),"AUD");

			assertEquals(mPolicy.getProduct().get(0).getProductCode(),"P0000001");
			assertEquals(mPolicy.getProduct().get(0).getDeductibleCode(),"1");
			assertEquals(mPolicy.getProduct().get(0).getDiscountCode(),"2");
			assertEquals(mPolicy.getProduct().get(0).getSubsidizedIndicator(),true);
			assertEquals(mPolicy.getProduct().get(1).getProductCode(),"P0000002");
			assertEquals(mPolicy.getProduct().get(1).getDeductibleCode(),"3");
			assertEquals(mPolicy.getProduct().get(1).getDiscountCode(),"4");
			assertEquals(mPolicy.getProduct().get(1).getSubsidizedIndicator(),true);

			//Test Claim Structure
			assertEquals(mPolicy.getClaim().getClawback().get(0).getClawbackPercent(),Double.valueOf(10));
			assertEquals(mPolicy.getClaim().getClawback().get(0).getClawbackLimit().get(0).getClawbackLimitCode(),"1");
			assertEquals(mPolicy.getClaim().getClawback().get(0).getClawbackLimit().get(0).getClawbackLimitDescription(),"Description for the code");
			assertEquals(mPolicy.getClaim().getToleranceDuration(), Integer.valueOf(15));

			//Test Payment Structure
			assertEquals(mPolicy.getPayment().getPaymentType().get(0),"MONTHLY");
			assertEquals(mPolicy.getPayment().getPaymentType().get(1),"WEEKLY");

			assertEquals(mPolicy.getPayment().getFrequency().getTotalOccurenceNumber(), Integer.valueOf(1));
			assertEquals(mPolicy.getPayment().getFrequency().getPaymentFrequency(),"MONTHLY");
			assertEquals(mPolicy.getPayment().getFrequency().getFrequencyIntervalValue(),Integer.valueOf(1));
			assertEquals(mPolicy.getPayment().getFrequency().getDeductionDay().get(0),"WED");
			assertEquals(mPolicy.getPayment().getFrequency().getDeductionDay().get(1),"THU");
			assertEquals(mPolicy.getPayment().getFrequency().getDeductionDayOfMonth(),Integer.valueOf(15));
			assertEquals(mPolicy.getPayment().getFrequency().getDeductionMonth(),"JUNE");
			assertEquals(mPolicy.getPayment().getValidityPeriod().getStartDate(),"2015-03-03");
			assertEquals(mPolicy.getPayment().getValidityPeriod().getEndDate(),"2018-03-03");

			//Test Validity Period
			assertEquals(mPolicy.getValidityPeriod().getStartDate(),"2015-03-03");
			assertEquals(mPolicy.getValidityPeriod().getEndDate(),"2018-03-03");

		} catch (IOException e) {
			e.printStackTrace();
		}
		return;
	}

	@Test
	public void parsePolicyMultiPayers() {
		String json = ExampleFile.read(exampleRoot+"get-policy-multipayers.json");
		assertTrue(json.length()>0);

		try {
			Policy p = new ObjectMapper().readValue(json,Policy.class);

			assertEquals(p.getType(),"policies");
			assertEquals(p.getFuturePolicy(),Boolean.FALSE);
			Product prod=p.getProduct();
			assertNotNull(prod);
			assertEquals(prod.getType(),"products");
			assertPolicyPremium(p);

			List<PolicyMember> members = p.getMembers();
			assertEquals(members.size(),3);

			for (int idx=0; idx<3; idx++) {
				PolicyMember m = members.get(idx);
				assertIsIndividual(m);
				assertHasBeneficiary(m);

				switch (idx) {
					case 0:
						assertPaysWith(m, BankAccount.class);
						assertEquals("main",m.getPartyType());
						break;	
					case 1:
						assertPaysWith(m, CreditCardAccount.class);
						assertEquals("partner",m.getPartyType());
						break;	
					case 2:
						assertDoesntPay(m);
						assertEquals("child",m.getPartyType());
						break;	
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return;
	}

	protected static void assertIsIndividual(PolicyMember m) {
		assertEquals(m.getType(),"members");
		Individual ind = m.getIndividual();
		assertNotNull(ind);
		assertNotNull(ind.getName());
		assertNotNull(ind.getGender());
		assertNotNull(ind.getBirthDate());
		assertNull(m.getOrganization());
		return;
	}

	protected static void assertIsOrganization(PolicyMember m) {
		assertEquals(m.getType(),"members");
	 	Organization org = m.getOrganization();
		assertNotNull(org);
		assertNotNull(org.getCorporateName());
		assertNull(m.getIndividual());
		return;
	}

	protected static void assertPaysWith(PolicyMember m, Class clazz) {
		PolicyPayment pmt = m.getPayment();
		assertNotNull(pmt);
		PaymentAccount acct = pmt.getAccount();
		assertNotNull(pmt.getPaymentMethod());
		assertTrue(acct.getClass().equals(clazz));
		assertHasRole(m, "premium payer");
		return;
	}

	protected static void assertDoesntPay(PolicyMember m) {
		PolicyPayment pmt = m.getPayment();
		assertNull(pmt);
		assertExcludesRole(m, "premium payer");
		return;
	}

	protected static void assertHasBeneficiary(PolicyMember m) {
		Beneficiary ben = m.getBeneficiary();
		assertNotNull(ben);
		assertNotNull(ben.getName());
		PaymentAccount ba = ben.getAccount();
		assertNotNull(ba);
		assertTrue(ba instanceof BankAccount);
		assertHasRole(m, "insured");
		return;
	}

	protected static void assertHasNoBeneficiary(PolicyMember m) {
		assertNull(m.getBeneficiary());
		return;
	}

	protected static void assertHasRole(PolicyMember m, String role) {
		List<String> roles = m.getPartyRole();
		boolean match = false;
		for (String r : roles) {
			if (r.equals(role)) {
				match = true;
				break;
			}
		}
		assertTrue(match);
	}

	protected static void assertExcludesRole(PolicyMember m, String role) {
		List<String> roles = m.getPartyRole();
		boolean match = false;
		for (String r : roles) {
			if (r.equals(role)) {
				match = true;
				break;
			}
		}
		assertFalse(match);
	}

	protected static void assertPolicyPremium(Policy p) {
		Premium prem = p.getPremium();
		assertNotNull(prem.getCoverPeriod());
		assertNotNull(prem.getBaseAmount());
		assertNotNull(prem.getPaymentAmount());
		assertNull(prem.getCoverageStartDate());
		assertNull(prem.getCoverageEndDate());
		assertNull(prem.getDiscountAmount());
		assertNull(prem.getLhcAmount());
		assertNull(prem.getAgrAmount());
	}
}
