package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class TestAgrRegistrationRequestSerialization {

	@Test
	public void generateAgrRegistrationRequest() {

		AgrRegistrationRequest agrRegistrationRequest = new AgrRegistrationRequest();

		AgrIncomeTier tier = new AgrIncomeTier().withIncomeType("1")
				.withIncomeTier("2");

		agrRegistrationRequest.setLodgementDate("2015-08-23");
		agrRegistrationRequest.setEndDate("2018-08-23");

		agrRegistrationRequest.setAgrIncomeTier(tier);

		agrRegistrationRequest.setUserCovered(true);
		agrRegistrationRequest.setAllMembersOnMedicare(true);
		agrRegistrationRequest.setReadAndUnderstand(true);

		
		//create agrApplicant
		AgrApplicant agrApplicant = new AgrApplicant();
		agrApplicant.setMemberIndicator("MEMBER");
		agrApplicant.setApplicantEndDate("2015-08-13");
		agrApplicant.setApplicantStartDate("2018-08-13");

		//create agrApplicant Name
		Name agrName1 = new Name().withFirstName("Sam").withMiddleName("J").withLastName("Customer");
		Name agrName2 = new Name().withFirstName("Jane").withMiddleName("S").withLastName("Customer");

		//create agrApplicant Individual
		Individual agrIndividual = new Individual();
		agrIndividual.setBirthDate("1980-08-13");
		agrIndividual.setGender("MALE");
		agrIndividual.setName(agrName1);
		agrIndividual.setMedicareNumber("12345678");
		agrIndividual.setMedicareIRN(1234);

		//create agrApplicant Address
		Address agrAddress1 = new Address();
		agrAddress1.setAddressLine1("Unit 1");
		agrAddress1.setAddressLine2("19 Fred Rd.");
		agrAddress1.setTownName("Melbourne");
		agrAddress1.setPostCode("3000");
		agrAddress1.setState("VIC");

		//set Applicant for agrRequest
		agrApplicant.setIndividual(agrIndividual);
		agrApplicant.setResidentialAddress(agrAddress1);
		agrApplicant.setMailingAddress(agrAddress1);
		agrRegistrationRequest.setApplicant(agrApplicant);

		Phone phone = new Phone();
		phone.setCountryCode("61");
		phone.setPhoneNumber("0411111111");
		agrApplicant.setPhone(phone);

		//create agrRequest Members

		//create Individual Structures 1 an 2
		Individual agrIndividualMember1 = new Individual();
		agrIndividualMember1.setBirthDate("1980-08-13");
		agrIndividualMember1.setGender("MALE");
		agrIndividualMember1.setName(agrName1);

		Individual agrIndividualMember2 = new Individual();
		agrIndividualMember2.setBirthDate("1982-08-13");
		agrIndividualMember2.setGender("FEMALE");
		agrIndividualMember2.setName(agrName2);

		AgrApplicantMember agrMember1 = new AgrApplicantMember();
		agrMember1.setDependantIndicator("ADULT");
		agrMember1.setApplicantStartDate("2015-08-13");
		agrMember1.setApplicantEndDate("2018-08-13");
		agrMember1.setIndividual(agrIndividualMember1);

		AgrApplicantMember agrMember2 = new AgrApplicantMember();
		agrMember2.setDependantIndicator("DEPENDENT");
		agrMember2.setApplicantStartDate("2015-08-13");
		agrMember2.setApplicantEndDate("2018-08-13");
		agrMember2.setIndividual(agrIndividualMember2);

		List<AgrApplicantMember> agrMemberList = new ArrayList<>();
		agrMemberList.add(agrMember1);
		agrMemberList.add(agrMember2);

		//set members for agrRequest
		agrRegistrationRequest.setMembers(agrMemberList);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(agrRegistrationRequest);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "post-agr-registration-request.json");
		assertTrue(json.length()>0);

	}
}
