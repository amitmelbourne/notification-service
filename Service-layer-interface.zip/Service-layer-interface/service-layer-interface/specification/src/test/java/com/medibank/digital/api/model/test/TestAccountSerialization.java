package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class TestAccountSerialization {

	@Test
		 public void RegisterAccountBenefitsRequest() {

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		ResourceLink policy = new ResourceLink()
				.withId("778899")
				.withType("policies");

		BankAccount acct = AccountFactory.generateBankAccount("John Smith");

		PostAccountForBenefits post = new PostAccountForBenefits();
		post.setAccount(acct);
		post.setPolicyRef(policy);

		String json = null;
		try {
			json = mapper.writeValueAsString(post);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "members", "post-account-benefits-example.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void RegisterChequeAccountBenefitsRequest() {

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		ResourceLink policy = new ResourceLink()
				.withId("778899")
				.withType("policies");

		ChequeAccount acct = new ChequeAccount().withPayByCheque(true);

		PostAccountForBenefits post = new PostAccountForBenefits();
		post.setAccount(acct);
		post.setPolicyRef(policy);

		String json = null;
		try {
			json = mapper.writeValueAsString(post);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "members", "post-cheque-account-benefits-example.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void RegisterDirectDebitRequest() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		ResourceLink policy = new ResourceLink()
				  .withId("778899")
				  .withType("policies");

		BankAccount acct = AccountFactory.generateBankAccount("John Smith");

		PostAccountForDirectDebit post = new PostAccountForDirectDebit();
		post.setAccount(acct);
		post.setPolicyRef(policy);

		String json = null;
		try {
			json = mapper.writeValueAsString(post);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "members", "post-bankaccount-directdebit-example.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void RegisterCreditCardPaymentRequest() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		ResourceLink policy = new ResourceLink()
				  .withId("778899")
				  .withType("policies");


		CreditCardAccount acct = AccountFactory.generateCreditCardAccount("John Smith");

		PostAccountForDirectDebit post = new PostAccountForDirectDebit();
		post.setAccount(acct);
		post.setPolicyRef(policy);


		String json = null;
		try {
			json = mapper.writeValueAsString(post);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "members", "post-creditcard-directdebit-example.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void GetAccountsResponse() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		List<PaymentAccount> list = new ArrayList<PaymentAccount>();

		CreditCardAccount cc = AccountFactory.generateCreditCardAccount("John smith");
		list.add(cc);

		BankAccount ba = AccountFactory.generateBankAccount("John Smith");
		list.add(ba);

		AccountList accountList = new AccountList();
		accountList.setAccounts(list);

		String json = null;
		try {
			json = mapper.writeValueAsString(accountList);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		System.out.println(json);
		ExampleFile.write(json, "members", "accountList.json");
		assertTrue(json.length()>0);

	}

}
