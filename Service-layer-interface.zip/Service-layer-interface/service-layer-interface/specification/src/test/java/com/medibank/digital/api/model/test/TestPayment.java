package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.Payment;
import com.medibank.digital.api.model.PaymentRequest;
import com.medibank.digital.api.model.PaymentResponse;
import com.medibank.digital.api.model.ResourceLink;
import com.medibank.digital.api.model.PaymentSchedule;
import java.util.List;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;

/**
 * Test parsing and serialisation of PaymentRequest and PaymentResponse objects
 * Created by Simon Collins on 9/07/2015.
 */
public class TestPayment {

    @Test
    public void serialiseCardRequest() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);


        PaymentRequest paymentRequest = new PaymentRequest()
                .withCardHolderName("Testy tester")
                .withPolicyRef(
                        new ResourceLink()
                            .withId("P1234")
                            .withLink("/v1/policies/P1234")
                            .withType("policies")
                );

        String json = mapper.writeValueAsString(paymentRequest);
		ExampleFile.write(json, "payments", "paymentRequest.json");

        assertTrue("Correct JSON contents", json.contains("Testy tester") && json.contains("P1234"));
    }

    @Test
    public void parseCardRequest() throws Exception {
        String exampleRoot = "src/main/resources/raml/payments/examples/";
        String json = ExampleFile.read(exampleRoot + "paymentRequest.json");
        System.out.println("Parse Payment Request:" + json);

        PaymentRequest paymentRequest = new ObjectMapper().readValue(json, PaymentRequest.class);

        assertEquals("Correct policyID", "P12345", paymentRequest.getPolicyRef().getId());
        assertEquals("Correct order number", "ON123456", paymentRequest.getOrderNum());
    }

    @Test
    public void serialiseCardResponse() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        PaymentResponse paymentResponse = new PaymentResponse()
                .withCardHolderName("Testy tester")
                .withPolicyRef(
                        new ResourceLink()
                                .withId("P1234")
                                .withLink("/policies/P1234")
                                .withType("policies")
                );

        String json = mapper.writeValueAsString(paymentResponse);
	ExampleFile.write(json, "payments", "paymentResponse.json");

        assertTrue("Correct JSON contents", json.contains("Testy tester") && json.contains("P1234"));
    }

    @Test
    public void parseCardResponse() throws Exception {
        String exampleRoot = "src/main/resources/raml/payments/examples/";
        String json = ExampleFile.read(exampleRoot + "paymentResponse.json");

        PaymentResponse paymentResponse = new ObjectMapper().readValue(json, PaymentResponse.class);

        assertEquals("Correct policyID", "P12345", paymentResponse.getPolicyRef().getId());
        assertEquals("Correct order number", "ON123456", paymentResponse.getOrderNum());
    }

    @Test
    public void serialisePaymentSchedule() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

		PaymentSchedule schedule = generatePaymentSchedule(256.78, 5, "2015-09-01", "P12345",true);

        String json = mapper.writeValueAsString(schedule);
		ExampleFile.write(json, "payments", "paymentSchedule.json");
    }

    @Test
    public void parsePaymentSchedule() throws Exception {
        String exampleRoot = "src/main/resources/raml/payments/examples/";
        String json = ExampleFile.read(exampleRoot + "paymentSchedule.json");

        PaymentSchedule schedule = new ObjectMapper().readValue(json, PaymentSchedule.class);

		int limit=schedule.getLimit();
		List<Payment> list = schedule.getPayments();
		assertEquals(list.size(), limit);
		assertNotNull(schedule.getPolicyRef());
		assertNotNull(schedule.getEndDate());

    }

	public static PaymentSchedule generatePaymentSchedule(Double amount, int limit, String endDate, String policyNumber, boolean includePolicyRef) {
		ResourceLink policy = new ResourceLink()
								.withId(policyNumber)
								.withType("policies")
								.withLink("/v1/policies/"+policyNumber);

		PaymentSchedule schedule = new PaymentSchedule()
						.withEndDate(endDate)
						.withLimit(limit);
		if (includePolicyRef) {
			schedule.setPolicyRef(policy);
		}
		List<Payment> list = PaymentFactory.generatePaymentList(amount,limit);
		schedule.setPayments(list);
		return schedule;
	}
}
