package com.medibank.digital.api.model.test;

import com.medibank.digital.api.model.Payment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.Calendar;
import java.util.GregorianCalendar;


public class PaymentFactory{

	protected static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss+10:00");


	public static Payment generatePayment(Double amount, Date start, Date paidTo) {
		Payment p = new Payment()
				  		.withStatus("Paid")
						.withTransactionType("Payment")
				  		.withPaymentAmount(amount)
						.withTransactionDate(sdf.format(start))
						.withPaymentMethod("Direct Debit")
						.withCoverageStartDate(sdf.format(start))
						.withCoverageEndDate(sdf.format(paidTo));
		return p;
	}

	public static List<Payment> generatePaymentList(Double amount, int repeats) {
		List<Payment> list = new ArrayList<Payment>();

		GregorianCalendar cal = new GregorianCalendar();

		for (int idx=0;idx<repeats;idx++) {
			Date to = cal.getTime();
			cal.add(Calendar.MONTH, 1);
			Date from = cal.getTime();
			Payment p = generatePayment(amount, from, to);
			list.add(p);
		}

		return list;
	}

}

