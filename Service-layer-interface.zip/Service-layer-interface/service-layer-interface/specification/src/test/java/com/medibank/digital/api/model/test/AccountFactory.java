package com.medibank.digital.api.model.test;

import com.medibank.digital.api.model.Resource;
import com.medibank.digital.api.model.BankAccount;
import com.medibank.digital.api.model.PayrollAccount;
import com.medibank.digital.api.model.CreditCardAccount;

public class AccountFactory{

	public static BankAccount generateBankAccount(String holderName) {

		// BankAccount extends PaymentAccount & Resource,
		// the .withXXX() methods don't work because the generators
		// return the base class.
		BankAccount acct = new BankAccount();
	  	acct.setId("123456");
	  	acct.setBsb("123-456");
	  	acct.setAccountNum("123456");
	  	acct.setAccountHolderName(holderName);
		return acct;

	}

	public static PayrollAccount generatePayrollAccount(Resource employer, String employerName) {

		// PayrollAccount extends PaymentAccount & Resource,
		// the .withXXX() methods don't work because the generators
		// return the base class.
		PayrollAccount acct = new PayrollAccount();
		acct.setEmployerRef(employer);
		acct.setEmployerName(employerName);
		acct.setEmployeeNumber("12345");
		acct.setEmployeeDepartment("Marketing");
		return acct;

	}

	public static CreditCardAccount generateCreditCardAccount(String holderName) {

		// CreditCardAccount extends PaymentAccount & Resource,
		// the .withXXX() methods don't work because the generators
		// return the base class.
		CreditCardAccount acct = new CreditCardAccount();
		acct.setId("123457");
	  	acct.setCardRefID("fhskdjhgsdgh");
	  	acct.setCardType("VISA");
	  	acct.setCardHolderName(holderName);
	  	acct.setPaymentCardID("123457");
	  	acct.setCardToken("****-******-0789");
	  	acct.setCardExpiry("03/16");

		return acct;

	}

}
