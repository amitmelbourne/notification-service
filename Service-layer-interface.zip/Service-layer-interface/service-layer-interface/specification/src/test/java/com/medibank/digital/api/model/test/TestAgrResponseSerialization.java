package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import static java.util.Collections.singletonList;
import static org.junit.Assert.assertTrue;

public class TestAgrResponseSerialization {

	@Test
	public void generateUpdateAGRResponse() {

		AusGovRebateResponse rebateResponse = new AusGovRebateResponse();

		Premium current = new Premium();
		current.setCoverPeriod("FORTNIGHTLY");
		current.setCoverageStartDate("2015-07-22");
		current.setCoverageEndDate("2015-08-10");
		current.setPaymentAmount(2450.50);

		Premium future = new Premium();
		future.setCoverPeriod("FORTNIGHTLY");
		future.setCoverageStartDate("2015-07-22");
		future.setCoverageEndDate("2015-08-10");
		future.setPaymentAmount(2500.50);

		Premiums premiums = new Premiums();
		premiums.setCurrent(singletonList(current));
		premiums.setFuture(singletonList(future));


		AusGovRebate agr = new AusGovRebate()
				.withEffectiveAGR("true")
				.withRegistrationStatus("true")
				.withAgrPercentage("5")
				.withRegistrationEffectiveFromDate("2015-08-23")
				.withRegistrationEffectiveToDate("2016-08-23");

		AgrIncomeTier tier = new AgrIncomeTier().withIncomeType("1")
				.withIncomeTier("2");
		agr.setAgrIncomeTier(tier);

		rebateResponse.setAusgovRebate(agr);
		rebateResponse.setPremiums(premiums);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = null;
		try {
			json = mapper.writeValueAsString(rebateResponse);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "put-agr-response.json");
		assertTrue(json.length()>0);

	}
}
