package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.CorrespondenceItem;
import com.medibank.digital.api.model.CorrespondenceList;
import com.medibank.digital.api.model.correspondence.*;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestCorrespondence {

	private static String exampleRoot = "src/main/resources/raml/members/examples/";

	@Test
	public void renderCorrespondenceList() {
	
		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		List<CorrespondenceItem> list = new ArrayList<CorrespondenceItem>();
		for (int idx=0;idx<5;idx++) {
			list.add(TestCorrespondence.generateItem());
		}

		CorrespondenceList corrList = new CorrespondenceList();
		corrList.setItems(list);

		String json = null;
		try {
			json = mapper.writeValueAsString(corrList);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		assertTrue(json.length()>0);
		ExampleFile.write(json, "members", "get-correspondence.json");
	
	}

	@Test
	public void parseCorrespondenceList() {
		String json = ExampleFile.read(exampleRoot+"get-correspondence.json");
		//System.out.println(json);

		try {
			CorrespondenceList cl = new ObjectMapper().readValue(json,CorrespondenceList.class);
			List<CorrespondenceItem> list = cl.getItems();
			assertEquals(list.size(),5);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void renderCorrespondenceDocument() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		Correspondence correspondence = new Correspondence();
		Document document = new Document();
		Insert insert = new Insert();

		Content documentContent = new Content();
		documentContent.setType("pdf");
		documentContent.setSize(new Size().withUnit("Bytes").withValue(420));
		documentContent.setData("base64;U28gbG9uZyBhbmQgdGhhbmtzIGZvciBhbGwgdGhlIGZpc2gh");

		Content insertContent = new Content();
		insertContent.setType("pdf");
		insertContent.setSize(new Size().withUnit("Kilobytes").withValue(1024));
		insertContent.setData("base64;U28gc2FkIHRoYXQgaXQgc2hvdWxkIGNvbWUgdG8gdGhpcw==");

		Content insertPreviewContent = new Content();
		insertPreviewContent.setType("png");
		insertPreviewContent.setData("base64;V2UgdHJpZWQgdG8gd2FybiB5b3UgYWxsLCBidXQgb2ggZGVhci4uLg==");

		correspondence.setId("1000154864735483");
		correspondence.setDocument(document);
		correspondence.setInserts(Arrays.asList(insert));

		document.setId("06448640654");
		document.setName("Tax Statement");
		document.setPublished("01/06/2016");
		document.setPages(2);
		document.setContent(documentContent);

		insert.setId("06458640692");
		insert.setClientKey("34842387");
		insert.setName("Tax Statement Information Insert");
		insert.setFilename("/path/to/tax_insert_2016_06_01_0001.pdf");
		insert.setPages(6);
		insert.setDisabled(false);
		insert.setContent(insertContent);
		insert.setPreview(insertPreviewContent);

		String json = null;
		try {
			json = mapper.writeValueAsString(correspondence);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		assertTrue(json.length() > 0);
	}

	@Test
	public void parseCorrespondenceDocument() {
		String json = ExampleFile.read(exampleRoot + "retrieve-document-example.json");

		try {
			Correspondence correspondence = new ObjectMapper().readValue(json, Correspondence.class);

			Document document    = correspondence.getDocument();
			List<Insert> inserts = correspondence.getInserts();

			assertEquals(correspondence.getId(), "1000154864735483");
			assertEquals(document.getContent().getType(), "pdf");
			assertEquals(document.getContent().getData(), "base64;U28gbG9uZyBhbmQgdGhhbmtzIGZvciBhbGwgdGhlIGZpc2gh");
			assertEquals(document.getContent().getSize().getValue().intValue(), 420);
			assertEquals(inserts.size(), 1);

			Insert insert = inserts.get(0);
			assertEquals(insert.getContent().getType(), "pdf");
			assertEquals(insert.getPreview().getType(), "png");
			assertEquals(insert.getContent().getData(), "base64;U28gc2FkIHRoYXQgaXQgc2hvdWxkIGNvbWUgdG8gdGhpcw==");
			assertEquals(insert.getPreview().getData(), "base64;V2UgdHJpZWQgdG8gd2FybiB5b3UgYWxsLCBidXQgb2ggZGVhci4uLg==");

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static CorrespondenceItem generateItem() {
	
		ResourceFactory f1 = new ResourceFactory();
		SubresourceFactory f2 = new SubresourceFactory(f1);
		CorrespondenceItem item = new CorrespondenceItem()
				  .withTimestamp("2015-03-01T09:04:08.00+10:00")
				  .withStatus("TBD")
				  .withTypeCode("W01")
				  .withDescription("Dunno whatever")
				  .withChannelId("email");
		item.setId(f2.generateID());
		item.setLinks(f2.getLinks("members","correspondence"));
		return item;
	}
}


