package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.Excess;
import com.medibank.digital.api.model.Excesses;
import com.medibank.digital.api.model.BonusBalance;
import com.medibank.digital.api.model.BonusBalances;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestBonusBalances {

	private static String exampleRoot = "src/main/resources/raml/policies/examples/";

	@Test
	public void serializeBonusBalances() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		BonusBalances bbResponse = new BonusBalances();
		BonusBalance b1 = new BonusBalance().withBalance(100.00).withCode("BAL001").withDescription("Remaining Balance Description");
		BonusBalance b2 = new BonusBalance().withBalance(790.00).withCode("BAL002").withDescription("Remaining Balance Description");
		BonusBalance b3 = new BonusBalance().withBalance(20.00).withCode("BAL003").withDescription("Remaining Balance Description");

		List<BonusBalance> bbList= new ArrayList<>();
		bbList.add(b1);
		bbList.add(b2);
		bbList.add(b3);
		bbResponse.setBonusBalances(bbList);

		String json = null;
		try {
			json = mapper.writeValueAsString(bbResponse);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "get-bonus-balances-response.json");
		assertTrue(json.length()>0);
	}


	@Test
	public void parseBonusBalances() {
		String json = ExampleFile.read(exampleRoot + "get-bonus-balances-response.json");

		BonusBalances bb = null;
		try {
			bb = new ObjectMapper().readValue(json,BonusBalances.class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		assertEquals(bb.getBonusBalances().get(0).getCode(),"BAL001");
		assertEquals(bb.getBonusBalances().get(0).getDescription(),"Remaining Balance Description");
		assertEquals(bb.getBonusBalances().get(0).getBalance(),Double.valueOf(100.00));
		assertEquals(bb.getBonusBalances().get(1).getCode(),"BAL002");
		assertEquals(bb.getBonusBalances().get(1).getDescription(),"Remaining Balance Description");
		assertEquals(bb.getBonusBalances().get(1).getBalance(),Double.valueOf(790.00));
		assertEquals(bb.getBonusBalances().get(2).getCode(),"BAL003");
		assertEquals(bb.getBonusBalances().get(2).getDescription(),"Remaining Balance Description");
		assertEquals(bb.getBonusBalances().get(2).getBalance(),Double.valueOf(20.00));
	}
}
