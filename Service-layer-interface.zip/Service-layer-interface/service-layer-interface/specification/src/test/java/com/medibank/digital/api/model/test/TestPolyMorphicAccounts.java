package com.medibank.digital.api.model.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import com.medibank.digital.api.model.BankAccount;
import com.medibank.digital.api.model.CreditCardAccount;
import com.medibank.digital.api.model.Resource;
import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.PaymentAccount;
import com.medibank.digital.api.model.PayrollAccount;

public class TestPolyMorphicAccounts {


	@Test
	public void bankAccount() {

		ObjectMapper mapper = new ObjectMapper();

		try{

			BankAccount ba = new BankAccount();
		  	ba.setId("123456");
		  	ba.setBsb("123-456");
		  	ba.setAccountNum("123456");
		  	ba.setAccountHolderName("John Smith");
	
			String json = mapper.writeValueAsString(ba);
			System.out.println(json);
			PaymentAccount result = mapper.readValue(json,PaymentAccount.class);
			assertTrue(result instanceof BankAccount);
			BankAccount ba2 = (BankAccount) result;

			assertEquals(ba.getAccountNum(),ba2.getAccountNum());
			assertEquals(ba.getBsb(),ba2.getBsb());
			assertEquals(ba.getAccountHolderName(),ba2.getAccountHolderName());
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void cardAccount() {

		ObjectMapper mapper = new ObjectMapper();
		try{

			CreditCardAccount cc = new CreditCardAccount();
			cc.setCardRefID("1234567");
			cc.setCardExpiry("03/17");
			cc.setCardToken("***-****-***-789");
			cc.setCardHolderName("John Q. Smith");
			cc.setCardType("VISA");
	
			String json = mapper.writeValueAsString(cc);
			System.out.println(json);
			PaymentAccount result = mapper.readValue(json,PaymentAccount.class);
			assertTrue(result instanceof CreditCardAccount);
			CreditCardAccount cc2 = (CreditCardAccount) result;
			
			assertEquals(cc.getCardExpiry(),cc2.getCardExpiry());
			assertEquals(cc.getCardToken(),cc2.getCardToken());
			// etc...

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void payrollAccount() {

		ObjectMapper mapper = new ObjectMapper();
		try{
			ResourceFactory f = new ResourceFactory();
			Resource res = f.getResource("members");
			PayrollAccount acct = new PayrollAccount();
			acct.setEmployerRef(res);
			acct.setEmployerName("ACME Inc.");
			acct.setEmployeeNumber("12345");
			acct.setEmployeeDepartment("Marketing");
	
			String json = mapper.writeValueAsString(acct);
			System.out.println(json);
			PayrollAccount result = mapper.readValue(json,PayrollAccount.class);
			assertTrue(result instanceof PayrollAccount);
			PayrollAccount acct2 = (PayrollAccount) result;
			
			assertEquals(acct.getEmployeeDepartment(),acct2.getEmployeeDepartment());
			assertEquals(acct.getEmployerName(),acct2.getEmployerName());
			// etc...
		} catch (IOException e) {
			e.printStackTrace();
		}
	
	}
}
