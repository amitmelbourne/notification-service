package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.api.model.*;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;


public class TestAgrRegistrationRequestParsing {

	private static String exampleRoot = "src/main/resources/raml/policies/examples/";

	@Test
	public void parseAgrRegistrationRequest() {
		String json = ExampleFile.read(exampleRoot+"post-agr-registration-request.json");
		assertTrue(json.length()>0);

		try {
			AgrRegistrationRequest agrRegistrationRequest = new ObjectMapper().readValue(json, AgrRegistrationRequest.class);

			AgrIncomeTier tier = agrRegistrationRequest.getAgrIncomeTier();


			assertEquals(tier.getIncomeTier(),"2");
			assertEquals(tier.getIncomeType(),"1");


			assertEquals(agrRegistrationRequest.getLodgementDate(),"2015-08-23");
			assertEquals(agrRegistrationRequest.getEndDate(),"2018-08-23");

			assertEquals(agrRegistrationRequest.getUserCovered(), true);
			assertEquals(agrRegistrationRequest.getAllMembersOnMedicare(), false);
			assertNull(agrRegistrationRequest.getReadAndUnderstand());

			AgrApplicant agrApplicant = agrRegistrationRequest.getApplicant();
			assertEquals(agrApplicant.getMemberIndicator(),"MEMBER");
			assertEquals(agrApplicant.getApplicantEndDate(),"2015-08-13");
			assertEquals(agrApplicant.getApplicantStartDate(), "2018-08-13");

			Individual agrIndividual = agrApplicant.getIndividual();
			assertEquals(agrIndividual.getBirthDate(),"1980-08-13");
			assertEquals(agrIndividual.getGender(),"MALE");
			assertEquals(agrIndividual.getName().getFirstName(),"Sam");
			assertEquals(agrIndividual.getName().getMiddleName(),"J");
			assertEquals(agrIndividual.getName().getLastName(), "Customer");
			assertEquals(agrIndividual.getMedicareNumber(),"12345678");
			assertEquals(agrIndividual.getMedicareIRN(),Integer.valueOf(1234));
			assertEquals(agrIndividual.getMedicareValidTo(),"2020-01-01");

			Address agrAddress1 = agrApplicant.getResidentialAddress();
			assertEquals(agrAddress1.getAddressLine1(),"Unit 1");
			assertEquals(agrAddress1.getAddressLine2(),"19 Fred Rd.");
			assertEquals(agrAddress1.getTownName(),"Melbourne");
			assertEquals(agrAddress1.getPostCode(),"3000");
			assertEquals(agrAddress1.getState(), "VIC");

			List<AgrApplicantMember> agrMemberList =  agrRegistrationRequest.getMembers();
			AgrApplicantMember agrMember1 = agrMemberList.get(0);
			AgrApplicantMember agrMember2 = agrMemberList.get(1);

			assertEquals(agrMember1.getDependantIndicator(),"ADULT");
			assertEquals(agrMember1.getApplicantStartDate(),"2015-08-13");
			assertEquals(agrMember1.getApplicantEndDate(),"2018-08-13");

			assertEquals(agrMember2.getDependantIndicator(),"DEPENDENT");
			assertEquals(agrMember2.getApplicantStartDate(),"2015-08-13");
			assertEquals(agrMember2.getApplicantEndDate(), "2018-08-13");

			Individual agrIndividualMember1 = agrMember1.getIndividual();
			Individual agrIndividualMember2 = agrMember2.getIndividual();

			assertEquals(agrIndividualMember1.getBirthDate(),"1980-08-13");
			assertEquals(agrIndividualMember1.getGender(),"MALE");
			assertEquals(agrIndividualMember1.getName().getFirstName(),"Sam");
			assertEquals(agrIndividualMember1.getName().getMiddleName(),"J");
			assertEquals(agrIndividualMember1.getName().getLastName(), "Customer");

			assertEquals(agrIndividualMember2.getBirthDate(),"1982-08-13");
			assertEquals(agrIndividualMember2.getGender(),"FEMALE");
			assertEquals(agrIndividualMember2.getName().getFirstName(),"Jane");
			assertEquals(agrIndividualMember2.getName().getMiddleName(),"S");
			assertEquals(agrIndividualMember2.getName().getLastName(), "Customer");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
