package com.medibank.digital.api.model.test;

import static org.junit.Assert.assertTrue;

import com.medibank.digital.api.model.*;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class TestUserSerialization {

	@Test
	public void generateActivateRequest() throws JsonProcessingException {

		ActivateRequest ar = new ActivateRequest();

		ar.setTokenID("U3VjaCBpcyBsaWZlLg==");

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(ar);

		ExampleFile.write(json, "users", "activateRequest.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateActivateResponse() throws JsonProcessingException {

		ActivateResponse ar = new ActivateResponse();

		ar.setTokenID("U3VjaCBpcyBsaWZlLg==");

		String url = "/api/v1/users/user@test.com/nextStep";

		Links nextLink = new Links().withNext(new Next().withHref(url).withTitle("Next"));

		ar.setLinks(nextLink);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(ar);

		ExampleFile.write(json, "users", "activateResponse.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateCredentialsRequest() throws JsonProcessingException {

		CredentialsRequest cr = new CredentialsRequest();

		cr.setTokenID("U3VjaCBpcyBsaWZlLg==");
		cr.setPassword("newPassword");

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(cr);

		ExampleFile.write(json, "users", "credentialsRequest.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateCredentialsResponse() throws JsonProcessingException {

		CredentialsResponse cr = new CredentialsResponse();

		cr.setTokenID("U3VjaCBpcyBsaWZlLg==");

		String url = "/api/v1/users/user@test.com/nextStep";

		Links nextLink = new Links().withNext(new Next().withHref(url).withTitle("Next"));

		cr.setLinks(nextLink);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(cr);

		ExampleFile.write(json, "users", "credentialsResponse.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateConfirmEmailRequest() throws JsonProcessingException {

		ConfirmEmailRequest cer = new ConfirmEmailRequest();

		cer.setTokenID("U3VjaCBpcyBsaWZlLg==");

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(cer);

		ExampleFile.write(json, "users", "confirmEmailRequest.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateVerifyTokenRequest() throws JsonProcessingException {

		VerifyTokenRequest vtr= new VerifyTokenRequest();

		vtr.setTokenID("U3VjaCBpcyBsaWZlLg==");

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(vtr);

		ExampleFile.write(json, "users", "verifyTokenRequest.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateConfirmEmailResponse() throws JsonProcessingException {

		ConfirmEmailResponse cer = new ConfirmEmailResponse();


		String url = "/api/v1/users/user@test.com/nextStep";

		Links nextLink = new Links().withNext(new Next().withHref(url).withTitle("Next"));

		cer.setLinks(nextLink);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(cer);

		ExampleFile.write(json, "users", "confirmEmailResponse.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateChangeUsername() throws JsonProcessingException {

		ChangeUsernameRequest cu = new ChangeUsernameRequest();

		cu.setNewUsername("newUser@test.com");

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(cu);

		ExampleFile.write(json, "users", "changeUsernameRequest.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateGetUserResponse() throws JsonProcessingException {

		GetUsernameResponse user = new GetUsernameResponse();

		user.setUsername("testy_tester@medibank.com.au");
		user.setErrorCode("0");

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(user);

		ExampleFile.write(json, "users", "getUsernameResponse.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateRegisterUserRequest() throws JsonProcessingException {

		RegisterUserRequest ur = new RegisterUserRequest();

		ur.setDob("2015-06-07");
		ur.setEmail("testy_tester@medibank.com.au");
		ur.setFirstName("Sam");
		ur.setLastName("Customer");
		ur.setPolicyNum("POL123");
		ur.setPassword("ssshhhhh");
		ur.setEmailOverride(true);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(ur);

		ExampleFile.write(json, "users", "registerUserRequest.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateRecoverPasswordRequest() throws JsonProcessingException {

		PasswordRecovery pr = new PasswordRecovery();

		pr.setUsername("testy_tester@medibank.com.au");

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(pr);

		ExampleFile.write(json, "users", "requestPasswordRecovery.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateChangePasswordRequest() throws JsonProcessingException {

		PasswordChange pcr = new PasswordChange();

		pcr.setOldPassword("oldPassword");
		pcr.setNewPassword("newPassword");


		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(pcr);

		ExampleFile.write(json, "users", "requestPasswordChange.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateResetPasswordRequest() throws JsonProcessingException {

		ResetPasswordRequest rpr = new ResetPasswordRequest();

		rpr.setTokenID("U3VjaCBpcyBsaWZlLg==");

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(rpr);

		ExampleFile.write(json, "users", "resetPasswordRequest.json");
		assertTrue(json.length()>0);

	}

	@Test
	public void generateResetPasswordResponse() throws JsonProcessingException {

		ResetPasswordResponse rpr = new ResetPasswordResponse();

		rpr.setTokenID("U3VjaCBpcyBsaWZlLg==");

		String url = "/api/v1/users/user@test.com/nextStep";

		Links nextLink = new Links().withNext(new Next().withHref(url).withTitle("Next"));

		rpr.setLinks(nextLink);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(rpr);

		ExampleFile.write(json, "users", "resetPasswordResponse.json");
		assertTrue(json.length()>0);

	}



	@Test
	public void generateMigrationStatusResponse() throws JsonProcessingException {

		MigrationStatus msResp = new MigrationStatus().withMigrated(true);

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(msResp);
		ExampleFile.write(json, "reference", "get-migration-status-response.json");
		assertTrue(json.length() > 0);
	}

	@Test
	public void generateRecoverPasswordResponse() throws JsonProcessingException {

		RecoverPasswordResponse recoverPass = new RecoverPasswordResponse();


		String url = "/api/v1/users/user@test.com/nextStep";

		Links nextLink = new Links().withNext(new Next().withHref(url).withTitle("Next"));

		recoverPass.setLinks(nextLink);
		recoverPass.setUsername("Xdfd334334ssddf");

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		String json = mapper.writeValueAsString(recoverPass);

		ExampleFile.write(json, "users", "recoverPasswordResponse.json");
		assertTrue(json.length()>0);

	}

}
