package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.medibank.digital.api.model.MemberSummary;
import com.medibank.digital.api.model.PolicySummaryList;
import org.junit.Test;

import java.util.List;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;

import com.medibank.digital.api.model.PolicySummary;
import com.medibank.digital.api.model.ProductSummary;

public class TestPolicyParsing {

	private static String exampleRoot = "src/main/resources/raml/policies/examples/";

	@Test
	public void parsePolicyList() {
		String json = ExampleFile.read(exampleRoot+"policiesList.json");
		assertTrue(json.length()>0);

		try {
			PolicySummaryList psl = new ObjectMapper().readValue(json,PolicySummaryList.class);
			List<PolicySummary> list = psl.getPolicies();
			assertEquals(list.size(),3);

			for (PolicySummary p : list) {
				assertEquals(p.getType(),"policies");
				assertEquals(p.getFuturePolicy(),Boolean.FALSE);
				ProductSummary prod=p.getProduct();
				assertNotNull(prod);
				assertEquals(prod.getType(),"products");
				MemberSummary m=p.getMember();
				assertNotNull(m);
				assertEquals(m.getType(),"members");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
