package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.Excess;
import com.medibank.digital.api.model.Excesses;
import org.junit.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TestExcesses {

	private static String exampleRoot = "src/main/resources/raml/policies/examples/";

	@Test
	public void serializeExcesses() {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		Excesses excesses = new Excesses();

		Excess e1 = new Excess();
		Excess e2 = new Excess();
		Excess e3 = new Excess();
		Excess e4 = new Excess();

		e1.setCode("EX01");
		e2.setCode("EX02");
		e3.setCode("EX03");
		e4.setCode("EX04");

		e1.setDescription("$100 Excess on Hospital stays");
		e1.setSubsidised(true);
		e1.setMarketable(true);
		e2.setDescription("$200 Excess on Hospital stays");
		e2.setSubsidised(false);
		e2.setMarketable(false);
		e3.setDescription("$300 Excess on Hospital stays");
		e4.setDescription("$400 Excess on Hospital stays");
		e4.setSubsidised(true);
		e4.setMarketable(false);

		List<Excess> eList = new ArrayList<>();
		eList.add(e1);
		eList.add(e2);
		eList.add(e4);

		excesses.setCurrent(e3);
		excesses.setChoice(eList);
		excesses.setUpdateable(true);

		String json = null;
		try {
			json = mapper.writeValueAsString(excesses);
		} catch (JsonProcessingException e) {
			e.printStackTrace();

		}
		ExampleFile.write(json, "policies", "get-excess-response.json");
		assertTrue(json.length()>0);
	}


	@Test
	public void parseExcesses() {
		String json = ExampleFile.read(exampleRoot + "get-excess-response.json");

		try {
			Excesses e = new ObjectMapper().readValue(json,Excesses.class);

			assertEquals(e.getCurrent().getCode(),"EX03");
			assertEquals(e.getCurrent().getDescription(),"$300 Excess on Hospital stays");

			assertEquals(e.getChoice().get(0).getCode(),"EX01");
			assertEquals(e.getChoice().get(0).getDescription(),"$100 Excess on Hospital stays");
			assertEquals(e.getChoice().get(0).getSubsidised(),Boolean.valueOf(true));
			assertEquals(e.getChoice().get(0).getMarketable(),Boolean.valueOf(true));
			assertEquals(e.getChoice().get(1).getCode(),"EX02");
			assertEquals(e.getChoice().get(1).getDescription(),"$200 Excess on Hospital stays");
			assertEquals(e.getChoice().get(1).getSubsidised(),Boolean.valueOf(false));
			assertEquals(e.getChoice().get(1).getMarketable(),Boolean.valueOf(false));
			assertEquals(e.getChoice().get(2).getCode(),"EX04");
			assertEquals(e.getChoice().get(2).getDescription(),"$400 Excess on Hospital stays");
			assertEquals(e.getChoice().get(2).getSubsidised(),Boolean.valueOf(true));
			assertEquals(e.getChoice().get(2).getMarketable(),Boolean.valueOf(false));

			assertEquals(e.getUpdateable(),Boolean.valueOf(true));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
