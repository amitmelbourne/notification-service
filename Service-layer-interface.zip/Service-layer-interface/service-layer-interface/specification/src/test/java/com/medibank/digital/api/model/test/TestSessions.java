package com.medibank.digital.api.model.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;

import com.medibank.digital.api.model.LoginResponse;
import com.medibank.digital.api.model.UserCredentials;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class TestSessions {

	private static String exampleRoot = "src/main/resources/raml/sessions/examples/";

	@Test
		 public void serializeLoginRequest() throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		UserCredentials userCreds = new UserCredentials().withPassword("Test123.").withUsername("testy_tester@medibank.com.au");

		String json = mapper.writeValueAsString(userCreds);

		assertTrue(json.length()>0);
		ExampleFile.write(json, "sessions", "loginRequest.json");
	}

	@Test
	public void serializeLoginResponse() throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();	  
		mapper.enable(SerializationFeature.INDENT_OUTPUT);

		LoginResponse userCreds = new LoginResponse().withCustomerId("C12345").withSessionId("1c59ba1f-9ffb-45b8-a320-70b93bbbd5dd");
		
		String json = mapper.writeValueAsString(userCreds);

		assertTrue(json.length()>0);
		ExampleFile.write(json, "sessions", "loginResponse.json");
	}

	@Test
	public void parseLoginRequest() throws IOException {
		String json = ExampleFile.read(exampleRoot+"userCredentials.json");

			UserCredentials userCreds = new ObjectMapper().readValue(json,UserCredentials.class);
			
			assertEquals("Correct username", userCreds.getUsername(),"jrocket@example.com");
			assertEquals("Correct password", userCreds.getPassword(),"foobarbaz");
	}

	@Test
	public void parseLoginResponse() throws IOException {
		String json = ExampleFile.read(exampleRoot+"loginResponse.json");

			LoginResponse loginResp = new ObjectMapper().readValue(json,LoginResponse.class);
			
			assertEquals("Correct sessionId", loginResp.getSessionId(),"1c59ba1f-9ffb-45b8-a320-70b93bbbd5dd");
			assertEquals("Correct customerId", loginResp.getCustomerId(),"C12345");

	}

}
