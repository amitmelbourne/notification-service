package com.medibank.digital.api.model.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.medibank.digital.api.model.CardRequest;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Test card request payload parsing (<code>cardRequest.json</code> schema)
 * Created by Simon Collins on 2/07/2015.
 */
public class TestCardRequest {

    @Test
    public void serialiseCardRequest() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        CardRequest cardRequest = new CardRequest()
                .withNumberOfCards(4)
                .withRequestReason("Extra card required");

        String json = mapper.writeValueAsString(cardRequest);
	ExampleFile.write(json, "policies", "post-card-request.json");

        assertTrue("Correct JSON contents", json.contains("Extra card required") && json.contains("4"));
    }

    @Test
    public void parseCardRequest() throws Exception {
        String exampleRoot = "src/main/resources/raml/policies/examples/";
        String json = ExampleFile.read(exampleRoot + "post-card-request.json");
        System.out.println("Parse Card Request:" + json);

        CardRequest cardRequest = new ObjectMapper().readValue(json, CardRequest.class);

        assertEquals("Correct number of cards", Integer.valueOf(2), cardRequest.getNumberOfCards());
        assertEquals("Correct request reason", "Lost Card", cardRequest.getRequestReason());
    }
}
