## API Services Layer

This project is a repository for API specifications as implemented in the API Gateway.

# RAML

The RAML specifications define REST APIs, and are located in:

`src/main/resources/raml`

# Maven

Maven is used to convert RAML specifications into JAX-RS implementations.

# RAML upload to portal

- Install php (for command line use)
- Install node.js
- Install newman by running "npm install -g newman". Details can be found here - https://www.npmjs.com/package/newman

- Run service-layer-interface\specification\package_apis.bash . This will produce a file called newman_input.json in service-layer-interface\specification\target\api-spec
- Run service-layer-interface\automate-raml-upload.bash (Replace the correct values in the script or pass the right values if running via bamboo)

# Documentation
- Install node.js
- `npm install raml2html@3.0` https://www.npmjs.com/package/raml2html
- `raml2html claims.raml > claims.html`