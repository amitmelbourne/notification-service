#!/bin/bash

## Script to upload RAML for an API.

usage="$(basename "$0") [-h] [-a -v] 

where:
    -h  show this help text
    -a  set the name of the API for which the file (RAML in this case) needs to be uploaded; for e.g. Medibank API
    -v  set the version of the API; for e.g. 1.0"


if [ $# -eq 0 ];
then
    echo "$usage" >&2
    exit 1
fi

while getopts 'a:v:h' option; do
  case "$option" in
    h) echo "$usage"
       exit 1
       ;;
    a) api=$OPTARG
       ;;
    v) version=$OPTARG
       ;;
    :) printf "missing argument for -%s\n" "$OPTARG" >&2
       echo "$usage" >&2
       exit 1
       ;;
  esac
done

if [ -z "${api}" ] || [ -z "${version}" ]; then
    echo "$usage" >&2
    exit 1
fi

#------INPUT (check these values before running the script----------------------------------------------------------------------------
export PORTAL_URL='https://anypoint.mulesoft.com'
export PORTAL_ORGANIZATION_ID='850e4e9c-a553-456c-9715-faffc7f1d3e2'
export PORTAL_USERNAME='<username>'
export PORTAL_PASSWORD='<password>'
export RAML_NAME='medibank.raml'
export RAML_LOCATION='<location>'
export PROXY='http://ausydisa02.au.imckesson.com:8080'
#-------------------------------------------------------------------------------------------------------------------------------------

export API_NAME="$api"
export API_VERSION="$version"

python upload_raml.py