Upload RAML for an API
----------------------
1) Make sure all the data is correct in the INPUT section of the run-local.bash script
2) Run the command using
   ./run-local.bash -a "<API name>" -v "<API version>"
   For example
   ./run-local.bash -a "Medibank API" -v "1.0"