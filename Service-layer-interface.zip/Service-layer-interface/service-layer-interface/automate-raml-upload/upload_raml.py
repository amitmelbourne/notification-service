#!/usr/bin/python

# Script to apply policies to an API

import requests, sys, json, os, time

_baseUrl = os.environ['PORTAL_URL']
_organizationId= os.environ['PORTAL_ORGANIZATION_ID']
_url=_baseUrl + '/apiplatform/repository/v2/organizations/' + _organizationId
_username = os.environ['PORTAL_USERNAME']
_password = os.environ['PORTAL_PASSWORD']
_apiName = os.environ['API_NAME']
_apiVersion = os.environ['API_VERSION']
_proxy  = os.environ['PROXY']
_ramlName  = os.environ['RAML_NAME']
_ramlLocation = os.environ['RAML_LOCATION']

proxyDict = { 
              "http"  : _proxy, 
              "https" : _proxy
            }


def throwException( resource , statusCode):
   sys.exit('	Error: Status code = ' + str(statusCode) + ' returned for resource ' + resource)


#----------------------------------------------------------------------------------------------
print ('Task 1: Authenticate user: ' + _username)

resource ='/accounts/login'
body = {'username': _username, 'password': _password}
response = requests.post(_baseUrl + resource, data=body, proxies=proxyDict)


if response.status_code != 200:
	throwException(resource = 'POST ' + resource, statusCode = response.status_code)

data = response.json()
authToken = data['token_type'] + ' ' + data['access_token']

#----------------------------------------------------------------------------------------------
print ('Task 2: Retrieve the API details for ' + _apiName + ' and version ' + _apiVersion)
resource ='/apis?query=' + _apiName
headers = {'Authorization': authToken}
response = requests.get(_url + resource, headers=headers, proxies=proxyDict)


if response.status_code != 200:
	throwException(resource = 'GET ' + resource, statusCode = response.status_code)

data = response.json()
apiId = ''
apiVersionId = ''

for api in data['apis']:
	if api['name'] == _apiName:
		for version in api['versions']:
			if version['name'] == _apiVersion:
				apiId = str(version['apiId'])
				apiVersionId = str(version['id'])

if apiId == '' or apiVersionId == '':
	print ('	Error: API details not found for the given input.')
	sys.exit()

#----------------------------------------------------------------------------------------------
print ('Task 3: Retrieve the files for ' + _apiName + ' and version ' + _apiVersion)
resource ='/apis/' + apiId + '/versions/' + apiVersionId + '/files'
headers = {'Authorization': authToken}
response = requests.get(_url + resource, headers=headers, proxies=proxyDict)


if response.status_code != 200:
	throwException(resource = 'GET ' + resource, statusCode = response.status_code)

data = response.json()

fileId=''
filePath=''

for files in data:
	if (str(files['apiVersionId']) == apiVersionId and files['name'] == _ramlName):
		fileId = str(files['id'])
		filePath = str(files['path'])

if fileId == '':
	print ('	Error: No file found for the given input.')
	sys.exit()
#----------------------------------------------------------------------------------------------
print ('Task 4: Upload the RAML for ' + _apiName + ' and version ' + _apiVersion + ' based on the input')

with open(_ramlLocation + _ramlName, 'rb') as myfile:
    data = myfile.read().replace('\n', '\n')

resource ='/apis/' + apiId + '/versions/' + apiVersionId + '/files/' + fileId

headers = {'Authorization': authToken, 'content-type': 'application/json'}
body = {'id': fileId, 'apiVersionId': apiVersionId, 'isDirectory': False, 'apiId': apiId, 'name': _ramlName, 'path': filePath, 'data': data}

response = requests.put(_url + resource, headers=headers, data=json.dumps(body), proxies=proxyDict)

if response.status_code != 200:
	print ('	Error: Status Code ' + str(response.status_code) + ' returned while uploading RAML ')
else:
	print ('	RAML ' + _ramlName + ' successfully uploaded')

	
#----------------------------------------------------------------------------------------------
print ('Task 5: Logout user: ' + _username)

resource ='/accounts/api/logout'
headers = {'Authorization': authToken}
response = requests.get(_baseUrl + resource, headers=headers, proxies=proxyDict)


if response.status_code != 200:
	throwException(resource = 'GET ' + resource, statusCode = response.status_code)

#----------------------------------------------------------------------------------------------