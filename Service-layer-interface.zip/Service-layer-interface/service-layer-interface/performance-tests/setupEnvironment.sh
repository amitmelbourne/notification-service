#!/bin/bash

JMETER_INSTALL_DIR="${USER}/apache-jmeter-3.0"

if [ ! -d "$JMETER_INSTALL_DIR" ]; then
    wget -nv http://apache.uberglobalmirror.com/jmeter/binaries/apache-jmeter-3.0.tgz
    tar xfz ./apache-jmeter-3.0.tgz -C ~
fi
