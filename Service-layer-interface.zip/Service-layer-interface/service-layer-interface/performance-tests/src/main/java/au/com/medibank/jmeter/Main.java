package au.com.medibank.jmeter;

public class Main {
    public static void main(String [] args) throws Exception{
        String url = null;
        if (args.length  != 1) {
            url= "api-dev01-nprd.digidev-aws.medibank.local";
        }
        else {
            url = args[0];
        }
        System.out.println(ApiGatewayHelper.getApiToken(url).trim());
    }
}
