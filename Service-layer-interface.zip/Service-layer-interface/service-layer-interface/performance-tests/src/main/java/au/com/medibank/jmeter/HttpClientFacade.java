package au.com.medibank.jmeter;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.SSLContext;
import java.security.NoSuchAlgorithmException;

public class HttpClientFacade {

    private HttpHost target;

    private HttpClientFacade() {
    }

    public static HttpClientFacade createInstance(HttpHost target) {
        HttpClientFacade authTokenGrabber = new HttpClientFacade();
        authTokenGrabber.target = target;
        return authTokenGrabber;
    }

    public HttpResponse post(String uri, String payload, String contentType) throws Exception {
        HttpClient httpclient = createClient();
        HttpResponse response = null;

        try {
            HttpPost httpPost = new HttpPost(uri);
            httpPost.setConfig(RequestConfig.custom().build());
            httpPost.setEntity(new StringEntity(payload));
            httpPost.setHeader("Content-Type", contentType);
            response = httpclient.execute(target, httpPost);
            try {
                EntityUtils.consume(response.getEntity());
            } catch (Exception e) {
                System.err.println("## Failed to consume response\n");
                throw new RuntimeException(e);
            }
        } catch (Exception e) {
            System.err.println("## Failed to execute post");
            throw new RuntimeException(e);
        }
        return response;
    }

    private HttpClient createClient() {
        try {
            SSLContext sslContext = SSLContext.getDefault();
            SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext,
                    SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            return HttpClients.custom().setSSLSocketFactory(sslsf).build();
        } catch (NoSuchAlgorithmException nsae) {
            System.out.println("Unable to configure relaxed SSL client");
        }

        return HttpClients.createDefault();
    }


}
