package au.com.medibank.jmeter;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;

public class ApiGatewayHelper {
    public static String getApiToken(String hostname) throws Exception {
        HttpHost target = new HttpHost(hostname, 443, "https");
        String jsonString = "{\"username\": \"C9999@medibank.com.au\", \"password\": \"Test123.\"}";
        HttpResponse post = HttpClientFacade.createInstance(target).post("/api/v1/sessions", jsonString, "application/json");
        return post.getFirstHeader("APISessionToken").getValue();
    }


}
