#!/usr/bin/env bash
##################################################
## Script variables
##################################################

unset HTTPS_PROXY
unset HTTP_PROXY
unset http_proxy
unset https_proxy

#Make sure jmeter is installed
LINUX_USER=`whoami`
JMETER_BINARY="jmeter.sh"

if [ "$LINUX_USER" = "bamboo" ]
then
    echo "setting JMETER_BINARY to absolute path"
    JMETER_BINARY="${HOME}/apache-jmeter-3.0/bin/jmeter.sh"
fi

#location helper jar file is installed
HELPER_JAR="build/libs/api-perf-test-helper-all-1.0.jar"

##################################################
## Script
##################################################

#Build the helper libraries
./gradlew clean
./gradlew fatJar

API_SESSION_TOKEN=`java -jar ${HELPER_JAR} $1`

echo "API_SESSION_TOKEN" && echo $API_SESSION_TOKEN

${JMETER_BINARY} -n -t ApiGatewayPerformance.jmx -JapiSessionToken="${API_SESSION_TOKEN}" -l performance_results.jtl

##########################################################
##########################################################
### DOC                                                ###
##########################################################
##########################################################
# Dev end point
#api-dev01-nprd.digidev-aws.medibank.local