##################################################
## Script variables
##################################################

#Make sure jmeter is installed
JMETER_INSTALLED=`which jmeter`

#location helper jar file is installed
HELPER_JAR="build/libs/api-perf-test-helper-all-1.0.jar"

##################################################
## Script
##################################################

API_SESSION_TOKEN=`java -jar ${HELPER_JAR} $1`
echo "API_SESSION_TOKEN" && echo $API_SESSION_TOKEN
jmeter.sh -t ApiGatewayPerformance.jmx -JapiSessionToken="${API_SESSION_TOKEN}" -l performance_results.jtl