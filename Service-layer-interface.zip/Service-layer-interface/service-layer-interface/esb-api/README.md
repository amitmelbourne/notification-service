# ESB API Specifications

The following documents were sourced from the corresponding locations:

 - AccessManagementRetrieveUser_v1.1.wsdl               | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Access Management (IAM)\Archive
 - BankReadBranchByBSB_v1.1.wsdl                        | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\BankReadBranchByBSB
 - CustomerReadByBPID_v2.3.wsdl                         | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Project Delphi ESB Read Customer v2.1
 - InteractionManageService_v1.1.wsdl                   | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Interaction Manage
 - ManageCustomerPaymentAccount_v0.3.wsdl               | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\ManagePaymentAccount
 - ManageCustomerUpdateCustomer_v2.3.wsdl               | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Project Delphi ESB Update Customer v2.2
 - ManagePolicyBeneficiary_v0.4.wsdl                    | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\UpdateBeneficiary
 - ManagePolicyBeneficiary_v1.2.wsdl                    | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\UpdateBeneficiary
 - ManagePolicyPremiumPayer v1.2.wsdl                   | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\ManagePremiumPayer
 - ManagePolicyUpdateExcess_v0.1.wsdl                   | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\UpdatePolicy
 - ManagePolicyUpdateIncomeTier_v2.1.wsdl               | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\UpdateIncomeTier
 - ManagePolicyUpdatePremium_v0.1.wsdl                  | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\UpdatePremium
 - ManagePolicyUpdatePremium_v1.2.wsdl                  | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\UpdatePremium
 - MemberCommsReadCorrespondenceItemByBPID_v2.1.wsdl    | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\MemberComms\ReadCorrespondenceItemByBPID
 - MemberCommsRetrieveDocuments_v0.2.wsdl               | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\MemberComms\RetrieveDocuments
 - PaymentGatewayProcessPayment_v1.1.wsdl               | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Westpac
 - PolicyCalculatePremiumByDPT_v0.1.wsdl                | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\CalculatePremiumOrDPT
 - PolicyReadByBPID_v3.1.wsdl                           | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\ReadPolicyList
 - PolicyReadByMasterPolicyID_v1.1.wsdl                 | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\ReadMasterPolicy
 - PolicyReadByPolicyID_v4.1.wsdl                       | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\ReadPolicyList
 - PolicyRequestCard_v0.1.wsdl                          | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\RequestCard
 - PolicySearchPremiumPaymentHistory_v0.3.wsdl          | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Search Premium Payment History
 - ServiceProviderSearch_v1.1.wsdl                      | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Claims Optimisation\Search Service Provider
 - PolicyReadBonus_v0.1.wsdl                            | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Claims Optimisation\ReadBonus
 - ClaimSearchServiceItem_v0.1.wsdl                     | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Claims Optimisation\SearchServiceItem
 - PolicyReadBenefitLimits_v0.3.wsdl                    | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Claims Optimisation\ReadBenefitLimits
 - ServiceProviderReadByProviderID_v0.2.wsdl            | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Claims Optimisation\Read Service Provider
 - ClaimSearchHistory_v1.4.wsdl                         | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Claims Optimisation\ClaimHistory
 - ClaimQuote_v0.1.wsdl                                 | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\Claims Optimisation\ClaimQuote
 - ManagePolicyRequestPHIRRegistration_v2.2.wsdl        | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\RequestPHIRRegistration
 - ProductCalculatePremium_v0.2.wsdl                    | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\ProductCalculatePremium
 - FlybuysEligibilityCheckMicrosite_v0.1.wsdl           | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\FlybuysEligibilityCheckMicrosite
 - FlybuysLinkMember_v0.1.wsdl                          | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\FlybuysLinkMember_v0
 - ClaimSubmit_v1.2.wsdl                                | J:\05 Project DelPHI\04 DelPHI Delivery\40 ESB\03 Solution Delivery\02 Interface Analysis\02 TO-BE\00_JIRA\ClaimSubmit_v1.2