package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.BeforeClass
import org.junit.Test

import static org.junit.Assert.assertTrue


class ValidateViewDependents {

    static PoliciesApiGateway policiesApiGateway;

    @BeforeClass
    public static void setup() {
        policiesApiGateway = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.memberOfPolicyThatHasReceiveBenefitsAccount)
    }

    private static void assertHasFields(obj, fields) {
        fields.each { field ->
            assertTrue(obj?.containsKey(field))
        }
    }

    @Jira(story = "DSS-239/1.1")
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void validate_multiple_dependents() {
        def responseData = policiesApiGateway.getPolicy(TestPolicy.hasMultipleMembersOneHasReceiveBenefitsAccount['policy']).getData()



        responseData['members'].each { eachMemberDetailKey ->

            println(eachMemberDetailKey['beneficiary'])

            assert eachMemberDetailKey
            assertHasFields eachMemberDetailKey, ['partyType', 'joinDate']
            assertHasFields eachMemberDetailKey['individual'], ['gender', 'birthDate', 'name']
            assertHasFields eachMemberDetailKey['individual']['name'], ['firstName', 'lastName']
        }
    }

    @Jira(story = "DSS-239/1.1")
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void validate_single_dependents_with_corp_payer() {

        PoliciesApiGateway methodLocalPoliciesGateway = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasCorrectPassword);
        def responseData = methodLocalPoliciesGateway.getPolicy(TestPolicy.hasRegisteredAgr['policy']).getData()

        responseData['members'].each { eachMemberDetail ->
            assert eachMemberDetail
            assertHasFields eachMemberDetail, ["partyType", 'joinDate']
            assert eachMemberDetail['organization']
            assertHasFields eachMemberDetail['organization'], ['corporateName', 'industrySector']
        }


    }

    @Jira(story = "DSS-239/1.1")
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void validate_single_dependents_with_individual_payer() {

       PoliciesApiGateway container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasDirectDebit);
        def responseData = container.getPolicy(TestPolicy.hasNonRegisteredAgr['policy']).getData()

        responseData['members'].each { eachMemberDetail ->
            assertHasFields eachMemberDetail, ["partyType", 'joinDate']
            assertHasFields eachMemberDetail['individual'], ['gender', 'birthDate', 'name']
            assertHasFields eachMemberDetail['individual']['name'], ['firstName', 'lastName']
        }
    }
}
