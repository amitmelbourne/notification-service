package au.com.medibank.client.api

import au.com.medibank.Config
import groovyx.net.http.RESTClient

import static au.com.medibank.assertions.HttpAssert.assertStatusCode
import static groovyx.net.http.ContentType.JSON

class ApiGatewayClientFactory {

    def static ReferencesApiGateway getUnauthorisedReferencesGateway() {
        return new ReferencesApiGateway(RestClientFactory.getUnauthenticatedRestClient())
    }

    def static MembersApiGateway getUnauthorisedMembersGateway() {
        return new MembersApiGateway(RestClientFactory.getUnauthenticatedRestClient())
    }

    def static PoliciesApiGateway getUnauthorisedPoliciesGateway() {
        return new PoliciesApiGateway(RestClientFactory.getUnauthenticatedRestClient())
    }

    // We get all in one go as we can then share the RestClient which has the auth credentials
    public static Map getGateways(member) {
        def (RESTClient restClient, sessionId) = RestClientFactory.getAuthenticatedRestClient(member)
        return [
                "members": new MembersApiGateway(restClient, sessionId),
                "users": new UsersApiGateway(restClient, sessionId),
                "policies": new PoliciesApiGateway(restClient, sessionId),
                "references": new ReferencesApiGateway(restClient, sessionId),
                "payments": new PaymentsApiGateway(restClient, sessionId),
                "tokens": new TokenApiGateway(restClient, sessionId),
        ]
    }

    public static Map getMicroservices() {
        Config c = new Config();
        return [
                "members": new MembersApiGateway(new RESTClient(c.getMembersMicroServiceUrl()), ''),
                "users": new UsersApiGateway(new RESTClient(c.getUsersMicroServiceUrl()), ''),
                "policies": new PoliciesApiGateway(new RESTClient(c.getPoliciesMicroServiceUrl()), ''),
                "references": new ReferencesApiGateway(new RESTClient(c.getReferencesMicroServiceUrl()), ''),
                "payments": new PaymentsApiGateway(new RESTClient(c.getPaymentsMicroServiceUrl()), ''),
                "tokens": new TokenApiGateway(new RESTClient(c.getTokenMicroServiceUrl()), ''),
        ]
    }

    public static MembersApiGateway getMembersApiGateway(member, expectingException = false) {
        def (RESTClient restClient, sessionId) = RestClientFactory.getAuthenticatedRestClient(member)
        return new MembersApiGateway(restClient, sessionId)
    }

    public static PoliciesApiGateway getPoliciesApiGateway(member, expectingException = false) {
        def (RESTClient restClient, sessionId) = RestClientFactory.getAuthenticatedRestClient(member)
        return new PoliciesApiGateway(restClient, sessionId)
    }

    public static PaymentsApiGateway getPaymentsApiGateway(member, expectingException = false) {
        def (RESTClient restClient, sessionId) = RestClientFactory.getAuthenticatedRestClient(member)
        return new PaymentsApiGateway(restClient, sessionId)
    }

    public static ReferencesApiGateway getReferencesApiGateway(member, expectingException = false) {
        def (RESTClient restClient, sessionId) = RestClientFactory.getAuthenticatedRestClient(member)
        return new ReferencesApiGateway(restClient, sessionId)
    }

    public static TokenApiGateway getTokensApiGateway(member, expectingException = false) {
        def (RESTClient restClient, sessionId) = RestClientFactory.getAuthenticatedRestClient(member)
        return new TokenApiGateway(restClient, sessionId)
    }

    public static UsersApiGateway getUsersApiGateway(member, expectingException = false) {
        def (RESTClient restClient, sessionId) = RestClientFactory.getAuthenticatedRestClient(member)
        return new UsersApiGateway(restClient, sessionId)
    }

    def static getOktaSessionToken(RESTClient restClient, String userName, String password) {
        def response
        try {
            def mapBody = [
                    'username': userName,
                    'password': password
            ]
            response = restClient.post(path: "sessions", headers: ['Content-Type': 'application/json'],
                    body: mapBody, requestContentType: JSON)
        } catch (Exception e) {
            return e
        }
        assertStatusCode(response, 201)
        def token = response.getHeaders().'APISessionToken'
        return token
    }


}
