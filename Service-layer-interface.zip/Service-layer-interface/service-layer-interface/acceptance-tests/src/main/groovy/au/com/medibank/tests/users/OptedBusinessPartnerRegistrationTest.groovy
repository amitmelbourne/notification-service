package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.MembersApiClient
import org.junit.Before
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class OptedBusinessPartnerRegistrationTest {
    private MembersApiClient registrationRequest
    private response


    @Before
    public void setup() {
        registrationRequest = ApiClientFactory.getMembersApiClient()
        response = registrationRequest.register(UserTestData.REGISTRATION_REQUEST_WITH_OPTEDOUT_BUSINESS_PARTNER)
    }



    @Test
    @Jira(stories = ["DSS-23/1.1", "DSS-107/1.4"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void request_for_registration_with_opted_business_partner_should_return_422_code() {
        assertStatusCode(response, 422)
    }


    @Test
    @Jira(stories = ["DSS-23/1.1", "DSS-107/1.4"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void request_for_registration_with_opted_business_partner_should_return_error_message() {
        def errorDescription = response.getResponse().responseData.errorDescription
        assert errorDescription == UserTestData.REGISTRATION_REQUEST_WITH_OPTEDOUT_BUSINESS_PARTNER.getErrorDescription(),
                "Error in description: \n${UserTestData.REGISTRATION_REQUEST_WITH_OPTEDOUT_BUSINESS_PARTNER.getErrorDescription()}\n${errorDescription}"

    }



}