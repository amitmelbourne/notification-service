package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.annotations.TestNotImplemented
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

//@Jira(story = 'DSS-98')
class viewCurrentPaymentInfo {

    private static PoliciesApiGateway apiGatewayFacade

    @BeforeClass
    public static void setup() {
        apiGatewayFacade= ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasUpdateableAddress)
    }

    @Jira(story = 'DSS-98/1.1')
    @Ignore
    @Test
    @ApiGateway(GET = 'policies/:policyNumber')
    // TODO: check wsdl
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void no_account_information_in_policy() {
        def responseData = apiGatewayFacade.getPolicy('P.TC1.A1').getData()
        assert !('accounts' in responseData['members'])
    }

    @Jira(story = 'DSS-98/1.3')
    @TestNotImplemented(reason = 'de-scoped for sprint 6')
    @Test
    @ApiGateway(GET = 'policies/:policyNumber')
    // TODO: check wsdl
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void message_if_multiple_active_accounts() {
    }

    @Jira(story = 'DSS-98/1.4')
    @Ignore
    @Test
    @ApiGateway(GET = 'policies/:policyNumber')
    // TODO: check wsdl
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void check_credit_card_type_in_policy() {
        def responseData = apiGatewayFacade.getPolicy('P.TC3.C1').getData()
        def premiumAccount = responseData['members'][0]['accounts']['payPremiums']
        // TODO: check [0] subscript is valid
        assert premiumAccount['cardType'] in ['VISA', 'MASTER'],
            "Card type was ${premiumAccount['cardType']}. Acceptable card types are VISA and MASTER"
    }

    @Jira(stories = ['DSS-98/1.5', 'DSS-99/2.1', 'DSS-99/2.2', 'DSS-99/2.3'])
    @Ignore
    @Test
    @ApiGateway(GET = 'policies/:policyNumber')
    // TODO: check wsdl
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void check_direct_debit_information_in_policy() {
        def responseData = apiGatewayFacade.getPolicy('P.TC2.B1').getData()
        //assert responseData['members'].size() > 1
        //['MALE', 'FEMALE'].each { assert it in responseData['members']['individual']['gender'] }
        def premiumAccount = responseData['members'][0]['accounts']
        assert premiumAccount != null
        // check this policy has an associated direct debit
        ["bsb", "accountHolderName", "accountNum"].each { field ->
            assert field in premiumAccount['payPremiums'], "Field '$field' should be in payPremiums section. It's missing!"
        }
    }
}