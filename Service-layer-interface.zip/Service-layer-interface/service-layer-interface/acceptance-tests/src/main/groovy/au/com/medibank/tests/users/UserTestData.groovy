package au.com.medibank.tests.users

public enum UserTestData {
    SUCCESSFUL_REGISTRATION_REQUEST("P1337", "Sam", "Customer", "2015-06-06", "simon.collins@medibank.com.au", "A!dddd999ee", "", false),
    REGISTRATION_REQUEST_WITH_BLANK_EMAIL("P1337", "Sam", "Customer", "2015-06-06", "", "A!dddd999ee", "EMAIL_IS_BLANK", false),

    REGISTRATION_REQUEST_WITH_NO_BUSINESS_PARTNER("P666a", "Sam", "Customer", "2015-06-06", "test2@example.com", "A!dddd999ee", "BUSINESS_PARTNER_NOT_FOUND", false),
    REGISTRATION_REQUEST_WITH_MULTIPLE_BUSINESS_PARTNER("P666a", "Sam", "Customer", "2015-06-06", "test3@example.com", "A!dddd999ee", "MULTIPLE_BUSINESS_PARTNERS_FOUND", false),
    REGISTRATION_REQUEST_WITH_OPTEDOUT_BUSINESS_PARTNER("P666a", "Sam", "Customer", "2015-06-06", "test4@example.com", "A!dddd999ee", "BUSINESS_PARTNER_OPTED_OUT", false),
    REGISTRATION_REQUEST_WITH_EMAIL_ALREADY_IN_USE("P666a", "Sam", "Customer", "2015-06-06", "test5@example.com", "A!dddd999ee", "EMAIL_ALREADY_IN_USE", false),

    SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_OVERRIDE("P666b", "John", "Smith", "1990-01-01", MismatchEmailInSapAndOverrideRegistrationTest.userWithEmailMatchesInSap['username'], "Test1234.", "", false),
    SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_OVERRIDE_TRUE("P666b", "John", "Smith", "1990-01-01", MismatchEmailInSapAndOverrideRegistrationTest.userWithEmailMatchesInSap['username'], "Test1234.", "", true),

    REGISTRATION_REQUEST_WITH_EMAIL_MISMATCH("P666c", "Sam", "Customer", "2015-06-06", "mismatch@example.com", "A!dddd999ee", "EMAIL_MISMATCH_WITH_BUSINESS_PARTNER_EMAIL", false),
    SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MATCHES_IN_SAP("P1337", "Sam", "Customer", "2015-06-06", MismatchEmailInSapAndOverrideRegistrationTest.userWithEmailMatchesInSap['username'], "Test1234.", "", false),

    SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_CHANGE("P666c", "John", "Smith", "1990-01-01", MismatchEmailInSapAndOverrideRegistrationTest.userWithEmailMisMatchesInSap, "Test123.", "", false);

    private final String policyNumber;
    private final String firstName;
    private final String lastName;
    private final String dob;
    private final String email;
    private final String password;
    private final String errorDescription;
    private final String emailOverride;

    private UserTestData(String policyNumber, String firstName, String lastName, String dob, String email, String password, String errorDescription, emailOverride) {
        this.policyNumber = policyNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dob = dob;
        this.email = email;
        this.password = password;
        this.errorDescription = errorDescription;
        this.emailOverride = emailOverride;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDob() {
        return dob;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public String getEmailOverride() {
        return emailOverride;
    }
}
