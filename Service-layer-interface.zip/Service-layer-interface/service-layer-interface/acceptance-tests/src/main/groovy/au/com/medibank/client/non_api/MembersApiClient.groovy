package au.com.medibank.client.non_api

import au.com.medibank.tests.users.UserTestData
import groovyx.net.http.HttpResponseException
import groovyx.net.http.RESTClient

import static groovyx.net.http.ContentType.JSON

class MembersApiClient extends BaseApiClient{

    RESTClient restClient

    MembersApiClient(String baseUrl, Map defaultHeaders) {
        super(baseUrl, defaultHeaders)

        restClient = new RESTClient(baseUrl)

        restClient.headers['client_id'] = this.defaultHeaders.get('client_id')
        restClient.headers['client_secret'] = this.defaultHeaders.get('client_secret')
        restClient.headers['Content-Type'] = this.defaultHeaders.get('Content-Type')
        restClient.ignoreSSLIssues();
    }

    def getRestClientInstance(){
        return this.restClient;
    }

    def register(UserTestData userTestData){
        register(userTestData.getPolicyNumber(), userTestData.getFirstName(), userTestData.getLastName(),
        userTestData.getDob(), userTestData.getEmail(), userTestData.getPassword(), userTestData.getEmailOverride())
    }

    def register(String policyId, String firstName, String lastName, String dob, String email= "simon.collins@medibank.com.au", String password, emailOverrideFlag) {
        def json = ["policyNum": policyId,
                    "firstName" : firstName,
                    "lastName" : lastName,
                    "dob" : dob,
                    "email" : email,
                    "password" : password,
                    "emailOverride": emailOverrideFlag
        ]

        def resp
        try {
            resp = restClient.post(path: "users", body: json, headers: this.defaultHeaders, requestContentType: JSON)
        } catch (HttpResponseException e) {
            System.err.println(e.getResponse().responseData.toString())
            return e

        }

        return resp;
    }

    def rawOktaAuthenticationResponse(String userName, String password) {
        def mapBody = [
                'username': userName,
                'password': password
        ]
        restClient.post(path: "sessions", headers: this.defaultHeaders,
                body: mapBody, requestContentType: JSON)
    }





}