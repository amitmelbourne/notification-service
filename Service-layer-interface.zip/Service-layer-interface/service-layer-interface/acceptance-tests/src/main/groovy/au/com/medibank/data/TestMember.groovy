package au.com.medibank.data

import au.com.medibank.Config

class TestMember {
    static defaultTestPassword = 'Test123.'

    static DevToSitMemberIdMapping = [
            'C9999'   : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C1234'   : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C1235'   : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC1.A' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC1.A' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC2.B' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC3.C' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC4.D' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC4.E' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC5.A' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C9999'   : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC5.A' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C1234'   : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC5.A' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC7.A' : ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC11.A': ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC14.A': ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC15.A': ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],
            'C.TC16.A': ['bpId': '4100001626', 'username': 'jdepp@gmail.com'],

    ]

    static canHaveCreditCardAdded = composeMember('C9999')
    static corpCanHaveCreditCardAdded = composeMember('C.TC1.A')
    static corpHasNoAccount = composeMember 'C.TC1.A'
    static hasBasicPolicy = composeMember('C9999')
    static hasCorrectPassword = composeMember('C9999')
    static hasReceivedBenefitsAccount = composeMember('C1234')
    static hasBasicInfo = composeMember('C1235')
    static emailVerfiedFlagFalse = composeMember("C.TC13.A")
    static hasDirectDebit = composeMember('C.TC1.A')
    static hasPolicywithNoAgr = composeMember('C.TC1.A')
    static hasNoBankAccount = composeMember('C.TC1.A')
    static onlyMemberOfPolicyHasReceiveBenefitsAccount = composeMember('C.TC2.B')
    static maleHasVisaPaymentCard = composeMember('C.TC3.C')
    static memberOfPolicyThatHasReceiveBenefitsAccount = composeMember('C.TC4.D')
    static femaleHasVisaPaymentCard = composeMember('C.TC4.E')
    static hasMultiplePolicies = composeMember('C.TC5.A')
    static hasOnePolicyWithAgr = composeMember('C9999')
    static hasMultiplePoliciesWithNoAgr = composeMember('C.TC5.A')
    static hasStoredCard = composeMember('C1234')
    static hasUpdateableAddress = composeMember('C9999')
    static member11 = composeMember('C.TC7.A')
    static hasWrongPassword = ['username': 'C.TC6.A@medibank.com.au',
                               'memberId': 'C.TC6.A',
                               'password': 'Go Lemons!']
    static hasConfigureWithOkta = composeMember('manish.nigade')
    static hasWrongUsername = composeMember('abc')
    static hasOMSOptOutFlagTrue = composeMember('C.TC9.A')
    static hadFraudMember = composeMember('C.TC8.A')
    static hasBlankUsername = composeMember('')
    static hasPoliciesWithMultiplePayer = composeMember('C.TC11.A')
    static hasPaymentHistory = composeMember('C.TC5.A')
    static hasPoliciesWithCorporatePremiumPayer = composeMember('C.TC14.A')
    static userInProvisionState = composeMember('C.TC15.A')
    static userInStageState = composeMember('C.TC16.A')
    static allExcessLevelsSubsidised = composeMember('C.TC2.B')
    static corpExcessLevelsMixedSubsidisedAndNotSubsidised = composeMember('C.TC2.B')
    static nonCorpHas2OrMoreExcessLevels = composeMember('C1236')
    static nonCorpHasExtrasOnlyCoverage = composeMember('C.TC2.B')
    static corp2OrMoreExcessLevelsSubsidised = composeMember('C.TC2.B')
    static corp2OrMoreExcessLevelsUnsubsidised = composeMember('C.TC2.B')
    static nonCorpOneExcessLevel =  composeMember('C9999')
    static corpOneExcessLevelNonSubsidised =  composeMember('C.TC2.B')
    static hasMultiplePayerPolicyWithIndividualAndCorp = composeMember('C.TC11.A')
    static doesNotExist = composeMember '6666'



    def TestMember() {
    }

    // ASSUMPTION: ids will be the same for SIT and PreProd, but will differ from DEV
    // In SIT (25/8/2015) BPIds, usernames, primary emails and memberIds can be independent
    // in DEV/Selphi (25/8/2015) BPId == memberId and username == memberId@medibank.com.au
    static composeMember(def devMemberId) {
        String envMemberId = Config.environment.startsWith('DEV') ?
                devMemberId : DevToSitMemberIdMapping[devMemberId].bpId
        String userName
        if (Config.environment.startsWith('DEV')) {
            userName = envMemberId
            if (!('@' in envMemberId)) {
                // Assumption: all DEV Selphi usernames end in '@medibank.com.au'
                // unless explicitly given
                userName += '@medibank.com.au'
            }
        } else {
            userName = DevToSitMemberIdMapping[devMemberId].username
        }

        return [
                'memberId': envMemberId,
                'username': userName,
                'password': defaultTestPassword
        ]
    }
}