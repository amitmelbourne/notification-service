package au.com.medibank.tests.users.Authentication

import au.com.medibank.Config
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.UsersApiGateway
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.TokenMicroServiceClient
import au.com.medibank.data.TestMember
import au.com.medibank.helpers.AssertHelper
import org.junit.After
import org.junit.Before
import org.junit.Ignore

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class PasswordChangeTest {

    static UsersApiGateway usersApiGateway
    static testUser
    public static final CHANGE_PASSWORD_TO = 'Test456.'
    public static final String DEFAULT_PASSWORD = TestMember.defaultTestPassword
    def response

    @Before
    public void setup() {
        testUser = TestMember.hasCorrectPassword
        usersApiGateway = ApiGatewayClientFactory.getUsersApiGateway(testUser)
    }


    @Jira(story = 'DSS-215/1.3.1')
    @ApiGateway(POST='users/$memberId/changePassword')
    @DelPHI(wsdl = 'InteractionManageService')
    public void correct_password_change() {
        response = usersApiGateway.postNewPassword("C9999", DEFAULT_PASSWORD, CHANGE_PASSWORD_TO)
        assertStatusCode(this.response, 202, "Unable to change default password for a new password")
    }


    @Ignore //Cannot run this test as too many failed attempts will lock the account
    @ApiGateway(POST='users/$memberId/changePassword')
    @DelPHI(wsdl = 'InteractionManageService')
    @Jira(story = 'DSS-215/1.3.2')
    public void password_change_old_password_wrong() {
        def wrongPassword = 'Colourless Green Ideas Sleep Furiously'
        def failResponse = usersApiGateway.postNewPassword(testUser['memberId'], wrongPassword, TestMember.defaultTestPassword)
        assert failResponse, "Should not be allowed to change password if old password is incorrect, yet there was a 'success' return code"
    }


     @Ignore("Manish no getUserDetails method")
    @ApiGateway(POST='users/$memberId/changePassword')
    @DelPHI(wsdl = 'InteractionManageService')
    @Jira(stories =  ['DSS-283/1.2','DSS-283/2.2'])
    public void verify_users_details_with_oms_initiated() {
        def user = TestMember.hasCorrectPassword['username']

        UsersApiGateway instance = new UsersApiGateway(ApiClientFactory.getMembersApiClient().getRestClientInstance())
         // never implemented getUserDetails
        def response = instance.getUserDetails(user,new TokenMicroServiceClient(new Config().getTokenMicroServiceUrl()).createToken(user,"PasswordReset"),false).getData()

        AssertHelper.assertHasFields(response,['dayOfBirth','name','username'])
        assert response['username'] == user,"Name of the user does not match in the response with requested name"
    }

     @Ignore("Manish no getUserDetails method")
    @ApiGateway(POST='users/$memberId/changePassword')
    @DelPHI(wsdl = 'InteractionManageService')
    @Jira(stories =  ['DSS-283/1.2','DSS-283/2.2'])
    public void verify_users_details_with_frontline_initiated() {
        def user = TestMember.hasCorrectPassword['username']

         UsersApiGateway instance = new UsersApiGateway(ApiClientFactory.getMembersApiClient().getRestClientInstance())
         // never implemented getUserDetails
        def response = instance.getUserDetails(user,new TokenMicroServiceClient(new Config().getTokenMicroServiceUrl()).createToken(user,"PasswordReset"),true).getData()

        AssertHelper.assertHasFields(response,['dayOfBirth','name','username'])
        assert response['username'] == user,"Name of the user does not match in the response with requested name"
    }



    @ApiGateway(POST='users/$memberId/changePassword')
    @DelPHI(wsdl = 'InteractionManageService')
    @Jira(story = 'DSS-283/1.3')
    public void enhance_security_for_member_forgot_password_with_correct_details() {
        def user = TestMember.hasCorrectPassword['username']
        UsersApiGateway instance = new UsersApiGateway(ApiClientFactory.getMembersApiClient().getRestClientInstance())
        def response = instance.checkDob(user,"12","1989")
        assertStatusCode(response, 200)
    }


    @ApiGateway(POST='users/$memberId/changePassword')
    @DelPHI(wsdl = 'InteractionManageService')
    @Jira(story = 'DSS-283/1.3')
    public void enhance_security_for_member_forgot_password_with_incorrect_details() {
        def user = TestMember.hasCorrectPassword['username']
        UsersApiGateway instance = new UsersApiGateway(ApiClientFactory.getMembersApiClient().getRestClientInstance())
        def response = instance.checkDob(user,"12","1990")
        assertStatusCode(response, 400)
    }


    @After
    public void teardown() {
        // change password back if it has been changed
        try {
            if (response == 202) {
                usersApiGateway.postNewPassword("C9999", CHANGE_PASSWORD_TO, DEFAULT_PASSWORD)
            }
        }
        catch(Exception e){
            //Never want a test to fail in teardown
        }
    }


}