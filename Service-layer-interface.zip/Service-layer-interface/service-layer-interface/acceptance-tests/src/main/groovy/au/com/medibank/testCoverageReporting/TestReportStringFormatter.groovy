package au.com.medibank.testCoverageReporting

import au.com.medibank.TestImplementationReporter
import au.com.medibank.helpers.CalcHelper

import static au.com.medibank.testCoverageReporting.AnnotationConfig.getReportableAnnotations

public class TestReportStringFormatter {
    static int indentation = 0
    static final int indentSize = 3
    static StringBuilder report = new StringBuilder('')
    TestImplementationReporter reporter

    public TestReportStringFormatter(TestImplementationReporter reportCollator) {
        reporter = reportCollator
    }

    String annotationReportFormatter() {
        addToReport '\n\n\n'
        addToReport '========'
        addToReport "Summary:\n"
        addToReport '========'
        addToReport '\n\n'
        if (AnnotationConfig.limitToStories) {
            addToReport "\n\nThis coverage report is limited to the following stories:\n\n"
            AnnotationConfig.limitToStories.collate(5).each { storyGroup ->
                def lineOfStories = storyGroup.join(', ')
                if (storyGroup.size() == 5) lineOfStories += ','
                addToReport(lineOfStories + '\n')
            }
            addToReport '\n\n'
        }
        def totalTests = reporter.selectedTestData.keySet().size()
        addToReport "All Tests: $totalTests\n"
        addToReport "Ignored Tests: ${reporter.selectedIgnoredTestNames.size()}\n"
        addToReport "Unimplemented Tests: ${reporter.notImplementedTestNames.size()}\n"
        double coverage = CalcHelper.getPercentage(totalTests, reporter.selectedIgnoredTestNames.size());
        addToReport "Percentage Implemented: $coverage%\n"

        def missingAnnotationsReport = new StringBuilder('')
        def thereAreMissingAnnotations = reporter.testsMissingAnnotations.collect { _, v ->
            v.size()
        }.sum() > 0
        if (thereAreMissingAnnotations) {
            addToReport '\n\n*** WARNING!!! Missing Annotations! ***\n\n'
            reportableAnnotations.each { annotation, _ ->
                def methodsMissingAnnotation = reporter.testsMissingAnnotations[annotation]
                if (methodsMissingAnnotation) {
                    addToReport "Active tests missing $annotation annotations ->\n"
                    indent()
                    methodsMissingAnnotation.each { methodName ->
                        def uniqueName = reporter.minimumUniqueNames[methodName]
                        addToReport "$uniqueName\n", true
                    }
                    outdent()
                }
            }
        }

        reportableAnnotations.each { annotation, lookup ->
            String heading = lookup.heading
            addToReport '\n\n\n'
            addToReport heading
            addToReport '\n' + '=' * heading.size() + '\n\n'
            reportMultiLevel reporter.collations[annotation]
        }
        report.toString()
    }

    def reportMultiLevel(LinkedHashMap collatedData) {
        indent()
        collatedData.each { heading, detail ->
            def isLastHeadingLevel = detail.getClass().name.tokenize('.')[-1] == 'ArrayList'
            if (isLastHeadingLevel) {
                def total = detail.size()
                def ignored = detail.findAll { AnnotationInstance annotation ->
                    annotation.ignored
                }.size()
                def notImplemented = detail.findAll { AnnotationInstance annotation ->
                    annotation.notImplemented
                }.size()
                String lineText = heading
                lineText += " (Total $total"
                if (ignored) {
                    lineText += " Ignored $ignored"
                }
                if (notImplemented) {
                    lineText += " NotImplemented $notImplemented"
                }
                lineText += ")"
                def noneActive = total == ignored + notImplemented
                if (noneActive) lineText += ' *** NO ACTIVE TESTS ***'
                lineText += " ->\n"
                addToReport lineText
                reportMethodDetail(detail)
            } else {
                addToReport heading + '\n'
                reportMultiLevel(detail)
            }
        }
        outdent()
    }

    private reportMethodDetail(annotatedMethods) {
        indent()
        boolean asterisked
        String text
        annotatedMethods.each { AnnotationInstance method ->
            method.with {
                asterisked = ignored || notImplemented
                text = reporter.minimumUniqueNames[testMethod]
                if (ignored) {
                    text += ' (ignored)'
                }
                if (notImplemented) {
                    text += ' (not implemented)'
                }
                addToReport text + '\n', asterisked
                if (asterisked) {
                    indent()
                }
                if (ignored) {
                    def ignoreMessage = ignoredReason ? "'$ignoredReason'" : "no reason given"
                    addToReport "Ignored: $ignoreMessage\n"
                }
                if (notImplemented) {
                    def notImplementedMessage = notImplementedReason ? "'$notImplementedReason'" : "no reason given"
                    addToReport "Not implemented: $notImplementedMessage\n"
                }
                if (asterisked) {
                    outdent()
                }
            }

        }
        outdent()
    }

    private static indent() {
        indentation += indentSize
    }

    private static outdent() {
        indentation -= indentSize
    }

    private static String indentPadding(int indentation) {
        return ' ' * indentation
    }

    private static void addToReport(text) {
        report.append(indentPadding(indentation) + text)
    }

    private static void addToReport(text, boolean asterisk) {
        report.append(indentWithOptionalAsterisk(text, asterisk))
    }

    private static String indentWithOptionalAsterisk(text, boolean asterisk) {
        return indentWithOptionalAsterisk(text, indentation, asterisk)
    }

    private static String indentWithOptionalAsterisk(text, int indentation, boolean asterisk) {
        def indentBy = asterisk ? indentation - 1 : indentation
        def mark = asterisk ? '*' : ''
        return indentPadding(indentBy) + mark + text
    }

    String csvTsrReport() {
        reporter.tsrRows.collect { row ->
            row.join(',')
        }.join('\n')
    }
}
