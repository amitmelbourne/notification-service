package au.com.medibank.client.api

import groovy.json.JsonBuilder
import groovyx.net.http.HttpResponseDecorator
import groovyx.net.http.HttpResponseException
import groovyx.net.http.RESTClient

import static au.com.medibank.assertions.DescriptiveErrors.failHttpResponseException
import static groovyx.net.http.ContentType.JSON

class PoliciesApiGateway  extends BaseApiGateway {
    def PoliciesApiGateway() {}
    def PoliciesApiGateway(RESTClient restClient) {
        super(restClient)
    }
    def PoliciesApiGateway(RESTClient restClient, String sessionId) {
        super(restClient, sessionId)
    }

    def getDeployedVersion() {
        restClient.get(path: "policies/version")
    }

    def getPolicy(policyNumber, expectingException = false) {
        def resp
        try {
            resp = restClient.get(path: "policies/${policyNumber}")
        } catch (HttpResponseException e) {
            if (expectingException == false) {
                failHttpResponseException(e)
            }
            throw e
        }
        return resp
    }

    def getPremium(String policyId) {
        def resp
        try {
            resp = restClient.get(path: "policies/${policyId}/premiums")
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
        return resp
    }

    def getPolicyWithPayments(policyNumber) {
        try {
            def resp = restClient.get(path: "policies/${policyNumber}", query: ["include": "payments"])
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
    }


    def HttpResponseDecorator getAmountToPay(String memberId, String policyId, String until) {
        def sessionToken = restClient.headers['APISessionToken']
        def response = null
        try {
            response = restClient.get(
                    path: "policies/${policyId}/amountToPay",
                    query: [
                            until: until
                    ],
                    headers: [APISessionToken: sessionToken, 'Content-Type': 'application/json'],
            ) as HttpResponseDecorator
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }

        return response
    }



//
// Policies list

    def HttpResponseDecorator getPoliciesList(String memberId) {
        def response = null

        try {
            response = restClient.get(
                    path: 'policies',
                    query: [
                            memberId: memberId
                    ],
                    headers: [
                            bpId  : memberId,
                            userId: 'test@test.com'
                    ],
            ) as HttpResponseDecorator
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
        return response
    }

    def postCardRequest(noOfCards, reason, policy, userId) {
        def response = null
        try {
            response = restClient.post(
                    path: "policies/${policy['policy']}/cardRequest",
                    headers: ['bpId'        : policy['member']['memberId'],
                              'userId'      : userId,
                              'Content-Type': 'application/json'],
                    body: ['numberOfCards': noOfCards,
                           'requestReason': reason
                    ],
                    requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
        return response.status
    }

    def putIncomeTier(String policyId, String incomeType, String incomeTier, etag) {

        def updateTierData = [
                "effectiveAGR"                 : "true",
                "registrationStatus"           : "true",
                "agrPercentage"                : "5",
                "registrationEffectiveFromDate": "2015-08-23",
                "registrationEffectiveToDate"  : "2016-08-23",
                "agrIncomeTier"                : [
                        "incomeType": incomeType,
                        "incomeTier": incomeTier
                ]
        ]

        def postBodyJson = new JsonBuilder(updateTierData).toPrettyString()
        def sessionToken = restClient.headers['APISessionToken']
        def response = null

        try {
            response = restClient.put(path: "policies/$policyId/ausgovRebate", body: postBodyJson, headers: [
                    APISessionToken: sessionToken, 'Content-Type': 'application/json', 'If-Match': etag], requestContentType: JSON)
        } catch (HttpResponseException e) {
            return e
        }

        return response
    }

    def putExcessChanges(String testPolicyId, String newExcessLevel,etag) {
        def resp
        def bodyMap = ["code": newExcessLevel,"changeStateID":""]

        try {
            resp = restClient.put(path: "policies/$testPolicyId/excess",
                    headers: ['Content-Type': 'application/json','If-Match':etag],
                    body: bodyMap, requestContentType: JSON)
        } catch (HttpResponseException e) {
            return e
        }
        catch (Exception e) {
            println('general exception here')
        }
        return resp
    }

    def getExcessChanges(String testPolicyId) {
        try {
            def resp = restClient.get(path: "policies/$testPolicyId/excess")
            return resp
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
    }

    def submitAgrDetails(policyId, etag) {

        def dataMap = [
                "startDate"    : "2015-08-13",
                "endDate"      : "2018-08-23",
                "lodgementDate": "2015-08-23",
                "changeStateID": "12345",
                "scale"        : "COUPLE",
                "coverType"    : "HOSPITAL",
                "agrIncomeTier": [
                        "incomeType": "1",
                        "incomeTier": "2"
                ],
                "applicant"    : [
                        "individual"        : [
                                "birthDate"     : "1980-08-13",
                                "gender"        : "MALE",
                                "medicareNumber": "1234",
                                "medicareIRN"   : 1234,
                                "name"          : [
                                        "firstName" : "Sam",
                                        "middleName": "J",
                                        "lastName"  : "Customer"
                                ]
                        ],
                        "memberIndicator"   : "MEMBER",
                        "applicantStartDate": "2018-08-13",
                        "applicantEndDate"  : "2015-08-13",
                        "address"           : [
                                "addressLine1": "Unit 1",
                                "addressLine2": "19 Fred Rd.",
                                "postCode"    : "3000",
                                "townName"    : "Melbourne",
                                "state"       : "VIC"
                        ]
                ],
                "members"      : [[
                                          "dependantIndicator": "ADULT",
                                          "applicantStartDate": "2015-08-13",
                                          "applicantEndDate"  : "2018-08-13",
                                          "type"              : "members",
                                          "individual"        : [
                                                  "birthDate": "1980-08-13",
                                                  "gender"   : "MALE",
                                                  "name"     : [
                                                          "firstName" : "Sam",
                                                          "middleName": "J",
                                                          "lastName"  : "Customer"
                                                  ]
                                          ]
                                  ], [
                                          "dependantIndicator": "DEPENDENT",
                                          "applicantStartDate": "2015-08-13",
                                          "applicantEndDate"  : "2018-08-13",
                                          "type"              : "members",
                                          "individual"        : [
                                                  "birthDate": "1982-08-13",
                                                  "gender"   : "FEMALE",
                                                  "name"     : [
                                                          "firstName" : "Jane",
                                                          "middleName": "S",
                                                          "lastName"  : "Customer"
                                                  ]
                                          ]
                                  ]]
        ]


        def bodyJSON = new JsonBuilder(dataMap).toPrettyString()
        def response = null
        try {
            response = restClient.post(
                    path: "policies/$policyId/registerAusgovRebate",
                    body: bodyJSON,
                    requestContentType: JSON,
                    headers: ['If-Match':etag,APISessionToken: restClient.headers['APISessionToken']])
        } catch (HttpResponseException e) {
            return e
        }
        return response
    }

}