package au.com.medibank.tests.tokens

import au.com.medibank.Config
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.RestClientFactory
import au.com.medibank.client.api.TokenApiGateway
import au.com.medibank.data.TestMember
import groovyx.net.http.RESTClient
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.core.IsNull.notNullValue
import static org.junit.Assert.assertTrue


class VerifyTokenService {

    static RESTClient restClient;
    def secretId = "XXXXXXYYSHHHHHHHHHHX"
    def expiryDate = "2016-08-01"
    def tokenType = "PasswordReset"
    def memberId = TestMember.hasReceivedBenefitsAccount['memberId']
    private static TokenApiGateway tokenApiGateway

    @BeforeClass
    public static void setup() {
        restClient = restClient = RestClientFactory.getBaseRestClient(new Config().getBaseTokenApiUrl());
        tokenApiGateway = new TokenApiGateway(restClient)
    }

    private static void assertHasFields(obj, fields) {
        fields.each { field ->
            assertTrue(obj.containsKey(field))
        }
    }

    @Jira(story = 'DSS-275')
    @Ignore
    @Test
    @ApiGateway(POST = "tokens")
    @DelPHI(wsdl = '')
    public void verify_post_valid_token_request() throws Exception {


        def result = this.tokenApiGateway.postTokenRequest(secretId, expiryDate, tokenType, memberId)

        assertThat result.body, notNullValue()
        assertHasFields(result.body, ['token'])
    }

    @Jira(story = 'DSS-275')
    @Ignore
    @Test
    @ApiGateway(POST = "tokens/used")
    @DelPHI(wsdl = '')
    public void verify_post_valid_token_response() throws Exception {

        def result = tokenApiGateway.postTokenRequest(secretId, expiryDate, tokenType, memberId)

        def usedResponse = tokenApiGateway.postUsedTokenRequest(result.getData()['token'], secretId).getData()
        assertTrue(usedResponse['expiryDate'].equals(expiryDate))
    }

    @Jira(story = 'DSS-275')
    @Ignore
    @Test
    @ApiGateway(POST = "tokens")
    @DelPHI(wsdl = 'noWSDL')
    public void verify_post_invalid_token_request() throws Exception {
        expiryDate = "2014-08-01"

        try {
            tokenApiGateway.postTokenRequest(secretId, expiryDate, tokenType, memberId, true)
        }
        catch (Exception ae) {
            assert ae.message.equals("Bad Request")
        }
    }


    @Test
    @Ignore
    @Jira(story = 'DSS-275')
    @ApiGateway(POST = "tokens/used")
    @DelPHI(wsdl = '')
    public void verify_post_invalid_token_response() throws Exception {

        def result = tokenApiGateway.postTokenRequest(secretId, expiryDate, tokenType, memberId)

        String temperedToken = result.getData()['token']
        temperedToken = temperedToken.substring(4, temperedToken.length())

        try {
            tokenApiGateway.postUsedTokenRequest(temperedToken, secretId, true).getData()
        }
        catch (Exception e) {
            assert e.message.equals("Internal Server Error")
        }
    }
}