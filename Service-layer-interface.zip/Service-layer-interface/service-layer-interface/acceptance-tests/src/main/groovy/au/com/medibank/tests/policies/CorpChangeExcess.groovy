package au.com.medibank.tests.policies

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.annotations.TestNotImplemented
import au.com.medibank.assertions.HttpCodeRange
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.Before
import org.junit.Ignore
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCode
import static au.com.medibank.assertions.HttpAssert.assertStatusCodeInRange

class CorpChangeExcess {

    PoliciesApiGateway apiGatewayInstance
    def testPolicy
    def getPolicyRespBeforeExcessChange
    def putResp
    def getResp
    def changeStateId
    def final newChangeExcess = 'EX01'

    @Before
    public void setup(){
    }


    @Test
    @Jira(story = 'DSS-279/1.1')
    @ApiGateway(PUT = 'policies/:id/product/excess', GET = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void can_change_excess_level_when_all_choices_subsidised() {
        def apiGatewayInstance = ApiGatewayClientFactory.getPoliciesApiGateway(
                TestMember.corp2OrMoreExcessLevelsSubsidised)
        def testPolicy = TestPolicy.corp2OrMoreExcessLevelsSubsidised
        getPolicyRespBeforeExcessChange = apiGatewayInstance.getPolicy(testPolicy.policy)
        getResp = apiGatewayInstance.getExcessChanges(testPolicy.policy)
//        changeStateId = getPolicyRespBeforeExcessChange.getData().changeStateID
//        changeStateId =

        def resp = apiGatewayInstance.getExcessChanges(TestPolicy.hasRegisteredAgr['policy'])
        resp = apiGatewayInstance.putExcessChanges(TestPolicy.hasRegisteredAgr['policy'],'EX03', ResponseHelper.generateResponseHeaderMap(resp).get("ETag"))
        assertStatusCode(resp, 200)
    }

    // TODO: no test data available for this test. Confirm there is a need for it
//
//    @Ignore("DSS-279 in progress: needs ")
//    @Jira(story = 'DSS-279/1.1')
//    @ApiGateway(PUT = 'policies/:id/excess')
//    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
//    public void cannot_change_excess_excess_level_if_only_one_choice() {
//        def apiGatewayInstance = ApiGatewayClientFactgetJumboBeingPhasedOutApiGatewayance(
//                TestMember.corpOneExcessLevelSubsidised)
//        def testPolicy = TestPolicy.corpOneExcessLevelSubsidised
//        def resp = apiGatewayInstance.putExcessChanges(testPolicy, newChangeExcess)
//        assertStatusCodeInRange(resp, HttpCodeRange._400)
//    }


    @Test
    @Ignore("DSS-279 in progress: needs Selphi work")
    @Jira(stories = ['DSS-279/1.1', 'DSS-279/1.4'])
    @ApiGateway(PUT = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void cant_change_excess_level_when_choices_are_mixed_subsidised_and_not_subsidised() {
        PoliciesApiGateway apiGatewayInstance = ApiGatewayClientFactory.getPoliciesApiGateway(
                TestMember.corpExcessLevelsMixedSubsidisedAndNotSubsidised)
        def testPolicy = TestPolicy.corpExcessLevelsMixedSubsidisedAndNotSubsidised

        def resp = apiGatewayInstance.getExcessChanges(testPolicy.policy)
        resp = apiGatewayInstance.putExcessChanges(testPolicy.policy,'EX02', apiGatewayInstance.generateResponseHeaderMap(resp).get("ETag"))

        assertStatusCodeInRange(resp, HttpCodeRange._400)
    }


    @Test
    @TestNotImplemented(reason = 'UI only')
    @Jira(story = 'DSS-279/1.3')
    @ApiGateway(PUT = 'policies/:id/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void display_note_that_full_premium_is_displayed_not_employee_contribution() {
    }
}
