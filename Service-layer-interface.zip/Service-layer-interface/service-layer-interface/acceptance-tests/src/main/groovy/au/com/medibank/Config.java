package au.com.medibank;

import java.io.IOException;
import java.util.Properties;

public class Config {

    Properties properties = new Properties();

    public Config() throws IOException {
        properties.load(getClass().getResourceAsStream("/config.properties"));
    }

    public String getBaseApiUrl() {
        return getConfigElement("BASE_API_URL", "base_api.url");
    }
    public String getBaseAppUrl() {
        return getConfigElement("BASE_APP_URL", "base_app.url");
    }

    public String getBaseTokenApiUrl() { return getConfigElement("BASE_TOKEN_API_URL", "base_token_api.url"); }

    public String getMembersMicroServiceUrl() { return getConfigElement("MEMBERS_MICRO_SERVICE_URL", "members.micro.service.url"); }
    public String getPaymentsMicroServiceUrl() { return getConfigElement("PAYMENTS_MICRO_SERVICE_URL", "payments.micro.service.url"); }
    public String getPoliciesMicroServiceUrl() { return getConfigElement("POLICIES_MICRO_SERVICE_URL", "policies.micro.service.url"); }
    public String getUsersMicroServiceUrl() { return getConfigElement("USERS_MICRO_SERVICE_URL", "users.micro.service.url"); }
    public String getReferencesMicroServiceUrl() { return getConfigElement("REFERENCES_MICRO_SERVICE_URL", "references.micro.service.url"); }
    public String getTokenMicroServiceUrl() { return getConfigElement("TOKEN_MICRO_SERVICE_URL", "token.micro.service.url"); }


    public String getSelphiBackdoorUrl() { return getConfigElement("SELPHI_URL", "selphi.url"); }
    public String getClientId() { return getConfigElement("API_GATEWAY_CLIENT_ID", "api.gateway.client.id"); }

    public String getOktaUrl() {
        return getConfigElement("OKTA_URL", "okta.url");
    }
    public String getOktaAuthToken() { return getConfigElement("OKTA_AUTH_TOKEN", "okta.auth.token"); }
    public String getOktaProxyHost() {return getConfigElement("OKTA_PROXY_HOST", "okta.proxy.host");}
    public int getOktaProxyPort() {return Integer.parseInt(getConfigElement("OKTA_PROXY_PORT", "okta.proxy.port"));}
    public String getOktaProtocol() {return getConfigElement("OKTA_PROXY_PROTOCOL", "okta.proxy.protocol");}
    public String getSkipOktaProxy() {return getConfigElement("SKIP_OKTA_PROXY", "skip.okta.proxy");}

    public String getClientSecret() {
        return getConfigElement("API_GATEWAY_CLIENT_SECRET", "api.gateway.client.secret");
    }

    public static String getEnvironment() {
        String environment = System.getenv("ENVIRONMENT");
        if (environment == null) {
            environment = "DEV02";
        }
        return environment;
    }

    private String getConfigElement(String environmentVariable, String propertyName) {
        String baseApiUrl = System.getenv(environmentVariable);
        if (baseApiUrl == null) baseApiUrl = properties.getProperty(propertyName);
        return baseApiUrl;
    }

}
