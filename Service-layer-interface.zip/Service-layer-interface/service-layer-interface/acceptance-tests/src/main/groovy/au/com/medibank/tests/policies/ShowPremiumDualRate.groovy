package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import org.junit.BeforeClass
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

public class ShowPremiumDualRate {
    static PoliciesApiGateway policiesApiGateway;
    static final USER_WITH_POLICY_WITH_FOUR_FREQUENCIES_AND_NO_DUAL_RATE = TestMember.nonCorpHas2OrMoreExcessLevels
    static final FOUR_PAYMENT_FREQUENCIES_AND_NO_DUAL_RATE_POLICY = "P1236"
    private static response

    @BeforeClass
    public static void setup() {
        policiesApiGateway = ApiGatewayClientFactory.getPoliciesApiGateway(USER_WITH_POLICY_WITH_FOUR_FREQUENCIES_AND_NO_DUAL_RATE)
        response = policiesApiGateway.getPremium(FOUR_PAYMENT_FREQUENCIES_AND_NO_DUAL_RATE_POLICY)
    }

    @Test
    @Jira(story = "DSS-295/1.3")
    @ApiGateway(GET = "policies/:policyId/premiums") @DelPHI(wsdl = "ProductCalculatePremiums")
    public void testPremiumReturnCode() {
        assertStatusCode(this.response, 200)
    }

    @Test
    @Jira(story = "DSS-295/1.3")
    @ApiGateway(GET = "policies/:policyId/premiums") @DelPHI(wsdl = "ProductCalculatePremiums")
    public void testCurrentAndFutureFrequenciesMatch() {
        def noOfCurrentFrequencies = response.responseData.current.size()
        def noOfFutureFrequencies = response.responseData.future.size()
        assert noOfCurrentFrequencies == noOfFutureFrequencies, "Number of frequencies for dual rates do not match"
    }

    @Test
    @Jira(story = "DSS-295/1.3")
    @ApiGateway(GET = "policies/:policyId/premiums") @DelPHI(wsdl = "ProductCalculatePremiums")
    public void testCurrentFrequencies() {
        //http://mrhaki.blogspot.com.au/2010/01/groovy-goodness-apply-method-to-all.html
        //Groovy equivalent of ruby Array.map
        def currentFrequencies = response.responseData.current*.coverPeriod
        assert currentFrequencies == ["MONTHLY", "QUARTERLY", "YEARLY"], "Frequencies not as expected"
    }

    @Test
    @Jira(story = "DSS-295/1.3")
    @ApiGateway(GET = "policies/:policyId/premiums") @DelPHI(wsdl = "ProductCalculatePremiums")
    public void testFutureFrequencies() {
        def currentFrequencies = response.responseData.future*.coverPeriod
        assert currentFrequencies == ["MONTHLY", "QUARTERLY", "YEARLY"], "Frequencies not as expected, got ${currentFrequencies}"
    }
}
