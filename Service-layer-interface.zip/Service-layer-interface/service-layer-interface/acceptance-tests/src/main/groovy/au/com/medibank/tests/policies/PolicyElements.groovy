package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

class PolicyElements {

    static PoliciesApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasUpdateableAddress)
    }

    @Jira(stories = ['DSS-158/1.1', 'DSS-158/1.2', 'DSS-158/1.3', 'DSS-158/1.4', 'DSS-158/1.5'])
    @Ignore
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    // TODO: check wsdl
    @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void view_policy_information() {
        def responseData = container.getPolicy('P9999').getData()
        ['masterPolicyID', //TODO: check this is 'policy story' from story
         'coverageStartDate'].each { assert it in responseData } // and 'coverageStartDate' is date joined
        // TODO: check these zero subscripts [0] are relying on a defined fixed order. Probably not true
        assert "coverTypeName" in responseData['product']['coverage'][0] // 'cover type'
        ['partyStatus', 'partyType', 'joinDate'].each { assert it in responseData['members'][0] }
        ['registrationStatus', 'agrPercentage'].each { assert it in responseData['ausgovRebate'] } // TODO: query ausgovRebate case
    }

    @Jira(story = "DSS-158/2.1")
    @Test
    @Ignore
    @ApiGateway(GET = "policies/:policyNumber")
    // TODO: check wsdl
    @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void view_member_role() {
        def responseData = container.getPolicy('12345').getData()
    }
}