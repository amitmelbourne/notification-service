package au.com.medibank.tests.manual

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.annotations.TestNotImplemented
import au.com.medibank.assertions.HttpCodeRange
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.Before
import org.junit.Ignore
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCodeInRange

class waitingForSelphiUpdate {

    def apiGatewayInstance
    def testPolicy
    def getPolicyRespBeforeExcessChange
    def putResp
    def getResp
    def changeStateId

    @Before
    public void setup() {
        apiGatewayInstance = ApiGatewayClientFactory.getPoliciesApiGateway(
                TestMember.nonCorpHasExtrasOnlyCoverage)
        testPolicy = TestPolicy.nonCorpHasExtrasOnlyCoverage
        getPolicyRespBeforeExcessChange = apiGatewayInstance.getPolicy(testPolicy.policy)
        getResp = apiGatewayInstance.getExcessChanges(testPolicy.policy)
        changeStateId = getResp.getData().changeStateID
        putResp = apiGatewayInstance.putExcessChanges(testPolicy.policy, 'EX03', changeStateId)
    }


    @Test
    @Ignore('waiting for Selphi update')
    @Jira(story = 'DSS-90/1.2')
    @ApiGateway(PUT = 'policies/:id/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void extras_only_cover_should_not_allow_update_excess() {
        assertStatusCodeInRange(putResp, HttpCodeRange._400)
    }


    @Test
    @TestNotImplemented(reason = 'UI only')
    @Jira(story = 'DSS-90/1.4')
    @ApiGateway(PUT = 'policies/:id/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void hosp_prod_member_can_see_excess_explanation() {
    }


    @Test
    @TestNotImplemented(reason = 'UI only')
    @Jira(story = 'DSS-90/1.7')
    @ApiGateway(PUT = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void hosp_prod_member_can_see_message_excess_change_effective_immediately() {
    }

}
