package au.com.medibank.client.api

import groovy.json.JsonBuilder
import groovyx.net.http.HttpResponseDecorator
import groovyx.net.http.HttpResponseException
import groovyx.net.http.RESTClient

import static au.com.medibank.assertions.DescriptiveErrors.failHttpResponseException
import static groovyx.net.http.ContentType.JSON

class UsersApiGateway extends BaseApiGateway{
    def UsersApiGateway() {}
    def UsersApiGateway(RESTClient restClient) {
        super(restClient)
    }
    def UsersApiGateway(RESTClient restClient, String sessionId) {
        super(restClient, sessionId)
    }

    def getDeployedVersion() {
        restClient.get(path: "users/version")
    }

    public int postNewPassword(memberId, oldPassword, newPassword) {
        def bodyMap = [

                "oldPassword": oldPassword,
                "newPassword": newPassword
        ]
        def bodyJSON = new JsonBuilder(bodyMap).toPrettyString()
        def response = null
        try {
            response = restClient.post(
                    path: "users/$memberId/changePassword",
                    body: bodyJSON,
                    requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
        return response
    }

    def HttpResponseDecorator getChangeUserId(String policyNumber, String firstName, String lastName, String dob) {

        def queryParam = [policyNum: policyNumber, firstName: firstName, lastName: lastName, dob: dob]
        def response = null
        try {
            response = restClient.get(path: 'users', headers: ['Content-Type': 'application/json'], requestContentType: JSON, query: queryParam)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }

        return response
    }

    def HttpResponseDecorator postTokenRequest(String secretId, String expiryDate, String tokenType, String memberId, expectingException = false) {
        def tokenDetails = [tokenType: tokenType, expiryDate: expiryDate, tokenProperties: [INTERACTION_ID: memberId, CHANGE_STATE_ID: 123456, BP_ID: memberId, USERNAME: memberId + '@medibank.com.au']]
        def sessionToken = restClient.headers['APISessionToken']

        try {
            def resp = restClient.post(path: "tokens", body: tokenDetails, headers: [
                    APISessionToken: sessionToken, 'Content-Type': 'application/json'], requestContentType: JSON)
        } catch (HttpResponseException e) {
            if (expectingException == false) {
                failHttpResponseException(e)
            }
            throw e
        }
    }
    def checkDob(String email, String month, String year){
        def response
        def bodyMap = ['month':month,'year':year];
        try{
            response = restClient.put(path:"users/${email}/checkdob",body:bodyMap,requestContentType: JSON)
        } catch (HttpResponseException e) {
            assert e.getResponse().status == 400
            return e
        }

        return response
    }

}