package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import au.com.medibank.helpers.AssertHelper
import org.junit.BeforeClass
import org.junit.Test

class ViewDirectDebitPayrollTest {

    static PoliciesApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasPoliciesWithMultiplePayer)
    }

    @Jira(story = 'DSS-159/1.2')
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['ProductReadByProdOptCd', 'CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicyReadByMasterPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void direct_debit_with_payroll_brokerid_corp() {
        def responseData = container.getPolicy(TestPolicy.hasCorporatePremiumPayer['policy']).getData()

        responseData['members'].each { eachMember ->
            AssertHelper.assertHasFields eachMember, ['payment']
            AssertHelper.assertHasFields eachMember['payment'], ['account', 'sharePercentage', 'payRemainingAmount']

            eachMember['payment'].each { k, v ->
                if (k.equals('account')) {
                    AssertHelper.assertHasFields v, ['accountType', 'employerName', 'employeeNumber', 'employeeDepartment', 'id', 'type']
                }
            }

        }
    }

}
