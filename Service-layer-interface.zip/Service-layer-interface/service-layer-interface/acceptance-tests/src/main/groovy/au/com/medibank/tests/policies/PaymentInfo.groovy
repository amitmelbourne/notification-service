package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.annotations.TestNotImplemented
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

class PaymentInfo {

    static PoliciesApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasUpdateableAddress)
    }

    @Jira(story = 'DSS-165/1.1')
    @Ignore
    @Test
    @ApiGateway(GET = 'policies/:policyNumber')
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void view_last_payment_info() {
        def responseData = container.getPolicy('99992').getData()
        // assume payment history is presented in reverse order of payment
        def lastPayment = responseData['paymentHistory'][0]
        def requiredFields = ['type', 'coverageEndDate', 'transactionDate',
                              'paymentAmount', 'paymentMethod', 'status']
        requiredFields.each { k -> assert k in lastPayment }
    }


    @Test
    @Ignore
    @TestNotImplemented(reason = "Not implemented against API")
    @Jira(story = "DSS-165/1.3")
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void limit_historical_payments_displayed() {
        throw new Exception('Not implemented against API at present-- possibly only at UI level')
    }


    @Test
    @Ignore
    @TestNotImplemented()
    @Jira(story = "DSS-165/1.2")
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void show_only_logged_in_beneficiary_payments() {
        throw new Exception('Not implemented: security work not yet out of DEV')
    }
}