package au.com.medibank.tests.policies

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import au.com.medibank.helpers.AssertHelper
import org.junit.BeforeClass
import org.junit.Test

class SubmitAGRDetails {

    static PoliciesApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasPoliciesWithMultiplePayer)
    }

    @Jira(stories = ['DSS-43/1.1', 'DSS-43/1.2'])
    @Test
    @ApiGateway(POST = "policies/:policyNumber/registerAusgovRebate")
    @DelPHI(wsdl = 'ManagePolicyRequestPHIRRegistration')
    public void submit_agr_successful() {

        def testPolicy = TestPolicy.hasMultiplePayeesWithIndividualAndCorp
        def resp = container.getExcessChanges(testPolicy.policy)
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        def responseData = container.submitAgrDetails(testPolicy.policy, responseMap.get("ETag")).getData()

        AssertHelper.assertHasFields(responseData.premiums, ['current', 'future'])
        AssertHelper.assertHasFields(responseData.premiums.future[0], ['paymentAmount', 'coverPeriod', 'coverageStartDate', 'baseAmount'])
        AssertHelper.assertHasFields(responseData.ausgovRebate, ['agrPercentage', 'registrationEffectiveFromDate'])
    }

    @Test
    @Jira(stories = ['DSS-43/1.3'])
    @ApiGateway(POST = "policies/:policyNumber/registerAusgovRebate")
    @DelPHI(wsdl = 'ManagePolicyRequestPHIRRegistration')
    public void submit_agr_unsuccessful() {

        try {
            container.submitAgrDetails(TestPolicy.hasMultiplePayeesWithIndividualAndCorp['policy'], "666")
        } catch (Exception e) {
            AssertHelper.assertHasFields(e.response.responseData['details'][0], ['errorCode', 'errorDescription'])
            assert e.response.responseData['errorDescription'] == 'Invalid Medicare Number', "Invalid Medicare number error message is not returning"
        }

    }

}


