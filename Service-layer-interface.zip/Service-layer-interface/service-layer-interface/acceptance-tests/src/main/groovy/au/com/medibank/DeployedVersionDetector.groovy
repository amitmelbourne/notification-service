package au.com.medibank

import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.BaseApiGateway;

public class DeployedVersionDetector {

    public static void main(String [] args){
        def inputFile = new File("build/versions.txt")
        Map microservices = ApiGatewayClientFactory.getMicroservices()
        StringBuilder sb = new StringBuilder();
        Iterator iterator = microservices.keySet().iterator()
        def next
        while (iterator.hasNext()) {
            try {

                next = iterator.next()
                sb.append(next + ": " + microservices.get(next).getDeployedVersion().getData().str + ", " + microservices.get(next).getBaseUri() + "\n");
            }
            catch (Exception e) {
                sb.append(next + ": ???\n");
            }
        }

        inputFile.write(sb.toString())


    }

}
