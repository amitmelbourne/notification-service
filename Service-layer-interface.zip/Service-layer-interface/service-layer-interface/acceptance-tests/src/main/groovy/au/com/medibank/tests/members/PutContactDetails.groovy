package au.com.medibank.tests.members

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.annotations.TestNotImplemented
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.helpers.AssertHelper
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

class PutContactDetails {

    static MembersApiGateway container
    Map addressUpdateables = ["addressLine1"       : 'New addr 1',
                              "addressLine2"       : ['New addr 2'],
                              "addressLine3"       : ['New addr 3'],
                              "postCode"           : ["3450", "3000", '3008'],
                              "townName"           : ["Brisbane", "Melbourne", 'Catherine'],
                              "stateCode"          : ['QLD', 'NT', 'NSW', 'WA', 'SA', 'VIC'],
                              "serviceDeliveryType":
                                      ['PRIVATE BAG',
                                       'RESPONSE BAG',
                                       'LOCKED BAG',
                                       'CMB',
                                       'STANDARD',
                                       'COUNTER DELIVERY',
                                       'GENERAL DELIVERY',
                                       'CARE PO',
                                       'GPO BOX',
                                       'MS',
                                       'RSD',
                                       'RMS',
                                       'CMA',
                                       'CPA',
                                       'RMB',
                                       'PO BOX'],
    ]

    Map addressNotUpdateable = ["addressLine1" : '666']

    Map phones = ['mobilePhone': ['0458775544']]

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getMembersApiGateway(TestMember.hasUpdateableAddress)
    }

//    // happy path
//
//    @Ignore
//    // TODO: Nick refactor this test
//    @Jira(stories = ['DSS-30/1.1.1', 'DSS-30/1.1.2', 'DSS-30/1.4'])
//    @ApiGateway(GET = 'members/:memberId?include=contact', PUT = 'members/:memberId/contact')
//    @DelPHI(wsdls = [])
//    public void update_residential_and_mailing_address() {
//        def testMember = TestMember.hasUpdateableAddress
//        def memberId = testMember['memberId']
//        ['residentialAddress', 'mailingAddress'].each { addressKey ->
//            def originalAddressFields = getContactDetails(testMember)[addressKey]
//            def updatedAddressFields = new HashMap(originalAddressFields)
//            addressUpdateables.each { fieldName, values ->
//                values.each { value ->
//                    def prePostValue = updatedAddressFields[fieldName]
//                    def thisIsResidentialServiceDeliveryWhichDoesNotChangeFromStandard = (addressKey == 'residentialAddress' && fieldName == 'serviceDeliveryType')
//                    if (thisIsResidentialServiceDeliveryWhichDoesNotChangeFromStandard) {
//                        // residential address is always
//                        updatedAddressFields[fieldName] = 'STANDARD'
//                    } else {
//                        updatedAddressFields[fieldName] = value
//                    }
//                    def postResponse = restClient
//                            .getAuthenticatedUser()
//                            .putContactItem(memberId, addressKey, updatedAddressFields)
//                    assert postResponse == 200, "Not 200 response: update of field '$fieldName' for address '$addressKey' was not successful"
//                    def postedValue = getContactDetails(testMember)[addressKey][fieldName]
//                    assert ((prePostValue != postedValue) || thisIsResidentialServiceDeliveryWhichDoesNotChangeFromStandard),
//                            "$fieldName ('$postedValue') for address '$addressKey' has stayed the same following update. It should have changed"
//                }
//
//            }
//            // cleaning up member contact details for next test run (pre-per-login code)
//            // TODO: remove this code when per-login test data is available
//            def postResponse = restClient
//                    .getAuthenticatedUser()
//                    .putContactItem(memberId, addressKey, originalAddressFields)
//            assert postResponse == 200, "Not 200 response: Couldn't clean up address '$addressKey'"
//        }
//    }

//
//    @Ignore
//    @Jira(stories = ['DSS-30/1.1.1', 'DSS-30/1.1.2', 'DSS-30/1.4'])
//    @ApiGateway(GET = 'members/:memberId?include=contact', PUT = 'members/:memberId/contact')
//    @DelPHI(wsdls = [])
//    def update_residentialaddress_addressLine1_status202() {
//        def response = updateResidentialContactField('addressLine1', contactDetailsNewValues['addressLine1'])
//        assert response.status == 202,
//                "Update of residential address field 'addressLine1': incorrect status (Actual = ${response.status}, Expected = 202"
//    }


    @Test
    @Ignore('Address not being updated. Nick Mellor to investigate 7/10/2015')
    @Jira(stories = ['DSS-30/1.1.1', 'DSS-30/1.1.2', 'DSS-30/1.4','DSS-292/1.0','DSS-292/1.1','DSS-292/1.3'])
    @ApiGateway(GET = 'members/:memberId?include=contact', PUT = 'members/:memberId/contact')
    @DelPHI(wsdls = ['ManageCustomerUpdateCustomer','CustomerReadByBPID'])
    public void update_successful_residential_address_addressLine1_changeConfirmed() {
        def newValue = addressUpdateables['addressLine1']
        updateOneContactField('residentialAddress', 'addressLine1', newValue)
        def actualValue = getContactDetails(TestMember.hasUpdateableAddress)['residentialAddress']['addressLine1']
        assert actualValue == newValue,
                "Residential address field 'addressLine1' value not updated properly. (Actual: $actualValue, Expected: $newValue)"
    }


    @Test
    @Jira(stories = ['DSS-292/1.2'])
    @ApiGateway(GET = 'members/:memberId?include=contact', PUT = 'members/:memberId/contact')
    @DelPHI(wsdls = ['ManageCustomerUpdateCustomer','CustomerReadByBPID'])
    public void update_unsuccessful_residential_address_addressLine1_changeConfirmed() {
        def newValue = addressNotUpdateable['addressLine1']
        updateOneContactField('residentialAddress', 'addressLine1', newValue)
    }


    @Test
    @Ignore("Not updating successfully. Nick Mellor to investigate 7/10/2015")
    @Jira(stories = ['DSS-30/1.1.1', 'DSS-30/1.1.2', 'DSS-30/1.4','DSS-292/1.0','DSS-292/1.1','DSS-292/1.3'])
    @ApiGateway(GET = 'members/:memberId?include=contact', PUT = 'members/:memberId/contact')
    @DelPHI(wsdls = ['ManageCustomerUpdateCustomer','CustomerReadByBPID'])
    public void update_successful_mailing_address_addressLine1_changeConfirmed() {
        def newValue = addressUpdateables['addressLine1']
        updateOneContactField('mailingAddress', 'addressLine1', newValue)
        def actualValue = getContactDetails(TestMember.hasUpdateableAddress)['mailingAddress']['addressLine1']
        assert actualValue == newValue,
                "Mailing address field 'addressLine1' value not updated properly. (Actual: $actualValue, Expected: $newValue)"
    }


    @Test
    @Jira(stories = ['DSS-292/1.2'])
    @ApiGateway(GET = 'members/:memberId?include=contact', PUT = 'members/:memberId/contact')
    @DelPHI(wsdls = ['ManageCustomerUpdateCustomer','CustomerReadByBPID'])
    public void update_unsuccessful_mailing_address_addressLine1_changeConfirmed() {
        def newValue = addressNotUpdateable['addressLine1']
        updateOneContactField('mailingAddress', 'addressLine1', newValue)
    }

    @TestNotImplemented(reason = "all UI")
    @Jira(stories = ['DSS-32/1.1', 'DSS-32/1.2', 'DSS-32/1.3'])
    public void view_preferences_on_UI() {
    }

    private void updateOneContactField(address, fieldName, value) {
        Map fieldToUpdate = [:]
        def residentialServiceDelivery = (address == 'residentialAddress' && fieldName == 'serviceDeliveryType')
        if (residentialServiceDelivery) {
            fieldToUpdate[fieldName] = 'STANDARD'
        } else {
            fieldToUpdate[fieldName] = value
        }

        fieldToUpdate['postCode'] = '3146'
        fieldToUpdate['townName'] = 'VIC'
        fieldToUpdate['state'] = 'VIC'
        fieldToUpdate['countryCode'] = 'AUS'

        def resp
        try {
            resp = container.getMemberContactDetails(TestMember.hasUpdateableAddress['memberId'])
            Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)
            container.putContactItem(TestMember.hasUpdateableAddress['username'], address, fieldToUpdate,responseMap.ETag)
        } catch (Exception ae) {
            AssertHelper.assertHasFields(ae.response.responseData, ['errorCode','errorDescription','details'])
            assert ae.response.responseData['errorDescription'] == 'Invalid address'
        }


    }

    private updateResidentialContactField(fieldName, newValue) {
        def updateFieldMap = [:]
        updateFieldMap.fieldName = newValue
        def resp = container.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        container.putContactItem(member['memberId'], 'residentialAddress', updateFieldMap,responseMap.get('ETag'))
    }


//    private getContactDetails(member) {
//        def putResp = restClient
//                .getAuthenticatedUser()
//                .getMemberContactDetails(member['memberId'])
//                .getData()
//        def ret = new HashMap(putResp)
//        return ret['contact']
//    }


    // happy path

    @Test
    @Ignore // TODO: fix this test
    @Jira(stories = ['DSS-30/1.1.1', 'DSS-30/1.1.2', 'DSS-30/1.4'])
    @ApiGateway(GET = 'members/:memberId?include=contact', PUT = 'members/:memberId/contact')
    @DelPHI(wsdls = [])
    public void update_residential_and_mailing_address() {
        def testMember = TestMember.hasUpdateableAddress
        def memberId = testMember['memberId']
        ['residentialAddress', 'mailingAddress'].each { addressKey ->
            def originalAddressFields = getContactDetails(testMember)[addressKey]
            def updatedAddressFields = new HashMap(originalAddressFields)
            addressUpdateables.each { fieldName, values ->
                values.each { value ->
                    def prePostValue = updatedAddressFields[fieldName]
                    def thisIsResidentialServiceDeliveryWhichDoesNotChangeFromStandard = (addressKey == 'residentialAddress' && fieldName == 'serviceDeliveryType')
                    if (thisIsResidentialServiceDeliveryWhichDoesNotChangeFromStandard) {
                        // residential address is always
                        updatedAddressFields[fieldName] = 'STANDARD'
                    } else {
                        updatedAddressFields[fieldName] = value
                    }

                    def resp = container.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
                    Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

                    def postResponse = container

                            .putContactItem(memberId, addressKey, updatedAddressFields,responseMap.get('ETag'))
                    assert postResponse == 200, "Not 200 response: update of field '$fieldName' for address '$addressKey' was not response"
                    def postedValue = getContactDetails(testMember)[addressKey][fieldName]
                    assert ((prePostValue != postedValue) || thisIsResidentialServiceDeliveryWhichDoesNotChangeFromStandard),
                            "$fieldName ('$postedValue') for address '$addressKey' has stayed the same following update. It should have changed"
                }

            }
            // cleaning up member contact details for next test run (pre-per-login code)
            // TODO: remove this code when per-login test data is available
            def resp = container.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
            Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

            def postResponse = container

                    .putContactItem(memberId, addressKey, originalAddressFields,responseMap.get('ETag'))
            assert postResponse == 200, "Not 200 response: Couldn't clean up address '$addressKey'"
        }
    }

    // happy path

    @Test
    @Ignore("can't update just the mailingAddressSameAsResidential in API")
    @Jira(stories = ['DSS-30/2.3'])
    @ApiGateway(GET = 'members/:memberId?include=contact', PUT = 'members/:memberId/contact')
    @DelPHI(wsdls = [])
    public void mailing_address_same_as_residential() {
        def testMember = TestMember.hasUpdateableAddress
        def memberId = testMember['memberId']
        [false, true].each { mailingAddressSame ->
            def contactDetails = getContactDetails(testMember)
            def retailAddressFields = contactDetails['residentialAddress']
            // ensure there is a mailing address
            def mailingAddressFields = contactDetails['mailingAddress'] ?: retailAddressFields
            contactDetails['mailingAddressSameAsResidential'] = mailingAddressSame
            def postResponse = container
                    .'put contact item'(memberId, 'mailingAddress', mailingAddressFields)
            assert postResponse == 200, "Not 200 response: update of mailing address address was not response"
            postResponse = container
                    .'put contact item'(memberId, 'mailingAddressSameAsResidential', false)
            assert postResponse == 200, "Not 200 response: update of mailing address address was not response"
            // TODO: Simon to fix API so PUTs can accept just the 'mailingAddressSameAsResidential' flag
            def postedValue = getContactDetails(testMember)['mailingAddress']
            if (mailingAddressSame) {
                assert postedValue == null, "Mailing address should be deleted if 'mailingAddressSameAsResidential' flag is set"
            } else {
                assert postedValue != null, "Mailing address should be present if 'mailingAddressSameAsResidential' flag is cleared"
            }
        }
    }


    @Test
    @Ignore('Failing to update on Selphi. Nick Mellor to investigate 07/10/2015')
    @Jira(stories = ['DSS-32/1.4'])
    @ApiGateway(PUTS = ["members/:memberId?include=contact", 'members/:memberId/contact'])
    @DelPHI(wsdls = [])
    public void update_updateable_preference() {
        def testMember = TestMember.hasUpdateableAddress
        def memberId = testMember['memberId']
        getContactDetails(testMember)['preferences'].each { channel, modes ->
            modes.each { mode, notNeeded ->

                [false, true].each { preferenceSetting ->
                    def modeItem = [:]
                    modeItem[channel] = [:]
                    modeItem[channel][mode] = ['preference': preferenceSetting]

                    def resp = container.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
                    Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

                    def postResponse = container
                            .putContactItem(memberId, 'preferences', modeItem,responseMap.get('ETag'))
                    assert postResponse == 200, "Not 200 response: update of '$service' preference '${mode}' was not response"
                    def serviceSettings = getContactDetails(testMember)['preferences'][channel][mode]
                    if (serviceSettings['updateable']) {
                        assert serviceSettings['preference'] == preferenceSetting,
                                "service PHONE is updateable but has not updated correctly"
                    }
                }
            }

        }


    }

    private getContactDetails(member) {
        def resp = container

                .getMemberContactDetails(member['memberId'])
                .getData()
        def ret = new HashMap(resp)
        return ret['contact']
        def mailingAddress = mailingAddressWithSameFlag(false)
        assert mailingAddress == null,
                "Mailing address should be deleted if 'mailingAddressSameAsResidential' flag is set"
    }

    private mailingAddressWithSameFlag(boolean mailingAddressSameFlag) {
        def testMember, memberId
        def contactDetails = getContactDetails(testMember)
        def residentialAddressFields = contactDetails['residentialAddress']
        // ensure there is a mailing address: if there isn't, create one
        def mailingAddressFields = contactDetails['mailingAddress'] ?: residentialAddressFields
        contactDetails['mailingAddressSameAsResidential'] = mailingAddressSameFlag
        container.'put contact item'(memberId, 'mailingAddress', mailingAddressFields)
        container.'put contact item'(memberId, 'mailingAddressSameAsResidential', false)
        getContactDetails(testMember)['mailingAddress']
    }

//
//    @Jira(stories = ['DSS-32/1.4'])
//    @ApiGateway(PUTS = ["members/:memberId?include=contact", 'members/:memberId/contact'])
//    @DelPHI(wsdls = [])
//    public void update_updateable_preference() {
//        def testMember = TestMember.hasUpdateableAddress
//        def memberId = testMember['memberId']
//        getContactDetails(testMember)['preferences'].each { channel, modes ->
//            modes.each { mode, notNeeded ->
//
//                [false, true].each { ft ->
//                    def modeItem = [:]
//                    modeItem[channel] = [:]
//                    modeItem[channel][mode] = ['preference': ft]
//                    def postResponse = restClient
//
//                            .putContactItem(memberId, 'preferences', modeItem)
//                    assert postResponse == 200, "Not 200 response: update of '$service' preference '${mode}' was not response"
//                    def serviceSettings = getContactDetails(testMember)['preferences'][channel][mode]
//                    if (serviceSettings['updateable']) {
//                        assert serviceSettings['preference'] == ft,
//                                "service PHONE is updateable but has not updated correctly"
//                    }
//                }
//            }
//
//        }
//
//
//    }


}