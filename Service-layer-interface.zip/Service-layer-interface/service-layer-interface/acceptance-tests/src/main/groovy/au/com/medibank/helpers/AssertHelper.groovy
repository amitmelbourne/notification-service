package au.com.medibank.helpers

import static org.junit.Assert.assertFalse
import static org.junit.Assert.assertTrue


class AssertHelper {

    private static void assertHasFields(objName, obj, fields) {
        fields.each { field ->
            assertTrue(obj.containsKey(field))
        }
    }

    private static void assertHasFields(obj, fields) {
        fields.each { field ->
            assertTrue(obj.containsKey(field))
        }
    }

    private static void assertNotHasFields(obj, fields) {
        fields.each { field ->
            assertFalse(obj.containsKey(field))
        }
    }
}
