package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import au.com.medibank.helpers.AssertHelper
import org.junit.BeforeClass
import org.junit.Test

class ViewMultiplePremiumPayer {

    static PoliciesApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasPoliciesWithMultiplePayer)
    }

    @Jira(story = 'DSS-276/1.1')
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['ProductReadByProdOptCd', 'CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicyReadByMasterPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void multiple_premium_payer_in_amount_with_individual_corp() {
        def responseData = container.getPolicy(TestPolicy.hasMultiplePayerWithIndividualAndCorpInAmount['policy']).getData()

        responseData['members'].each { eachMember ->
            AssertHelper.assertHasFields eachMember, ['payment']
            AssertHelper.assertHasFields eachMember['payment'], ['account', 'shareAmount', 'payRemainingAmount']
            AssertHelper.assertNotHasFields eachMember['payment'], ['sharePercentage']

            validateIndividualAndOrganization(eachMember)
        }
    }

    @Jira(story = 'DSS-276/1.1')
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['ProductReadByProdOptCd', 'CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicyReadByMasterPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void multiple_premium_payer_in_amount_with_individual() {
        def responseData = container.getPolicy(TestPolicy.hasMultiplePayerWithIndividualInAmount['policy']).getData()

        responseData['members'].each { eachMember ->
            AssertHelper.assertHasFields eachMember, ['payment']
            AssertHelper.assertHasFields eachMember['payment'], ['account', 'shareAmount', 'payRemainingAmount']
            AssertHelper.assertNotHasFields eachMember['payment'], ['sharePercentage']

            validateIndividualAndOrganization(eachMember)
        }
    }

    @Jira(story = 'DSS-276/1.1')
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['ProductReadByProdOptCd', 'CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicyReadByMasterPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void multiple_premium_payer_in_percentage_with_individual_corp() {
        def responseData = container.getPolicy(TestPolicy.hasMultiplePayerWithIndividualAndCorpInPercentage['policy']).getData()

        responseData['members'].each { eachMember ->
            AssertHelper.assertHasFields eachMember, ['payment']
            AssertHelper.assertHasFields eachMember['payment'], ['account', 'sharePercentage', 'payRemainingAmount']
            AssertHelper.assertNotHasFields eachMember['payment'], ['shareAmount']

            validateIndividualAndOrganization(eachMember)
        }
    }

    @Jira(story = 'DSS-276/1.1')
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['ProductReadByProdOptCd', 'CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicyReadByMasterPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void multiple_premium_payer_in_percentage_with_individual() {
        def responseData = container.getPolicy(TestPolicy.hasMultiplePayerWithIndividualInPercentage['policy']).getData()

        responseData['members'].each { eachMember ->
            AssertHelper.assertHasFields eachMember, ['payment']
            AssertHelper.assertHasFields eachMember['payment'], ['account','sharePercentage', 'payRemainingAmount']
            AssertHelper.assertNotHasFields eachMember['payment'], ['shareAmount']

            validateIndividualAndOrganization(eachMember)
        }
    }

    private validateIndividualAndOrganization(memberData) {

        memberData['payment'].each { eachPaymentDetails ->

            if (eachPaymentDetails.equals('account')) {
                AssertHelper.assertHasFields eachPaymentDetails, ['accountType', 'id']

                if ((eachPaymentDetails['accountType'].equals('Bank')) || (eachPaymentDetails['accountType'].equals('CreditCard'))) {
                    AssertHelper.assertHasFields memberData, ['individual']
                    AssertHelper.assertNotHasFields memberData, ['organization']
                } else if (eachPaymentDetails['accountType'].equals('Payroll')) {
                    AssertHelper.assertHasFields memberData, ['organization']
                    AssertHelper.assertNotHasFields memberData, ['individual']
                }
            }
        }
    }
}
