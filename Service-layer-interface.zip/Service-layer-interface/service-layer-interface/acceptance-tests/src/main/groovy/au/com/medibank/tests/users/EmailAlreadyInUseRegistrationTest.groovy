package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.MembersApiClient
import org.junit.Before
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertErrorDescription
import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class EmailAlreadyInUseRegistrationTest {
    private MembersApiClient registrationRequest
    private response


    @Before
    public void setup() {
        registrationRequest =registrationRequest = ApiClientFactory.getMembersApiClient()
        response = this.registrationRequest.register(UserTestData.REGISTRATION_REQUEST_WITH_EMAIL_ALREADY_IN_USE)
    }



    @Jira(story = "DSS-23/1.1")
    @Test
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void request_for_registration_with_email_already_in_use_should_return_409_code() {
        assertStatusCode(response, 409)
    }



    @Jira(story = "DSS-23/1.1")
    @Test
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void request_for_registration_with_email_already_in_use_should_have_an_error_message() {
        assertErrorDescription(this.response, UserTestData.REGISTRATION_REQUEST_WITH_EMAIL_ALREADY_IN_USE.getErrorDescription(),
                "Error description either not return OR might differ with expected for blank mail address")
    }


}