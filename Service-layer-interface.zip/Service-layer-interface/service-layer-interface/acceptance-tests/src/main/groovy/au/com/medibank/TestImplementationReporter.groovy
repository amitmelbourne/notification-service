package au.com.medibank

import au.com.medibank.annotations.TestNotImplemented
import au.com.medibank.testCoverageReporting.AnnotationCollator
import au.com.medibank.testCoverageReporting.TestReportStringFormatter
import org.junit.Ignore
import org.junit.Test
import org.reflections.Reflections
import org.reflections.scanners.MethodAnnotationsScanner
import org.reflections.util.ClasspathHelper
import org.reflections.util.ConfigurationBuilder
import org.reflections.util.FilterBuilder

import java.nio.file.Files
import java.nio.file.Paths

import static au.com.medibank.testCoverageReporting.AnnotationConfig.getReportableAnnotations
import static au.com.medibank.testCoverageReporting.AnnotationConfig.limitToStories
import static au.com.medibank.testCoverageReporting.Utils.*

public class TestImplementationReporter {
    def reflections
    def allNormalisedTests = [:].withDefault { [:] }
    def selectedTestData = [:]
    def testsWithAnnotations = [:].withDefault { [] }
    def testsMissingAnnotations = [:]
    def tests
    def testNames
    def ignoredTests
    def ignoredTestNames
    def ignoredReasons
    def notImplementedReasons
    def selectedIgnoredTestNames
    def notImplementedTests
    def notImplementedTestNames
    def inactiveTests
    def collations
    def tsrRows
    def minimumUniqueNames = [:]

    TestImplementationReporter() {
        reflections = createReflections()
        tests = reflections.getMethodsAnnotatedWith(Test)
    }


    private Reflections createReflections() {
        new Reflections(new ConfigurationBuilder()
                .filterInputsBy(new FilterBuilder().includePackage("au.com.medibank.tests"))
                .setUrls(ClasspathHelper.forPackage("au.com.medibank.tests"))
                .setScanners(new MethodAnnotationsScanner()))
    }

    private def normaliseAnnotations() {
        // one row per annotation param value per test
        // all plural parameters converted to multiple singular
        // e.g. @DelPHI(wsdls = ['PolicyReadByBPID', 'ManageCustomerPaymentAccount', 'ManagePolicyPremiumPayer'])
        // becomes:
        //      @DelPHI(wsdl = 'PolicyReadByBPID')
        //      @DelPHI(wsdl = 'ManageCustomerPaymentAccount')
        //      @DelPHI(wsdl = 'ManagePolicyPremiumPayer')
        tests.each { test ->
            test.getAnnotations().each { annotation ->
                def testData = [:].withDefault { [] }
                def annotationClass = littleClass(annotation.annotationType().name)
                def match = reportableAnnotations[annotationClass]
                if (match) {
                    def annotationParams = annotation.h.memberValues
                    annotationParams.each { paramName, paramValue ->
                        if (paramName in match.singular && paramValue != '') {
                            testData[paramName].add(paramValue)
                            testsWithAnnotations[annotationClass].add(testNameWithJavaClass(test))
                        } else if (paramName in match.plural && paramValue != []) {
                            def equivSingular = match.singular[match.plural.indexOf(paramName)]
                            // TODO: detect edge case: singular null paramValue
                            testData[equivSingular].addAll(paramValue)
                            testsWithAnnotations[annotationClass].add(testNameWithJavaClass(test))
                        }
                    }
                }
                if (testData != [:]) {
                    allNormalisedTests[testNameWithJavaClass(test)].putAll(testData)
                }
            }

        }
        buildMinimumUniqueNames()
    }

    private void selectedStoriesOnly() {
        if (limitToStories) {
            Set<String> selectedTestNames = []
            allNormalisedTests.each { testName, testData ->
                testData.each { paramName, stories ->
                    if (paramName == 'story') {
                        stories.each { fullJiraRef ->
                            if (jiraStory(fullJiraRef) in limitToStories)
                                selectedTestNames.add(testName)
                        }
                    }
                }
            }
            selectedTestNames.each { testName ->
                selectedTestData[testName] = allNormalisedTests[testName]
            }
        } else {
            selectedTestData = allNormalisedTests
        }
    }

    private void buildCollations(TestImplementationReporter reporter) {
        normaliseAnnotations()
        selectedStoriesOnly()
        testNames = listOfTestNames(tests)
        ignoredTests = reflections.getMethodsAnnotatedWith(Ignore)
        notImplementedTests = reflections.getMethodsAnnotatedWith(TestNotImplemented)
        ignoredTestNames = listOfTestNames(ignoredTests)
        notImplementedTestNames = listOfTestNames(notImplementedTests)
        def reasons = ignoredTests.collect { test ->
            test.declaredAnnotations.find { ann ->
                littleClass(ann.h.type.name) == 'Ignore'
            }.value()
        }
        ignoredReasons = [ignoredTestNames*.toString(), reasons].transpose().collectEntries { it }
        def nIReasons = notImplementedTests.collect { test ->
            def foundNIParam = test.getAnnotations().find { annotation ->
                littleClass(annotation.annotationType().name) == 'TestNotImplemented'
            }
            foundNIParam != null ? foundNIParam.h.memberValues.reason : ''
        }
        notImplementedReasons = [notImplementedTestNames*.toString(), nIReasons].transpose().collectEntries { it }
        selectedIgnoredTestNames = ignoredTestNames.intersect(selectedTestData.keySet() as Set)
        inactiveTests = ignoredTests
        reportableAnnotations.each { annotation, _ ->
            testsMissingAnnotations[annotation] =
                    (selectedTestData.keySet() as Set) - testsWithAnnotations[annotation] - inactiveTests
        }
        def annotationCollator = new AnnotationCollator(reporter)
        collations = annotationCollator.collateAllAnnotations()
        tsrRows = annotationCollator.collateTsr()
    }

    private static listOfTestNames(testCollection) {
        testCollection.collect { test -> testNameWithJavaClass(test) } as Set
    }

    String minimumUniqueName(String javaName) {
        def currentLevel = 1
        String shortName = ''
        while (allNormalisedTests.findAll { jName, _ ->
            shortName = partialClass(javaName, currentLevel)
            jName.endsWith(shortName)
        }.size() > 1) {

            ++currentLevel

        }

        return shortName
    }

    private static String partialClass(String javaName, int level) {
        javaName.tokenize('.')[-level..-1].join('.')
    }

    public void buildMinimumUniqueNames() {
        allNormalisedTests.keySet().each { javaName ->
            minimumUniqueNames[javaName] = minimumUniqueName(javaName)
        }
    }

    public static void main(String[] args) {
        def reporter = new TestImplementationReporter()
        // TODO: reading from and and writing to same object: is this good design?!
        reporter.buildCollations(reporter)
        def formatter = new TestReportStringFormatter(reporter)
        String detailReports = formatter.annotationReportFormatter()
        System.out.print(detailReports)
        Files.write(Paths.get("./test_coverage_report.txt"), detailReports.getBytes())
        String tsrReport = formatter.csvTsrReport()
        Files.write(Paths.get("./tsr_report.csv"), tsrReport.getBytes())
    }
}