package au.com.medibank.testCoverageReporting

class AnnotationConfig {
    static final reportableAnnotations = [
            'ApiGateway':
                    [
                            'heading' : 'API Gateway Coverage',
                            'singular': ['GET', 'POST', 'PUT'],
                            'plural'  : ['GETS', 'POSTS', 'PUTS']
                    ],
            'Jira'      :
                    [
                            'heading' : 'Jira Story Coverage',
                            'singular': ['story'],
                            'plural'  : ['stories']
                    ],
            'DelPHI'    :
                    [
                            'heading' : 'WSDL Story Coverage',
                            'singular': ['wsdl'],
                            'plural'  : ['wsdls']
                    ]
    ]


    static final limitToStories = [
            /* Examples:
                'DSS-29',
                'DSS-32',
                'DSS-46',
                'DSS-80',
                'DSS-116',
                'DSS-159',
            */
            'DSS-39',
            'DSS-46',
            'DSS-80',
            'DSS-116',
            'DSS-159',
            'DSS-215',
            'DSS-269',
            'DSS-276',
            'DSS-122',
            'DSS-208',
            'DSS-226',
            'DSS-250',
            'DSS-253',
            'DSS-254',
            'DSS-256',
            'DSS-264',
            'DSS-286',
            'DSS-292',
            'DSS-23',
            'DSS-24',
            'DSS-43',
            'DSS-54',
            'DSS-90',
            'DSS-107',
            'DSS-139',
            'DSS-148',
            'DSS-160',
            'DSS-180',
            'DSS-233',
            'DSS-252',
            'DSS-279',
            'DSS-282',
            'DSS-296',
            'DSS-297',
            'DSS-310',
            'DSS-355',
            'DSS-375',

    ]
}
