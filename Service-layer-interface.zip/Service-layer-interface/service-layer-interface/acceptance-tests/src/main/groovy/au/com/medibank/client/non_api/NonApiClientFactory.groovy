package au.com.medibank.client.non_api

import au.com.medibank.Config
import groovyx.net.http.RESTClient

public class NonApiClientFactory {
    public static TokenMicroServiceClient getTokenMicroService(){
        return new TokenMicroServiceClient(new Config().getTokenMicroServiceUrl());
    }

    public static OktaClient getOktaClient(){
        def config = new Config();

        Map<String, Object> hashMap = ["proxyHost"    : config.getOktaProxyHost(),
                       "proxyPort"    : config.getOktaProxyPort(),
                       "proxyProtocol": config.getOktaProtocol(),
                       "skipProxy": config.getSkipOktaProxy(),
        ]
        return new OktaClient(new Config().getOktaUrl(), new Config().getOktaAuthToken(), hashMap);
    }

    public static SelphiClient getSelphiClient() {
        def client = new RESTClient(new Config().getSelphiBackdoorUrl())
        new SelphiClient(client)
    }
}
