package au.com.medibank.tests.policies

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.annotations.TestNotImplemented
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.After
import org.junit.Before
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class NonCorpHappyPath {

    PoliciesApiGateway apiGatewayInstance
    def testPolicy
    def getPolicyRespBeforeExcessChange
    def putResp
    def getResp
    def changeStateId
    def final expectedOldExcessCode = 'EX02' // TODO: these literals need to be removed for SIT
    def final newExcessCode = 'EX03'

    @Before
    public void setup() {
        apiGatewayInstance = ApiGatewayClientFactory.getPoliciesApiGateway(
                TestMember.nonCorpHas2OrMoreExcessLevels)
        testPolicy = TestPolicy.nonCorpHas2OrMoreExcessLevels
        getPolicyRespBeforeExcessChange = apiGatewayInstance.getPolicy(testPolicy.policy)
        getResp = apiGatewayInstance.getExcessChanges(testPolicy.policy)
        changeStateId = getPolicyRespBeforeExcessChange.getData().changeStateID

        def resp = apiGatewayInstance.getExcessChanges(testPolicy.policy)
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        putResp = apiGatewayInstance.putExcessChanges(testPolicy.policy, newExcessCode, responseMap.get("ETag"))
    }


    @Test
    @Jira(stories = ['DSS-90/1.1', 'DSS-90/1.12c'])
    @ApiGateway(PUT = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void change_excess_active_when_hosp_prod_component_has_multi_excess_level_options() {
        assertStatusCode(putResp, 200)
    }


    @Test
    @Jira(story = 'DSS-90/1.3')
    @ApiGateway(GET = 'policies/:id')
    @DelPHI(wsdl = 'PolicyReadByBPID')
    public void hosp_prod_member_can_see_name() {
        assert 'name' in getPolicyRespBeforeExcessChange.getData().product,
                "Name of cover is not available for policy '${testPolicy.policy}' and was expected"
    }

    @Test
    @Jira(story = 'DSS-90/1.5')
    @ApiGateway(GET = 'policies/:id')
    @DelPHI(wsdl = 'PolicyReadByBPID')
    public void hosp_prod_member_can_see_excess_code_in_policy() {
        assert 'excessCode' in getPolicyRespBeforeExcessChange.getData().product,
                'Excess code is not available on this policy and was expected'
    }

    @Test
    @Jira(story = 'DSS-90/1.6a')
    @ApiGateway(PUT = 'policies/:id/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void hosp_prod_member_can_see_current_excess_level() {
        assert 'code' in getResp.getData().current,
                "Expected to be able to see currently chosen excess level for policy '${testPolicy.policy}'. Could not."
    }

    @Test
    @Jira(story = 'DSS-90/1.6b')
    @ApiGateway(PUT = 'policies/:id/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void hosp_prod_member_can_see_current_excess_choices() {
        def noOfChoices = getResp.getData().choice.size()
        assert noOfChoices == 3,
                "Expected to see 3 choices for this policy."
    }

    @Test
    @Jira(story = 'DSS-90/1.8')
    @ApiGateway(PUT = 'policies/:id/product/excess', GET = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void hosp_prod_member_can_change_excess_level() {
        def getPolicyRespAfterChange = apiGatewayInstance.getPolicy(testPolicy.policy)
        assert getPolicyRespAfterChange.getData().product.excessCode == newExcessCode
    }


    @Test
    @Jira(stories = ['DSS-90/1.9', 'DSS-90/1.12a'])
    @ApiGateway(PUT = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void display_excess_as_per_policy_specific_pay_frequency() {
        assert putResp.getData().premiums.current.paymentAmount[0] >= 0.0,
                "Expected premium amount to be greater than zero following an excess change"
    }

    @Test
    @Jira(story = 'DSS-90/1.12b')
    @ApiGateway(PUT = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void date_paid_to_present_if_change_excess_successful() {
        // Groovy Badness:
        //   if a['datePaidTo'] == '' and a['b'] == 1:
        //      'datePaidTo' in a == false
        //      'b' in a == true
        // BUT...
        //      'datePaidTo' in a.keySet() == true
        // NB datePaidTo may be an empty string-- and be careful of unexpected behaviour of Groovy 'in' operator
        assert 'datePaidTo' in putResp.getData().keySet(),
                "Expected 'datePaidTo' field in policy '${testPolicy.policy}'. Not found."
    }


    @Test
    @TestNotImplemented(reason = 'No programmatic access to backend/cacheing concerns')
    @Jira(story = 'DSS-90/1.12c')
    @ApiGateway(PUT = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void backend_stores_change_of_excess_level() {
    }



    @Jira(story = 'DSS-90/1.13')
    @ApiGateway(PUT = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void display_dual_rate_from_backend_on_submit() {
        assert putResp.getData().premiums.future.size() > 0,
                "Expected dual rate. None present"
    }


    @Jira(story = 'DSS-90/1.14')
    @ApiGateway(PUT = 'policies/:id/product/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void do_not_display_you_are_covered_message_if_dpt_blank() {
        assert putResp.getData().datePaidTo == '',
                "Expected blank 'datePaidTo' field in policy '${testPolicy.policy}'"
    }

    @After
    public void teardown() {
        def resp = apiGatewayInstance.getExcessChanges(testPolicy.policy)
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        putResp = apiGatewayInstance.putExcessChanges(testPolicy.policy, newExcessCode, responseMap.get("ETag"))
    }
}
