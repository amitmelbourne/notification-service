package au.com.medibank.helpers

import org.apache.commons.lang.time.FastDateFormat

import javax.xml.datatype.DatatypeFactory
import javax.xml.datatype.XMLGregorianCalendar
import java.text.DateFormat
import java.text.SimpleDateFormat

/**
 * Created by m47333 on 3/07/2015.
 */
class DateHelper {
    private static datatypeFactory = DatatypeFactory.newInstance();
    private final static String FORMAT_YYYY_MM_DD = "yyyy-MM-dd";

    static XMLGregorianCalendar getXMLGregorianCalendar(int year, int month, int day) {
        def c = new GregorianCalendar()
        c.set(year, month, day)
        datatypeFactory.newXMLGregorianCalendar(c)
    }

    static XMLGregorianCalendar getXMLGregorianCalendar(int field, int value) {
        def c = new GregorianCalendar()
        c.add(field, value)
        datatypeFactory.newXMLGregorianCalendar(c)
    }

    static XMLGregorianCalendar getXMLGregorianCalendar() {
        def c = new GregorianCalendar()
        datatypeFactory.newXMLGregorianCalendar(c)
    }


    public static String xmlGregorianCalendarToString(XMLGregorianCalendar calendar) {
        if (calendar == null)
            return "";
        FastDateFormat fdf = FastDateFormat.getInstance(FORMAT_YYYY_MM_DD)
        return fdf.format(calendar.toGregorianCalendar().getTime());
    }

    public static String xmlGregorianCalendarToString() {
        return xmlGregorianCalendarToString(getXMLGregorianCalendar())
    }

    def static String getDateInPast(int numberOfDays) {
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd")
        Calendar calender = Calendar.getInstance()

        Date today = new Date()
        calender.setTime(today)
        calender.add(Calendar.DAY_OF_MONTH, -numberOfDays)
        Date pastday = calender.getTime()

        return format.format(pastday)
    }

    def static Date dateFormatter(String date) {
        DateFormat format = new SimpleDateFormat("yyyy-MM-dd")
        return format.parse(date)
    }

}
