package au.com.medibank.testCoverageReporting

import au.com.medibank.TestImplementationReporter

import static au.com.medibank.testCoverageReporting.Utils.*

class AnnotationCollator {

    TestImplementationReporter reporter

    AnnotationCollator(TestImplementationReporter rprt) {
        // TODO: testsImplementationStatistics = new TestStatistics().run()
        reporter = rprt
    }

    public collateAllAnnotations() {
        def collations = [:]

        AnnotationConfig.reportableAnnotations.each { annotation, _ ->
            collations[annotation] = this.invokeMethod("collate$annotation", null)
        }
        collations
    }


    private collateJira() {
        def jiraAnnotations = selectForAnnotation('Jira')
        jiraAnnotations.sort { a, b ->
            jiraOrdering(a) <=> jiraOrdering(b)
        }
        jiraAnnotations.groupBy(
                { AnnotationInstance jiraAnnotation ->
                    def fullJiraRef = jiraAnnotation.paramValue
                    jiraStory(fullJiraRef)
                },
                { AnnotationInstance jiraAnnotation ->
                    def fullJiraRef = jiraAnnotation.paramValue
                    jiraScenario(fullJiraRef) ? "Scenario ${jiraScenario(fullJiraRef)}" : '[no scenario]'
                }
        )
        // TODO: weed out unselected stories
    }


    private List<AnnotationInstance> selectForAnnotation(String annotation) {
        def annotations = []
        AnnotationConfig.reportableAnnotations."$annotation".singular.each { param ->
            reporter.selectedTestData.findAll { _, data ->
                param in data.keySet()
            }.collect { method, data ->
                [method, data[param]]
            }.each { method, annotationValues ->
                annotationValues.each { paramValue ->
                    def annotationInstance = new AnnotationInstance()
                    //annotationInstance.annotationName = ''
                    annotationInstance.testMethod = method
                    annotationInstance.paramName = param
                    annotationInstance.paramValue = paramValue
                    if (method in reporter.ignoredTestNames) {
                        annotationInstance.ignored = true
                        annotationInstance.ignoredReason = reporter.ignoredReasons[method]
                    }
                    if (method in reporter.notImplementedTestNames) {
                        annotationInstance.notImplemented = true
                        annotationInstance.notImplementedReason = reporter.notImplementedReasons[method]
                    }
                    annotations.add(annotationInstance)
                }
            }
        }
        annotations
    }

    private static String jiraOrdering(annotationInstance) {
        def fullJiraStory = annotationInstance.paramValue
        def method = annotationInstance.testMethod
        def ordering = [jiraStoryNumber(fullJiraStory).toString().padLeft(4)] +
                jiraScenarioOrdering(jiraScenario(fullJiraStory)) + [method]
        ordering.join(':')
    }

    private static List jiraScenarioOrdering(jiraScenario) {
        // ensures '1.2.12a' is sorted after '1.2.9' in same story
        def final maxScenarioDepth = 8
        def scenarioIds = jiraScenario.tokenize('.')
        def scenarioParts = [];
        def isDigit = { letterOrDigit -> letterOrDigit in '0'..'9' }
        // total scenario ordering must be same width for every scenario, so use padded blanks
        // for unused scenario levels
        maxScenarioDepth.times { pos ->
            def scenarioPart = scenarioIds[pos].collect { it }
            String numericPart = scenarioPart.takeWhile(isDigit).join().padLeft(5)
            String theRest = scenarioPart.dropWhile(isDigit).join().padRight(5)
            scenarioParts[pos] = numericPart + theRest
        }
        scenarioParts
    }


    private collateApiGateway() {
        def apiAnnotations = selectForAnnotation('ApiGateway')
        apiAnnotations.sort { a, b ->
            apiGatewayOrdering(a) <=> apiGatewayOrdering(b)
        }
        apiAnnotations.groupBy(
                { apiAnnotation ->
                    def fullApiCall = apiAnnotation.paramValue
                    '/' + apiService(fullApiCall)
                },
                { apiAnnotation ->
                    def httpMethod = apiAnnotation.paramName
                    "Method $httpMethod"
                },
                { apiAnnotation ->
                    def fullApiCall = apiAnnotation.paramValue
                    fullApiCall ?: '[no detail]'
                }
        )
    }

    private static String apiGatewayOrdering(AnnotationInstance apiAnnotation) {
        def fullUrl = apiAnnotation.paramValue
        def getPostPut = apiAnnotation.paramName
        def method = apiAnnotation.testMethod
        return [
                apiService(fullUrl),
                getPostPut,
                apiServiceDetail(fullUrl),
                method
        ].join(':')
    }

    private collateDelPHI() {
        def wsdlRefs = selectForAnnotation('DelPHI')
        wsdlRefs.sort { a, b ->
            wsdlOrdering(a) <=> wsdlOrdering(b)
        }
        wsdlRefs.groupBy { AnnotationInstance wsdlRef ->
            def wsdlName = wsdlRef.paramValue
            wsdlName
        }
    }

    private static String wsdlOrdering(AnnotationInstance wsdlAnnotation) {
        def wsdlName = wsdlAnnotation.paramValue
        def method = wsdlAnnotation.testMethod
        return "$wsdlName:$method"
    }

    public collateTsr() {
        def tsrData = selectForAnnotation('Jira')
        tsrData.sort { a, b ->
            tsrOrdering(a) <=> tsrOrdering(b)
        }
        def tsrGrouped = tsrData.groupBy(
                { AnnotationInstance jiraAnnotation ->
                    def fullJiraRef = jiraAnnotation.paramValue
                    jiraStoryNumber(fullJiraRef)
                }
        )
        def tsrTableData = tsrGrouped.collect { _, tests ->
            def fullJiraRef = tests[0].paramValue
            def firstActiveTest = tests.findAll {
                test -> !test.ignored
            }[0]
            if (firstActiveTest) {
                [jiraStory(fullJiraRef), reporter.minimumUniqueNames[firstActiveTest.testMethod], 'passed']
            } else {
                [jiraStory(fullJiraRef), '*** NO ACTIVE TESTS ***', 'not automated']
            }
        }
        return [['Story', 'Test Method', 'Pass/Fail']] + tsrTableData
    }

    private static String tsrOrdering(annotationInstance) {
        def fullJiraStory = annotationInstance.paramValue
        jiraStoryNumber(fullJiraStory).toString().padLeft(4)
    }


}