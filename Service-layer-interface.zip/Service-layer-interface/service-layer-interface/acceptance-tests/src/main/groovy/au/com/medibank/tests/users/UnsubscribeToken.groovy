package au.com.medibank.tests.authentication

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.data.TestMember
import org.apache.commons.codec.binary.Base64
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers
import org.jose4j.jwe.JsonWebEncryption
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers
import org.jose4j.jwk.JsonWebKey
import org.jose4j.jws.AlgorithmIdentifiers
import org.jose4j.jws.JsonWebSignature
import org.jose4j.jwt.JwtClaims
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

import java.security.Key
import java.security.Security

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class UnsubscribeToken {
    static MembersApiGateway container;
    def static localToken
    static String computershareKey

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getMembersApiGateway(TestMember.hasDirectDebit)
        computershareKey = "computershareformplemailcampaign"
    }

    @Test
    @Ignore("waiting for Jarrod's investigation")
    @ApiGateway(POST = "members/unsubscribe")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'ManagerPolicyPremiumPayer', 'ManageCustomerPaymentAccount'])
    @Jira(story = "DSS-148")
    public void successful_unsubscribe_preferences() {
        def key = loadKey(computershareKey)
        def bpId = TestMember.hasReceivedBenefitsAccount['memberId']
        def medium = "EMAIL"
        def category = "MANISH"
        localToken = generateLocalToken(bpId,medium,category, key)

        MembersApiGateway instance = new MembersApiGateway(container.getRestClientInstance())
        def response = instance.unsubscribe(localToken)


        assertStatusCode(response, 200)
    }


    @Test
    @Ignore("waiting for Jarrod's investigation")
    @ApiGateway(POST = "members/unsubscribe")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'ManagerPolicyPremiumPayer', 'ManageCustomerPaymentAccount'])
    @Jira(story = "DSS-148")
    public void unsuccessful_unsubscribe_preferences() {
        def key = loadKey(computershareKey)
        def bpId = TestMember.hasReceivedBenefitsAccount['memberId']
        def medium = "EMAIL"
        def category = "MARKETING"
        localToken = generateLocalToken(bpId,medium,category, key)

        MembersApiGateway instance = new MembersApiGateway(container.getRestClientInstance())
        def response = instance.unsubscribe(localToken + "123456")

    }


    @Ignore("This is not in scope of story dss-148")
    @Test
    @ApiGateway(POST = "members/unsubscribe")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'ManagerPolicyPremiumPayer', 'ManageCustomerPaymentAccount'])
    @Jira(story = "DSS-148")
    public void unsubscribe_preferences_with_non_updatable_field() {
        def key = loadKey(computershareKey)
        def bpId = TestMember.hasReceivedBenefitsAccount['memberId']
        def medium = "EMAIL"
        def category = "SERVICE"
        localToken = generateLocalToken(bpId,medium,category, key)

        MembersApiGateway instance = new MembersApiGateway(container.getRestClientInstance())
        def response = instance.unsubscribe(localToken + "123456")

        assertStatusCode(response, 200)
    }

    def generateLocalToken(String bpId, String medium, String category, Key key) {
        //
        // Prepare our sample token
        JwtClaims claims = new JwtClaims()
        claims.setIssuedAtToNow()
        claims.setClaim("bpid", bpId)
        claims.setClaim("medium", medium)
        claims.setClaim("category", category)
        String claimsJson = claims.toJson()

        // Sign
        JsonWebSignature jws = new JsonWebSignature()
        jws.setPayload(claimsJson)
        jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.HMAC_SHA256)
        jws.setKey(key)
        String signedJwt = jws.getCompactSerialization()

        // Encrypt using JWE
        JsonWebEncryption jwe = new JsonWebEncryption()
        jwe.setPayload(signedJwt)
        jwe.setContentTypeHeaderValue("JWT")
        jwe.setAlgorithmHeaderValue(KeyManagementAlgorithmIdentifiers.DIRECT)

        jwe.setEncryptionMethodHeaderParameter(ContentEncryptionAlgorithmIdentifiers.AES_256_GCM)
        jwe.setKey(key)
        String encryptedJwt = jwe.getCompactSerialization()


        return encryptedJwt
    }

    def loadKey(String computershareKey) {
        Security.addProvider(new BouncyCastleProvider())
        Base64 encoder = new Base64(true)
        byte[] encodedBytes = encoder.encode(computershareKey.getBytes())
        def encodedKey = new String(encodedBytes)
        def keyJson = "{\"kty\":\"oct\",\"k\":\"" + encodedKey + "\"}"
        JsonWebKey webKey = JsonWebKey.Factory.newJwk(keyJson)
        Key key = webKey.getKey()
        return key
    }
}
