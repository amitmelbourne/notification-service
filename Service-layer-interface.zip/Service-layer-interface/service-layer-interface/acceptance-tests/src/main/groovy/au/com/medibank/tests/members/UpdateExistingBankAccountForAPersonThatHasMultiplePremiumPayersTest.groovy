package au.com.medibank.tests.members

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.client.non_api.NonApiClientFactory
import au.com.medibank.client.non_api.SelphiClient
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.After
import org.junit.Before
import org.junit.Test

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.core.IsEqual.equalTo

public class UpdateExistingBankAccountForAPersonThatHasMultiplePremiumPayersTest {

    public static final String USER_WITH_EXISTING_BANK_ACCOUNT_AND_OF_TYPE_PERSON_WITH_MULTIPLE_PREMIUM_PAYERS = TestMember.hasPoliciesWithMultiplePayer
    public static final LinkedHashMap<String, String> TEST_MEMBER = TestMember.hasCorrectPassword
    public static final LinkedHashMap<String, String> POLICY = TestPolicy.hasRegisteredAgr
    private MembersApiGateway membersApiGateway
    private PoliciesApiGateway policiesApiGateway
    private SelphiClient selphiClient
    private result
    private userId

    @Before
    public void setup() {
        Map gateways = ApiGatewayClientFactory.getGateways(TEST_MEMBER)
        membersApiGateway = gateways.members
        policiesApiGateway = gateways.policies
        selphiClient = NonApiClientFactory.getSelphiClient()
        selphiClient.resetUserSession(membersApiGateway.getCurrentSessionId())
        verifyPreconditions(membersApiGateway, policiesApiGateway)
        userId = USER_WITH_EXISTING_BANK_ACCOUNT_AND_OF_TYPE_PERSON_WITH_MULTIPLE_PREMIUM_PAYERS

        def resp = membersApiGateway.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
        def memberEtag = ResponseHelper.generateResponseHeaderMap(resp).ETag

        resp = policiesApiGateway.getPolicy(POLICY['policy'])
        result = this.membersApiGateway.postNewBankAccount(this.userId, "082-024",POLICY['policy'],memberEtag + "," + ResponseHelper.generateResponseHeaderMap(resp).get('ETag'))
    }

    private void verifyPreconditions(MembersApiGateway membersApiGateway, PoliciesApiGateway policiesApiGateway) {
        def accounts = policiesApiGateway.getPolicy(POLICY['policy']).getData()['members']['payment']['account']
        final boolean hasBankAccount = accounts.contains({e -> "Bank".equals(e["accountType"])})
        final boolean hasPayroll = accounts.contains({e -> "Payroll".equals(e["accountType"])})

        if (hasPayroll && hasBankAccount) {
            throw new IllegalStateException("expected accounts to have one Bank account and one Payroll account")
        }
    }

    @After
    public void teardown(){
        selphiClient.resetUserSession(membersApiGateway.getCurrentSessionId())
    }


    @Test
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    @Jira(story = "DSS-286/1.2")
    public void post_response_code_is_201_user_with_existing_bank_account(){
        assertThat(this.result.status, equalTo(201));
    }


    @Test
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"], GETS=["members/:memberId/accounts"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    @Jira(story = "DSS-286")
    public void GET_bank_account_should_no_more_than_3_accounts_after_update_user_with_existing_bank_account(){
        def accounts = policiesApiGateway.getPolicy(POLICY['policy']).getData();

        assertThat("Number of Bank accounts is exceeding more than one for selected member",accounts['members']['payment']['account'].size <= 3)
    }


    @Test
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    @Jira(story = "DSS-286")
    public void assertResponsePayloadAccountNum_user_with_existing_bank_account_user_with_existing_bank_account(){
        assertThat(this.result.responseData.get("accountNum"), equalTo("123456"));
    }


    @Test
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"])
    @DelPHI(wsdls = ["CustomerReadByBPID"])
    @Jira(story = "DSS-286")
    public void assertResponsePayloadAccountType_user_with_existing_bank_account(){
        assertThat(this.result.responseData.get("accountType"), equalTo("Bank"));
    }


    @Test
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    @Jira(story = "DSS-286")
    public void assertResponsePayloadAccountBsb_user_with_existing_bank_account(){
        assertThat(this.result.responseData.get("bsb"), equalTo("082-024"));
    }


    @Test
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    @Jira(story = "DSS-286")
    public void assertResponsePayloadAccountHolderName_user_with_existing_bank_account(){
        assertThat(this.result.responseData.get("accountHolderName"), equalTo("John Smith"));
    }


    @Test
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    @Jira(story = "DSS-286")
    public void assertResponsePayloadType_user_with_existing_bank_account(){
        assertThat(this.result.responseData.get("type"), equalTo("accounts"));
    }
}