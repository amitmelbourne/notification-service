package au.com.medibank.tests.policies

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.assertions.HttpAssert
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

class PoliciesVerifyEtag {

    static MembersApiGateway membersApiGateway;
    static PoliciesApiGateway policiesApiGateway;

    @BeforeClass
    public static void setup() {
        Map gateways = ApiGatewayClientFactory.getGateways(TestMember.hasCorrectPassword)
        policiesApiGateway = gateways.policies
        membersApiGateway = gateways.members
    }


    @Test
    @Jira(story = 'DSS-307')
    @ApiGateway(POST = "policies/policyNumber")
    @DelPHI(wsdl = 'NA')
    public void successful_get_policy_with_etag() throws Exception {

        def accountsData = policiesApiGateway.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(accountsData)

        assert responseMap.containsKey("ETag")
    }


    @Test
    @Jira(story = 'DSS-307')
    @ApiGateway(POST = "policies/testPolicyId/excess")
    @DelPHI(wsdl = 'NA')
    public void successful_put_policy_excess_with_etag() throws Exception {

        def resp = policiesApiGateway.getExcessChanges(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        resp = policiesApiGateway.putExcessChanges(TestPolicy.hasRegisteredAgr['policy'],'EX03', responseMap.get("ETag"))
        HttpAssert.assertStatusCode(resp, 200)
    }


    @Test
    @Jira(story = 'DSS-307')
     @Ignore("Manish Etag")
    @ApiGateway(POST = "policies/testPolicyId/excess")
    @DelPHI(wsdl = 'NA')
    public void unsuccessful_put_policy_excess_with_etag() throws Exception {
        def container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.corpOneExcessLevelNonSubsidised)

        def resp = container.getExcessChanges(TestPolicy.corp2OrMoreExcessLevelsSubsidised['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        resp = container.putExcessChanges(TestPolicy.corp2OrMoreExcessLevelsSubsidised['policy'],'EX03', "12345")
        HttpAssert.assertStatusCode(resp, 500)

    }

    @Test
    @Jira(story = 'DSS-307')
    @ApiGateway(POST = "policies/testPolicyId/registerAusgovRebate")
    @DelPHI(wsdl = 'NA')
    public void successful_post_policy_register_agr_with_etag() throws Exception {
        def container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasPolicywithNoAgr)

        def resp = container.getExcessChanges(TestPolicy.hasNonRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        resp = container.submitAgrDetails(TestPolicy.hasNonRegisteredAgr['policy'],responseMap.get("ETag"))
        HttpAssert.assertStatusCode(resp, 202)

    }


    @Test
    @Jira(story = 'DSS-307')
    @Ignore("Manish Etag")
    @ApiGateway(POST = "policies/testPolicyId/registerAusgovRebate")
    @DelPHI(wsdl = 'NA')
    public void unsuccessful_post_policy_register_agr_with_etag() throws Exception {
        def container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasPolicywithNoAgr)

        def resp = container.getExcessChanges(TestPolicy.hasNonRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        resp = container.submitAgrDetails(TestPolicy.hasNonRegisteredAgr['policy'],"12345")
        HttpAssert.assertStatusCode(resp, 500)

    }

    @Test
    @Jira(story = 'DSS-307')
    @Ignore("Manish Etag")
    @ApiGateway(POST = "policies/testPolicyId/ausgovRebate")
    @DelPHI(wsdl = 'NA')
    public void successful_put_policy_aus_gov_rebate_with_etag() throws Exception {
        String policyId = TestPolicy.hasRegisteredAgr['policy']
        String incomeType = "SINGLE"
        String incomeTier = "1"

        def container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasCorrectPassword)

        def resp = container.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        resp = container.putIncomeTier(policyId, incomeType, incomeTier,responseMap.get("ETag"))
        HttpAssert.assertStatusCode(resp, 200)

    }

    @Test
    @Jira(story = 'DSS-307')
    @Ignore("Manish Etag")
    @ApiGateway(POST = "policies/testPolicyId/ausgovRebate")
    @DelPHI(wsdl = 'NA')
    public void unsuccessful_put_policy_aus_gov_rebate_with_etag() throws Exception {
        String policyId = TestPolicy.hasRegisteredAgr['policy']
        String incomeType = "SINGLE"
        String incomeTier = "1"

        def container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasCorrectPassword)

        def resp = container.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        resp = container.putIncomeTier(policyId, incomeType, incomeTier,"12345")
        HttpAssert.assertStatusCode(resp, 500)

    }

}