package au.com.medibank.tests.members

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.assertions.HttpAssert
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

import java.text.SimpleDateFormat

class MembersVerifyEtag {

    static MembersApiGateway membersApiGateway;
    static PoliciesApiGateway policiesApiGateway;

    @BeforeClass
    public static void setup() {
        Map gateways = ApiGatewayClientFactory.getGateways(TestMember.hasCorrectPassword)
        policiesApiGateway = gateways.policies
        membersApiGateway = gateways.members
    }


    @Test
    @Jira(story = 'DSS-307')
    @ApiGateway(POST = "members/bpId")
    @DelPHI(wsdl = 'NA')
    public void memeber_details_with_etag() throws Exception {
        def resp = membersApiGateway.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        assert responseMap.containsKey("ETag")
    }

    @Test
    @Jira(story = 'DSS-307')
    @ApiGateway(POST = "members/bpId")
    @DelPHI(wsdl = 'NA')
    public void successful_update_contact_with_etag() throws Exception {
        def resp = membersApiGateway.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        Map fields = [mailingAddress: [addressLine1: "123", postCode: "3146", townName: "Melbourne", state: "VIC", countryCode: "AU"]]
        resp = membersApiGateway.updateContactDetails(TestMember.hasCorrectPassword['memberId'], responseMap.get("ETag"),fields)

        HttpAssert.assertStatusCode(resp, 200)
    }

    @Test
    @Jira(story = 'DSS-307')
    @Ignore("Manish Etag")
    @ApiGateway(POST = "members/bpId")
    @DelPHI(wsdl = 'NA')
    public void unsuccessful_update_contact_with_etag() throws Exception {
        def resp = membersApiGateway.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])

        Map fields = [mailingAddress: [addressLine1: "123", postCode: "3146", townName: "Melbourne", state: "VIC", countryCode: "AU"]]
        resp = membersApiGateway.updateContactDetails(TestMember.hasCorrectPassword['memberId'], "12345",fields)

        HttpAssert.assertStatusCode(resp, 500)

    }

    @Test
    @Jira(story = 'DSS-307')
    @ApiGateway(POST = "members/memberId/accounts")
    @DelPHI(wsdl = 'NA')
    public void successful_get_member_account_with_etag() throws Exception {

        def accountsData = membersApiGateway.listCreditCards(TestMember.hasCorrectPassword['memberId'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(accountsData)

        assert responseMap.containsKey("ETag")
    }

    @Test
    @Jira(story = 'DSS-307')
    @ApiGateway(POST = "members/memberId/accounts/directdebit")
    @DelPHI(wsdl = 'NA')
    public void successful_post_policy_direct_debit_with_etag() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']

        def container = ApiGatewayClientFactory.getGateways(TestMember.hasCorrectPassword)
        def resp = container.members.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
        def memberEtag = ResponseHelper.generateResponseHeaderMap(resp).get("ETag")

        resp = container.policies.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        def result = container.members.postDirectDebit(TestMember.hasCorrectPassword['memberId'],new SimpleDateFormat("yyyy-MM-dd").format(new Date()),"MONTHLY","1",policyNumber,memberEtag + "," + responseMap.get("ETag"))
        HttpAssert.assertStatusCode(result, 201)

    }

    @Test
    @Jira(story = 'DSS-307')
    @ApiGateway(POST = "members/memberId/accounts/directdebit")
    @DelPHI(wsdl = 'NA')
    public void unsuccessful_post_policy_direct_debit_with_etag() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']

        def container = ApiGatewayClientFactory.getGateways(TestMember.hasCorrectPassword)

        def resp = container.policies.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        def result = container.members.postDirectDebit(TestMember.hasCorrectPassword['memberId'],new SimpleDateFormat("yyyy-MM-dd").format(new Date()),"MONTHLY","1",policyNumber,responseMap.get("ETag"))

    }

    @Jira(story = 'DSS-307')
    @Test
    @ApiGateway(POST = "members/memberId/accounts/directdebit")
    @DelPHI(wsdl = 'NA')
    public void successful_post_policy_benefits_with_etag() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']

        def container = ApiGatewayClientFactory.getGateways(TestMember.hasCorrectPassword)
        def resp = container.members.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
        def memberEtag = ResponseHelper.generateResponseHeaderMap(resp).get("ETag")

        resp = container.policies.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        def result = container.members.postClaimBenefit(TestMember.hasCorrectPassword['memberId'], TestPolicy.hasRegisteredAgr['policy'], true,memberEtag + "," + responseMap.get("ETag"))
        assert result == 201

    }

    @Jira(story = 'DSS-307')
    @Test
    @ApiGateway(POST = "members/memberId/accounts/directdebit")
    @DelPHI(wsdl = 'NA')
    public void unsuccessful_post_policy_benefits_with_etag() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']

        def container = ApiGatewayClientFactory.getMembersApiGateway(TestMember.hasCorrectPassword)
        def result = container.postClaimBenefit(TestMember.hasCorrectPassword['memberId'], TestPolicy.hasRegisteredAgr['policy'], true,"12345")
        assert result.statusCode == 500
    }

}