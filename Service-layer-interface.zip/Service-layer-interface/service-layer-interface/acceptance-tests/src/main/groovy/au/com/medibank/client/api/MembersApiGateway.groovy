package au.com.medibank.client.api

import groovy.json.JsonBuilder
import groovyx.net.http.HttpResponseDecorator
import groovyx.net.http.HttpResponseException
import groovyx.net.http.RESTClient

import static au.com.medibank.assertions.DescriptiveErrors.failHttpResponseException
import static groovyx.net.http.ContentType.JSON

class MembersApiGateway extends BaseApiGateway {
    def MembersApiGateway() {}
    def MembersApiGateway(RESTClient restClient) {
        super(restClient)
    }
    def MembersApiGateway(RESTClient restClient, String sessionId) {
        super(restClient, sessionId)
    }

    def getDeployedVersion() {
        restClient.get(path: "members/version")
    }

    def HttpResponseDecorator getCorrespondence(String memberId, String typeCodeId, String fromDate, String untilDate, String limit) {

        def queryMap = [:]

        if (typeCodeId) queryMap['typeCode'] = typeCodeId
        if (fromDate) queryMap['from'] = fromDate
        if (untilDate) queryMap['until'] = untilDate
        if (limit) queryMap['limit'] = limit

        return restClient.get(path: "members/${memberId}/correspondence",
                headers: ['bpId': memberId],
                query: queryMap
        ) as HttpResponseDecorator

    }

    def getMemberContactDetails(String bpId) {
        try {
            def resp = restClient.get(path: "members/${bpId}",
                    query: ['include': 'contact'],
                    headers: ['APISessionToken': restClient.headers.APISessionToken])
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
    }

    def getAccounts(memberId) {
        try {
            def resp = restClient.get(path: "members/${memberId}/accounts")
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
    }

    def postNewBankAccount(memberId, String bsb,policyNumber, etag) {
        def bodyJSON = [
                "account"         : [
                        "accountType"      : "Bank",
                        "bsb"              : bsb,
                        "accountNum"       : "123456",
                        "accountHolderName": "John Smith",
                        "id"               : "123456",
                        "type"             : "accounts"
                ],
                "policyRef"       : [
                        "id"  : policyNumber,
                        "type": "policies"
                ],
                "paymentAmount"   : 255.5,
                "paymentFrequency": "fortnightly",
                "effectiveDate"   : "2015-08-23",
                "changeStateID"   : "12345"

        ]




        def response = null
        try {
            response = restClient.post(
                    path: "members/${memberId}/accounts/directdebit",
                    body: bodyJSON,
                    headers: ['If-Match':etag,APISessionToken: restClient.headers['APISessionToken']],
                    requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
        return response
    }


    def postNewBankAccount(memberId, String bsb) {
        def bodyJSON = [
                "account"         : [
                        "accountType"      : "Bank",
                        "bsb"              : bsb,
                        "accountNum"       : "123456",
                        "accountHolderName": "John Smith",
                        "id"               : "123456",
                        "type"             : "accounts"
                ],
                "policyRef"       : [
                        "id"  : "P9999",
                        "type": "policies"
                ],
                "paymentAmount"   : 255.5,
                "paymentFrequency": "fortnightly",
                "effectiveDate"   : "2015-08-23",
                "changeStateID"   : "12345"

        ]




        def response = null
        try {
            response = restClient.post(
                    path: "members/${memberId}/accounts/directdebit",
                    body: bodyJSON,
                    requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }



        return response
    }


    def postDirectDebit(String memberId, String effectiveDate, String paymentFrequency, String deductionDay, String policyNumber, etag) {
        try {
            Map bodyMap = [account     : [accountHolderName: "Test", accountNum: "1234567890123456", accountType: "Bank", bsb: "082-124", type: "accounts"],
                           deductionDay: deductionDay, effectiveDate: effectiveDate, paymentAmount: "255.5", paymentFrequency: paymentFrequency, changeStateID: "12345",
                           policyRef   : [id: policyNumber, type: "Policy"]]

            def resp = restClient.post(path: "members/${memberId}/accounts/directdebit",
                    body: bodyMap,
                    headers: ['If-Match':etag,APISessionToken: restClient.headers['APISessionToken']],
                    requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
    }


    def updateContactPhoneNumber(String memberId, homePhone, workPhone, mobilePhone) {
        def postBodyMap = [:]
        if (homePhone) {
            postBodyMap['homePhone'] = homePhone
        }
        if (workPhone) {
            postBodyMap['workPhone'] = workPhone
        }
        if (mobilePhone) {
            postBodyMap['mobilePhone'] = mobilePhone
        }


        def postBodyJson = new JsonBuilder(postBodyMap).toPrettyString()
        def response = null
        try {
            response = restClient.put(
                    path: "members/${memberId}/contact",
                    headers: [
                            bpId  : memberId,
                            userId: 'test@test.com'
                    ],
                    body: postBodyJson,
                    requestContentType: JSON
            )
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
        return response.status
    }

    def alterClaimBenefitsMainAccountDetails(updateableMemberId, updateablePolicyId, updatedFields, etag) {
        def postBodyMap = [
                "account"  : [
                        "accountType"      : "Bank",
                        "bsb"              : "111-111",
                        "accountNum"       : "123456",
                        "accountHolderName": "John Smith",
                        "id"               : "$updateableMemberId",
                        "type"             : "accounts"
                ],
                "policyRef": [
                        "id"  : "$updateablePolicyId",
                        "type": "policies"
                ]
        ]

        updatedFields.each { k, v ->
            postBodyMap['account'][k] = v
        }
        def postBodyJson = new JsonBuilder(postBodyMap).toPrettyString()
        def response = null
        try {
            response = restClient.post(
                    path: "members/$updateableMemberId/accounts/benefits",
                    headers: ['If-Match' : etag,
                              'APISessionToken': restClient.headers.APISessionToken],
                    body: postBodyJson,
                    requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
        return response.status
    }

    def postClaimBenefit(String memberId, String policyId, expectingException = false,etag) {
        def postBodyMap = [
                "account"  : [
                        "accountType"      : "Bank",
                        "bsb"              : "111-111",
                        "accountNum"       : "123456",
                        "accountHolderName": "John Smith",
                        "id"               : "$memberId",
                        "type"             : "accounts"
                ],
                "policyRef": [
                        "id"  : "$policyId",
                        "type": "policies"
                ]
        ]

        def postBodyJson = new JsonBuilder(postBodyMap).toPrettyString()

        def response
        try {
            response = restClient.post(path: "members/${memberId}/accounts/benefits", body: postBodyJson, requestContentType: JSON,
                    headers: ['If-Match':etag,APISessionToken: restClient.headers['APISessionToken']])
        } catch (HttpResponseException e) {
            if (expectingException == false) {
                failHttpResponseException(e)
            }
            return e
        }
        response.status
    }


    def putContactItem(updateableMemberId, item, fields, etag) {
        def bodyMap = [:]
        bodyMap[item] = fields
        def bodyJSON = new JsonBuilder(bodyMap).toPrettyString()
        def response = null
        try {
            response = restClient.put(
                    path: "members/$updateableMemberId/contact",
                    body: bodyJSON,
                    requestContentType: JSON,
                    headers: ['If-Match':etag,APISessionToken: restClient.headers['APISessionToken']])
        } catch (HttpResponseException e) {
            throw e
        }
        return response.status
    }

    def HttpResponseDecorator getMemberInfo(String memberId, boolean contactDetails) {
        def query = (contactDetails) ? [
                include: 'contact'
        ] : [:]
        def response = null

        try {
            response = restClient.get(
                    path: "members/${memberId}",
                    headers: [
                            bpId  : memberId,
                            userId: 'test@test.com'
                    ],
                    query: query
            ) as HttpResponseDecorator
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
        return response
    }

    def HttpResponseDecorator getContactDetails(String memberId) {
        return getMemberInfo(memberId, true)
    }

    def HttpResponseDecorator viewStoredCardList(String memberId) {
        try {
            def resp = restClient.get(path: "members/${memberId}/accounts")
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
    }

    def listCreditCards(memberId) {
        def resp
        try {
            resp = restClient.get(path: "members/${memberId}/accounts", requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }

        return resp
    }


    def assignCreditCard(memberId, policyId, cardHolderName, cardNumber, cardExpiry, etag){
        def jsonBody = [
                "account" : [
                        "accountType" : "CreditCard",
                        "cardRefID" : "fhskdjhgsdgh",
                        "cardType" : "VISA",
                        "cardHolderName" : cardHolderName,
                        "paymentCardID" : "123457",
                        "cardToken" : cardNumber,
                        "cardExpiry" : cardExpiry,
                        "id" : "123457",
                        "type" : "accounts"
                ],
                "policyRef" : [
                        "id" : policyId,
                        "type" : "policies"
                ],
                "paymentAmount" : 512.87,
                "paymentFrequency" : "monthly",
                "effectiveDate" : "2018-08-23",
                "deductionDay" : "14"
        ]

        try {
            restClient.post(path: "members/${memberId}/accounts/directdebit", body: jsonBody,
                    headers: ['If-Match':etag,APISessionToken: restClient.headers['APISessionToken']],
                    requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
    }

    def unsubscribe(String token) {
        try {
            restClient.put(path: "members/unsubscribe", body: [tokenID: token], requestContentType: JSON)
        } catch (HttpResponseException e) {
            assert e.getResponse().status == 500
        }
    }

    def updateContactDetails(updateableMemberId,  etag,fields) {
        def bodyJSON = new JsonBuilder(fields).toPrettyString()
        def response = null
        try {
            response = restClient.put(
                    path: "members/$updateableMemberId/contact",
                    body: bodyJSON,
                    requestContentType: JSON,
                    headers: ['If-Match':etag,APISessionToken: restClient.headers['APISessionToken']])
        } catch (HttpResponseException e) {
            return e
        }
        return response
    }
}