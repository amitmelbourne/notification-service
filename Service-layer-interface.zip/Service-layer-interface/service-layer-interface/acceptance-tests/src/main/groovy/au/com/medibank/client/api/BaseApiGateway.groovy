package au.com.medibank.client.api

import groovyx.net.http.HttpResponseException
import groovyx.net.http.RESTClient

import static au.com.medibank.assertions.DescriptiveErrors.failHttpResponseException


class BaseApiGateway {
    //TODO http://stackoverflow.com/questions/3691933/in-groovy-is-there-a-way-to-decorate-every-class-to-add-tracing
    protected RESTClient restClient
    protected final sessionId = null

    def BaseApiGateway() {}

    def BaseApiGateway(RESTClient restClient) {
        this.restClient = restClient
    }

    def BaseApiGateway(RESTClient restClient, String sessionId) {
        this.restClient = restClient
        this.sessionId = sessionId
    }

    def getBaseUri(){
        restClient.getUri()
    }

    def getCurrentSessionId() {
        return sessionId
    }

}