package au.com.medibank.client.non_api

import com.mashape.unirest.http.Unirest
import com.mashape.unirest.request.HttpRequestWithBody

class BaseApiClient {
    private String baseUrl
    public Map defaultHeaders;

    BaseApiClient(String baseUrl, Map defaultHeaders) {
        this.baseUrl = baseUrl
        this.defaultHeaders = defaultHeaders
    }

    String getBaseUrl() { return baseUrl }

    HttpRequestWithBody postWithDefaultHeaders(String restResource) {
        HttpRequestWithBody post = Unirest.post(this.getBaseUrl() + restResource)
        for (Map.Entry<String, String> entry : defaultHeaders.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();
            post = post.header(key, value);
        }
        return post
    }

}