package au.com.medibank.tests.members

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.data.TestMember
import org.hamcrest.Matcher
import org.junit.BeforeClass
import org.junit.Test

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.Matchers.nullValue
import static org.hamcrest.collection.IsEmptyCollection.empty
import static org.hamcrest.collection.IsMapContaining.hasKey
import static org.hamcrest.core.IsEqual.equalTo
import static org.hamcrest.core.IsNull.notNullValue
import static org.hamcrest.text.IsEmptyString.isEmptyOrNullString
import static org.junit.Assert.assertFalse


public class GetContactDetails {
    static  MembersApiGateway container;

    // TODO: check annotations in this class

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getMembersApiGateway(TestMember.hasUpdateableAddress)
    }

    private static <T> void assertDoesNotMatch(String message, Matcher<? super T> c, T arg) {
        assertFalse(message, c.matches(arg));
    }

    private static void assertHasFields(objName, obj, fields) {
        fields.each { field ->
            assertDoesNotMatch "${objName} has ${field}", isEmptyOrNullString(), obj[field]
        }
    }

    /**
     * Check the basic contact information for a member is returned.
     */

    @Test
    @Jira(stories = ['DSS-29/1.1', 'DSS-29/1.3', 'DSS-29/1.4', 'DSS-29/1.5', 'DSS-32/1.1'])
    @ApiGateway(GET= "members/:memberId/?include=contact")
    @DelPHI(wsdls = ['CustomerReadByBPID'])
    public void get_contact_details_basis_info() throws Exception {
        def response = container.getContactDetails(TestMember.hasStoredCard['memberId']).getData()

        assertThat response, notNullValue()

        assertHasFields "Response", response, ['id', 'individual']
        assertHasFields "Individual Response", response['individual']['name'], ['firstName','lastName','preferredName']
    }

    /**
     * Check address information is returned
     */

    @Test
    @Jira(stories = ['DSS-29/1.1', 'DSS-29/1.3', 'DSS-29/1.4', 'DSS-29/1.5', 'DSS-32/1.1'])
    @ApiGateway(GET= "members/:memberId/?include=contact")
    @DelPHI(wsdls = ['CustomerReadByBPID'])
    public void get_contact_address_info() throws Exception {
        def response = container.getContactDetails(TestMember.hasStoredCard['memberId']).getData()

        assertThat response, notNullValue()
        Map contact = response['contact'] as Map
        assertThat contact, notNullValue()
        assertThat contact['residentialAddress'], notNullValue()
        assertThat contact['mailingAddress'], notNullValue()

        assertHasFields "ResidentialAddress", contact.residentialAddress,
            ['id', 'serviceDeliveryType', 'addressLine1', 'addressLine2', 'addressLine3', 'postCode', 'townName', 'state']

        assertHasFields "MailingAddress", contact.mailingAddress,
            ['id', 'deliveryPointID', 'serviceDeliveryType', 'addressLine1', 'postCode', 'townName', 'state']

        assertThat contact['mailingAddressSameAsResidential'] as boolean, equalTo(false)
    }

    /**
     * Check "same as" flag set properly.
     */

    @Test
    @Jira(stories = ['DSS-29/1.1', 'DSS-29/1.3', 'DSS-29/1.4', 'DSS-29/1.5', 'DSS-32/1.1'])
    @ApiGateway(GET= "members/:memberId/?include=contact")
    @DelPHI(wsdls = ['CustomerReadByBPID'])
    public void get_contact_address_mailing_same_as_residential() throws Exception {
        def response = container.getContactDetails(TestMember.hasBasicInfo['memberId']).getData()

        assertThat response, notNullValue()
        Map contact = response['contact'] as Map
        assertThat contact, notNullValue()
        assertThat contact['residentialAddress'], notNullValue()
        assertThat contact['mailingAddress'], nullValue()

        assertHasFields "ResidentialAddress", contact.residentialAddress,
            ['id', 'serviceDeliveryType', 'addressLine1', 'postCode', 'townName', 'state']

        assertThat contact['mailingAddressSameAsResidential'] as boolean, equalTo(true)
    }

    /**
     * Check phone number information is returned
     */

    @Test
    @Jira(stories = ['DSS-29/1.1', 'DSS-29/1.3', 'DSS-29/1.4', 'DSS-29/1.5', 'DSS-32/1.1'])
    @ApiGateway(GET= "members/:memberId/?include=contact")
    @DelPHI(wsdls = ['CustomerReadByBPID'])
    public void get_contact_phone_number_info() throws Exception {
        def response = container.getContactDetails(TestMember.hasStoredCard['memberId']).getData()

        assertThat response, notNullValue()
        Map contact = response['contact'] as Map
        assertThat contact, notNullValue()
        def homePhone = contact['homePhone'] as Map
        def workPhone = contact['workPhone'] as Map
        def mobilePhone = contact['mobilePhone'] as Map

        assertHasFields "Home Phone", homePhone,
            ['countryCode', 'phoneNumber']

        assertHasFields "Work Phone", workPhone,
            ['countryCode', 'phoneNumber']

        assertHasFields "Mobile Phone", mobilePhone,
            ['countryCode', 'phoneNumber']
    }

    /**
     * Check preferences information is returned correctly
     */

    @Test
    @Jira(stories = ['DSS-29/1.1', 'DSS-29/1.3', 'DSS-29/1.4', 'DSS-29/1.5', 'DSS-32/1.1'])
    @ApiGateway(GET= "members/:memberId/?include=contact")
    @DelPHI(wsdls = ['CustomerReadByBPID'])
    public void get_contact_preferences_info() throws Exception {
        def response = container.getContactDetails(TestMember.hasStoredCard['memberId']).getData()

        assertThat response, notNullValue()
        Map contact = response['contact'] as Map
        assertThat contact, notNullValue()
        def preferences = contact['preferences'] as Map
        assertThat preferences, notNullValue()

        assertThat contact['sensitiveInformationProtection'] as boolean, equalTo(false)

        def publication = preferences['PUB'] as Map
        def service = preferences['SRV'] as Map
        def marketing = preferences['MRK'] as Map
        assertThat publication, notNullValue()
        assertThat service, notNullValue()
        assertThat marketing, notNullValue()

        [publication, marketing, service].each { Map category ->
            assertDoesNotMatch "Category has medium items", empty(), category.keySet()

            category.each { _, v ->
                assertThat v as Map, hasKey('preference')
                assertThat v as Map, hasKey('updateable')
            }
        }
    }

    /**
     * Check preferences information is returned correctly
     */

    @Test
    @Jira(stories = ['DSS-29/1.1', 'DSS-29/1.3', 'DSS-29/1.4', 'DSS-29/1.5', 'DSS-32/1.1'])
    @ApiGateway(GET= "members/:memberId/")
    @DelPHI(wsdls = ['CustomerReadByBPID'])
    public void get_member_basic_info_only() throws Exception {
        def response = container.getMemberInfo(TestMember.hasBasicInfo['memberId'], false).getData()

        assertThat response, notNullValue()

        assertHasFields "Response", response, ['id', 'individual']
        assertHasFields "Individual Response", response['individual']['name'], ['firstName','lastName','preferredName']

        Map contact = response['contact']
        assertThat contact, nullValue() // should be no contact object returned - just header info
    }

}
