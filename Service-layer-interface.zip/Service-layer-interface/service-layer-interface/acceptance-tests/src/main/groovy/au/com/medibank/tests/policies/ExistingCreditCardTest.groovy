package au.com.medibank.tests.policies

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.Before
import org.junit.Ignore
import org.junit.Test

class ExistingCreditCardTest {
    private MembersApiGateway membersApiGateway
    private PoliciesApiGateway policiesApiGateway

    @Before
    public void setup(){
        Map gateways = ApiGatewayClientFactory.getGateways(TestMember.hasCorrectPassword)
        membersApiGateway = gateways.members
        policiesApiGateway = gateways.policies
    }


    @Test
    @Ignore("Investigating failure on 12/09/2015 weekend")
    @Jira(story = 'DSS-296/1.2')
    @ApiGateway(POST = '/members/:id/accounts{directDebit}')
    @DelPHI(wsdls = ['PolicyReadByBPID',
            'ManageCustomerUpdateCustomer',
            'ManagePolicyPremiumPayer',
            'ManagePolicyUpdatePremium'])
    public void refresh_credit_card_list_for_existing_cards(){
        def accountsData = membersApiGateway.listCreditCards('C9999').responseData.accounts
        def creditCardAccount =  accountsData.find({e -> e.accountType.equals("CreditCard")})
        assert creditCardAccount.paymentCardID == "9999************999", "Could not find credit card"
    }

    @Test
    @Jira(stories = ['DSS-296/1.3', 'DSS-296/1.4'])
    @ApiGateway(GET = '/members/:id')
    @DelPHI(wsdl = 'CustomerReadByBPID')
    public void assign_credit_card_from_existing_cards(){
        def resp = policiesApiGateway.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)
        def response = membersApiGateway.assignCreditCard(
                TestMember.hasNoBankAccount.memberId,
                TestPolicy.hasNoBankAccount.policy,
                "John Smith","****-******-0789",
                "03/16",
                responseMap.get('ETag'))
        assert response.getStatus() == 201
    }


    @Test
    @Jira(stories = ['DSS-297/1.0', 'DSS-297/2.0'])
    @ApiGateway( POST = '/members/:id/accounts{directDebit}')
    @DelPHI(wsdls = [
            'PolicyReadByBPID',
            'ManageCustomerUpdateCustomer',
            'ManagePolicyPremiumPayer',
            'ManagePolicyUpdatePremium'
    ])
    public void update_credit_card_from_existing_cards(){

        def resp = policiesApiGateway.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)
        def response = membersApiGateway.assignCreditCard(TestMember.hasCorrectPassword['memberId'], TestPolicy.hasRegisteredAgr['policy'],"John Smith","****-******-0789","03/16",responseMap.get('ETag'))

        resp = policiesApiGateway.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        responseMap = ResponseHelper.generateResponseHeaderMap(resp)
        response = membersApiGateway.assignCreditCard(TestMember.hasCorrectPassword['memberId'], TestPolicy.hasRegisteredAgr['policy'],"John Smith","1234-5678-9012-3456","02/18",responseMap.get('ETag'))

        assert response.getStatus() == 201
    }

}
