package au.com.medibank.testCoverageReporting

import java.lang.reflect.Method

class Utils {

    static littleClass(String className) {
        className.tokenize('.')[-1]
    }

    static testNameWithJavaClass(Method test) {
        test.clazz.name + '.' + test.name
    }

    static testNameWithLittleClass(Method test) {
        littleClass(test.clazz.name) + '.' + test.name
    }

    static jiraStory(String fullJiraRef) {
        fullJiraRef.tokenize('/')[0]
    }

    static Integer jiraStoryNumber(String fullJiraRef) {
        def jsn = jiraStory(fullJiraRef).tokenize('-')[1]
        jsn ? jsn.toInteger() : 0
    }

    static jiraScenario(String fullJiraRef) {
        // absent scenario after '/' must be handled
        // TODO: correctly order 'DSS-90/1.11' and 'DSS-90/1.10a' after 'DSS-90/1.10' and 'DSS-90/1.9'
        fullJiraRef.tokenize('/')[1] ?: ""
    }

    static apiService(fullApiRef) {
        fullApiRef.tokenize('/')[0] ?: ""
    }

    static apiServiceDetail(fullApiRef) {
        fullApiRef.tokenize('/').tail().join('/') ?: ""
    }


}
