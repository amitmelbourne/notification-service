package au.com.medibank.helpers;

public class CalcHelper {
    public static double getPercentage(Integer total, Integer amount) {
        Float c = new Float(total) - new Float(amount);
        if (amount.equals(0))  {
            return 0;
        }
        return (c / total) * 100;
    }
}
