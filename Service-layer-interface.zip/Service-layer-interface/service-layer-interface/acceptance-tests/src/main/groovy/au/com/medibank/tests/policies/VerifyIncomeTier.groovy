package au.com.medibank.tests.policies

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.annotations.TestNotImplemented
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.BeforeClass
import org.junit.Test

import static org.junit.Assert.assertFalse
import static org.junit.Assert.assertTrue

class VerifyIncomeTier {

    static PoliciesApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasCorrectPassword)
    }

    private static void assertHasFields(obj, fields) {
        fields.each { field ->
            assertTrue(obj.containsKey(field))
        }
    }

    private static void assertNotHasFields(obj, fields) {
        fields.each { field ->
            assertFalse(obj.containsKey(field))
        }
    }

    @Jira(stories = ['DSS-48/1.1', 'DSS-48/1.2', 'DSS-48/1.3'])
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['BankReadBranchByBSB', 'CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void read_agr_tier_with_valid_user() {
        def responseData = container.getPolicy(TestPolicy.hasRegisteredAgr['policy']).getData()

        assertHasFields responseData['ausgovRebate'], ['effectiveAGR', 'registrationStatus', 'agrPercentage', 'registrationEffectiveFromDate', 'registrationEffectiveToDate', 'agrIncomeTier']
        assertHasFields responseData['ausgovRebate']['agrIncomeTier'], ['incomeType', 'incomeTier']

        assertTrue(responseData['ausgovRebate']['effectiveAGR'].equals("true"))
    }

    @Jira(stories = ['DSS-48/1.1', 'DSS-48/1.2', 'DSS-48/1.3'])
    @Test
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdls = ['BankReadBranchByBSB', 'CustomerReadByBPID', 'PolicyReadByPolicyID', 'PolicySearchPremiumPaymentHistory'])
    public void read_agr_tier_with_invalid_user() {

        PoliciesApiGateway container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasDirectDebit);

        def responseData = container.getPolicy(TestPolicy.hasNonRegisteredAgr['policy']).getData()
        assertNotHasFields responseData, ['ausgovRebate','agrIncomeTier','effectiveAGR']
    }

    @Jira(stories = ['DSS-248/1.2', 'DSS-48/1.3'])
    @Test
    @TestNotImplemented
    @ApiGateway(PUT = "policies/:policyNumber/ausgovRebate/agrIncomeTier")
    @DelPHI(wsdl = 'ManagePolicyUpdateIncomeTier')
    public void successful_update_income_tier_details() {
        String policyId = TestPolicy.hasRegisteredAgr['policy']
        String incomeType = "SINGLE"
        String incomeTier = "1"

        def resp = container.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        def responseData = container.putIncomeTier(policyId, incomeType, incomeTier,
                ResponseHelper.generateResponseHeaderMap(resp).ETag).getData()

        assertHasFields responseData.ausgovRebate,
                ['agrPercentage','agrIncomeTier']
        def agrIncomeTier = responseData.ausgovRebate.agrIncomeTier
        assertHasFields agrIncomeTier,
                ['incomeType', 'incomeTier']
        assertTrue agrIncomeTier.incomeType.equals(incomeType)
        assertTrue agrIncomeTier.incomeTier.equals(incomeTier)
    }
}