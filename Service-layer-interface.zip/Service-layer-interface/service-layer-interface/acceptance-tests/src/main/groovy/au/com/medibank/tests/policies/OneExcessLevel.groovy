package au.com.medibank.tests.policies

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.assertions.HttpCodeRange
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.Ignore
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCodeInRange

class OneExcessLevel {

    PoliciesApiGateway apiGatewayInstance
    def testPolicy
    def getPolicyRespBeforeExcessChange
    def putResp
    def getResp
    def changeStateId
    def final newExcessLevel = 'EX03'


    @Test
    @Ignore('awaiting Selphi updates')
    @Jira(story = 'DSS-90/1.1')
    @ApiGateway(PUT = 'policies/:id/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void non_corp_one_excess_level_only_cant_change() {
        apiGatewayInstance = ApiGatewayClientFactory.getPoliciesApiGateway(
                TestMember.nonCorpOneExcessLevel)
        testPolicy = TestPolicy.nonCorpOneExcessLevel
        getPolicyRespBeforeExcessChange = apiGatewayInstance.getPolicy(testPolicy.policy)
        getResp = apiGatewayInstance.getExcessChanges(testPolicy.policy)
        changeStateId = getResp.getData().changeStateID

        def resp = apiGatewayInstance.getExcessChanges(testPolicy.policy, newExcessLevel)
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        putResp = apiGatewayInstance.putExcessChanges(testPolicy.policy, newExcessLevel, responseMap.get("ETag"))

        assertStatusCodeInRange(putResp, HttpCodeRange._400)
    }


    @Test
    @Ignore('awaiting Selphi updates')
    @Jira(story = 'DSS-279/1.1')
    @ApiGateway(PUT = 'policies/:id/excess')
    @DelPHI(wsdl = 'ManagePolicyUpdateExcess')
    public void corp_one_excess_level_only_cant_change() {
        apiGatewayInstance = ApiGatewayClientFactory.getMembersApiGateway(
                TestMember.corpOneExcessLevelNonSubsidised)
        testPolicy = TestPolicy.corpOneExcessLevelNonSubsidised
        getPolicyRespBeforeExcessChange = apiGatewayInstance.getPolicy(testPolicy.policy)
        getResp = apiGatewayInstance.getExcessChanges(testPolicy.policy)
        changeStateId = getResp.getData().changeStateID
        def resp = apiGatewayInstance.getExcessChanges(testPolicy.policy, newExcessLevel)
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)

        putResp = apiGatewayInstance.putExcessChanges(testPolicy.policy, newExcessLevel, responseMap.get("ETag"))
        assertStatusCodeInRange(putResp, HttpCodeRange._400)
    }

}
