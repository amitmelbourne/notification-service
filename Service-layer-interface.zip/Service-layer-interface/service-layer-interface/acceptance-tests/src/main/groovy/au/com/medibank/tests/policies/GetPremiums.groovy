package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import au.com.medibank.helpers.DateHelper
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.core.IsEqual.equalTo
import static org.hamcrest.number.OrderingComparison.greaterThan

public class GetPremiums {
    static PoliciesApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasStoredCard)
    }


    @Test
    @Jira(stories = ["DSS-102", "DSS-103"])
    @ApiGateway(GET= "policies/:policyId/amountToPay")
    @DelPHI(wsdl = "PolicyCalculatePremiumByDPT") @Ignore
    public void test_returns_premiums() {
        def xUntilDate = DateHelper.getXMLGregorianCalendar(Calendar.DATE, 30)
        def untilDate = DateHelper.xmlGregorianCalendarToString(xUntilDate)
        def response = container.getAmountToPay(TestMember.hasStoredCard['memberId'], TestPolicy.hasReceiveBenefitsAccount['policy'], untilDate).getData()

        def until = response['current'][0]
        assertThat(until['datePaidTo'], equalTo(untilDate));
        assertThat(until['paymentAmount'], greaterThan(new BigDecimal(0)));
    }
}
