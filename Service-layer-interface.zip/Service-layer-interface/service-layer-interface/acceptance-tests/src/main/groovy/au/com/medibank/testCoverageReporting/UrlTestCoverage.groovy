package au.com.medibank.testCoverageReporting

class UrlTestCoverage {

    UrlTestCoverage(String url) {
        this.url = url;
        this.noOfTests = 0;
        this.noOfIgnoredTests = 0;
        this.noNotImplemented = 0;
        this.noOfTestsNotImplemented = 0;
        this.noGetRequest = 0;
        this.noPostRequest = 0;
        this.noPutRequest = 0;
    }

    private String url;
    private Integer noOfTests;
    private Integer noOfIgnoredTests;
    private Integer noOfTestsNotImplemented;
    private Integer noNotImplemented;
    private Integer noGetRequest;
    private Integer noPostRequest;
    private Integer noPutRequest;

    Integer getImplementedCount(){
        return noOfTests - noOfIgnoredTests - noNotImplemented
    }

    String getUrl() {
        return url
    }

    Integer getNoOfTests() {
        return noOfTests
    }

    void incrementTestCount() {
        noOfTests++;
    }

    void incrementIgnoredTestCount() {
        noOfIgnoredTests++;
    }

    void incrementNotImplementedCount() {
        noNotImplemented++;
    }

    void incrementTestNotImplementedCount() {
        noOfIgnoredTests++;
    }

    Integer getNoOfIgnoredTests() {
        return noOfIgnoredTests
    }

    void incrementGetRequestTestCount() {
        noGetRequest++;
    }

    void incrementPostRequestTestCount() {
        noPostRequest++;
    }

    void incrementPutRequestTestCount() {
        noPutRequest++;
    }

    Integer getGetRequestTestCount() {
        return noGetRequest;
    }

    Integer getPostRequestTestCount() {
        return noPostRequest;
    }

    Integer getPutRequestTestCount() {
        return noPutRequest;
    }
}