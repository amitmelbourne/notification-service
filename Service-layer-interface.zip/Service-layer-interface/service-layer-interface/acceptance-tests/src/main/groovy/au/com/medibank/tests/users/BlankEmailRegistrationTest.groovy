package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.MembersApiClient
import org.junit.Before
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class BlankEmailRegistrationTest {
    private MembersApiClient registrationRequest
    private response

    @Before
    public void setup() {
        registrationRequest = ApiClientFactory.getMembersApiClient()
        response= this.registrationRequest.register(UserTestData.REGISTRATION_REQUEST_WITH_BLANK_EMAIL)
    }


    @Jira(story = "DSS-23/1.1")
    @Test
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void request_for_registration_with_blank_email_should_return_a_422_code() {
//        assert response['statusCode'] == 422, "Registration with blank email address member not working as per expectations"
        assertStatusCode(response, 422)
    }


    @Jira(story = "DSS-23/1.1")
    @Test
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void request_for_registration_with_blank_email_should_return_an_error_message() {
        assert response['response']['responseData']['errorDescription'] == UserTestData.REGISTRATION_REQUEST_WITH_BLANK_EMAIL.getErrorDescription(),
                "Error description either not return OR might differ with expected for blank mail address"
    }

}
