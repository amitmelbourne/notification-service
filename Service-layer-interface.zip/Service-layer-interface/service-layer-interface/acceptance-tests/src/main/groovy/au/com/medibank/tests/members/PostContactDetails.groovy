package au.com.medibank.tests.members

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.data.TestMember
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

import static org.hamcrest.CoreMatchers.equalTo
import static org.hamcrest.CoreMatchers.nullValue
import static org.hamcrest.MatcherAssert.assertThat

public class PostContactDetails {

    static MembersApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getMembersApiGateway(TestMember.hasUpdateableAddress)
    }

    @Test
    @Ignore
    @Jira(stories = ['DSS-216/1.1', 'DSS-216/1.3'])
    @ApiGateway(POST = "members/:memberId/contact")
    @DelPHI(wsdls = ['ManageCustomerUpdateCustomer'])
    public void get_contact_details_basis_info() throws Exception {
        def home = [
                countryCode: 'AU',
                phoneNumber: '555 5555'
        ]
        def work = [
                countryCode: 'AU',
                phoneNumber: '666 6666'
        ]
        def mobile = [
                countryCode: 'AU',
                phoneNumber: '04545 54545'
        ]
        def response = container.updateContactPhoneNumber(TestMember.hasBasicInfo['memberId'], home, work, mobile)

        assertThat response as Integer, equalTo(200)

        // fetch and verify
        response = container.getContactDetails(TestMember.hasBasicInfo['memberId']).getData()
        assertThat response.contact.homePhone.phoneNumber, equalTo('555 5555')
        assertThat response.contact.workPhone.phoneNumber, equalTo('666 6666')
        assertThat response.contact.mobilePhone.phoneNumber, equalTo('04545 54545')

        // delete and update
        home = [
                countryCode: '',
                phoneNumber: '  '
        ]
        work = [
                phoneNumber: '22 22 22 22'
        ]
        response = container.updateContactPhoneNumber(TestMember.hasBasicInfo['memberId'], home, work, mobile)
        assertThat response as Integer, equalTo(200)

        // refetch
        response = container.getContactDetails(TestMember.hasBasicInfo['memberId']).getData()
        assertThat response.contact['homePhone'], nullValue()
        assertThat response.contact.workPhone.phoneNumber, equalTo('22 22 22 22')
        assertThat response.contact.mobilePhone.phoneNumber, equalTo('04545 54545')
    }

}
