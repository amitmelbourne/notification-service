package au.com.medibank.client.non_api

import com.mashape.unirest.http.HttpResponse
import com.mashape.unirest.http.Unirest
import groovy.json.JsonOutput
import org.apache.http.HttpHost

class OktaClient {

    private final String baseUrl
    private final String authorizationToken
    private final Map settings

    OktaClient() {}

    public OktaClient(String baseUrl, String authorizationToken, Map settings) {
        this.baseUrl = baseUrl
        this.authorizationToken = authorizationToken
        this.settings = settings
    }

    def changeUserIntoProvisionedState(String emailToProvision) {
        deactivate(emailToProvision)
        activate(emailToProvision)
    }

    public void unlockAccounts(List<String> bpIds = "C9999") {
        for (String bpId : bpIds) {
            unlockAccount(bpId)
        }
    }

    public void unlockAllAccounts() {
        unlockAccounts(["C9999", "C.TC6.A", "C.TC5.A", "P.TC20.A1", "C.TC16.A", "C.TC2.B"])
    }


    def unlockAccount(String bpId = "C9999") {
        try {
            enableProxy()
            Unirest.post("${this.baseUrl}users/${bpId}")
                    .header("authorization", "SSWS 00pdVw7BPfyifcTq_2Aa-_G16RQmbg3RmVwa1oToUP")
                    .header("accept", "application/json")
                    .header("content-type", "application/json")
                    .body("{\r\n\"credentials\": {\r\n\"password\" : { \"value\": \"Test123.\" }\r\n}\r\n}")
                    .asString();
        } finally {
            disableProxy();
        }
    }

    def createNewUser(String email, String bpId) {
        try {
            enableProxy()
            Map jsonMap = ["profile"    :
                                   ["firstName"  : "Brett",
                                    "lastName"   : "Henderson",
                                    "email"      : email,
                                    "login"      : email,
                                    "mobilePhone": "0400123456",
                                    "BP_ID"      : bpId],
                           "credentials": ["password": ["value": "C0rrect Horse Battery Staple"]]
            ]

            def url = "${this.baseUrl}users?activate=false"
            HttpResponse<String> response = Unirest.post(url)
                    .header("content-type", "application/json")
                    .header("authorization", "SSWS 00pdVw7BPfyifcTq_2Aa-_G16RQmbg3RmVwa1oToUP")
                    .body(JsonOutput.toJson(jsonMap))
                    .asString();
            if (response.status != 200)
                throw new IllegalStateException("Failed to create user in OKTA, got return code of ${response.status}\n"
                        + "URL: ${url}\nJSON: ${JsonOutput.toJson(jsonMap)}")
        } finally {
            disableProxy();
        }
    }

    def deactivate(String email) {
        try {
            enableProxy()
            HttpResponse<String> response = Unirest.post(this.baseUrl + email + "lifecycle/deactivate")
                    .header("origin", "")
                    .header("content-type", "application/json")
                    .header("authorization", this.authorizationToken)
                    .asString();
            return response
        }
        finally {
            disableProxy();
        }
    }

    def activate(String email) {
        try {
            enableProxy()
            HttpResponse<String> response = Unirest.post(this.baseUrl + "users/" + email + "/lifecycle/activate")
                    .header("origin", "")
                    .header("content-type", "application/json")
                    .header("authorization", this.authorizationToken)
                    .asString();
            return response
        }
        finally {
            disableProxy();
        }
    }

    private disableProxy() {
        Unirest.setProxy(null)
    }

    private void enableProxy() {
        if (settings.get("skipProxy").equals("true")) {
            return;
        }
        def host = new HttpHost(settings.get("proxyHost"), settings.get("proxyPort"), settings.get("proxyProtocol"))
        Unirest.setProxy(host);
    }


    def setEmailVerifiedFlag(String email, String bpId, flag) {
        try {
            enableProxy()
            Map jsonMap = ["profile"    :
                                   ["firstName": "Brett", "lastName": "Henderson",
                                    "email"    : email, "login": email, "mobilePhone": "0400123456", "BP_ID": bpId, "emailVerified": flag],
                           "credentials": ["password":
                                                   ["value": "C0rrect Horse Battery Staple"]
                           ]
            ]

            def url = "${this.baseUrl}users/$email"
            HttpResponse<String> response = Unirest.put(url)
                    .header("content-type", "application/json")
                    .header("authorization", "SSWS 00pdVw7BPfyifcTq_2Aa-_G16RQmbg3RmVwa1oToUP")
                    .body(JsonOutput.toJson(jsonMap))
                    .asString();
            if (response.status != 200)
                throw new IllegalStateException("Failed to create user in OKTA, got return code of ${response.status}\n"
                        + "URL: ${url}\nJSON: ${JsonOutput.toJson(jsonMap)}")
        } finally {
            disableProxy();
        }
    }

    def getMemberDetails(String email) {
        try {
            enableProxy()
            HttpResponse<String> response = Unirest.get(this.baseUrl + "users/" + email)
                    .header("content-type", "application/json")
                    .header("authorization", this.authorizationToken)
                    .asString();
            return response
        }
        finally {
            disableProxy();
        }
    }


}
