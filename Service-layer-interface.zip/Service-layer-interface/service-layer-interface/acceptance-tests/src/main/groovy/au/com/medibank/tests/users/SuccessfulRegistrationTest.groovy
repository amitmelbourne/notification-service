package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.MembersApiClient
import org.junit.Before

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class SuccessfulRegistrationTest {
    private MembersApiGateway apiGatewayInstance
    private MembersApiClient registrationRequest



    @Before
    public void setup() {
        apiGatewayInstance = ApiGatewayClientFactory.getUnauthorisedMembersGateway()
        registrationRequest = ApiClientFactory.getMembersApiClient()
    }



    @Jira(stories = ["DSS-23", "DSS-107/1.0"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void successful_request_for_registration() {
        def response = registrationRequest.register(UserTestData.SUCCESSFUL_REGISTRATION_REQUEST)
        assertStatusCode(response, 201)
    }

}