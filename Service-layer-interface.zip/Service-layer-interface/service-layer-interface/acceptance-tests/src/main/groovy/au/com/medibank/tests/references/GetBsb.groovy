package au.com.medibank.tests.references

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.ReferencesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.helpers.AssertHelper
import org.junit.BeforeClass
import org.junit.Test

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.core.IsEqual.equalTo

class GetBsb {
    static ReferencesApiGateway apiGateway;

    @BeforeClass
    public static void setup() {
        apiGateway = ApiGatewayClientFactory.getReferencesApiGateway(TestMember.hasUpdateableAddress)
    }

    @Test @Jira(story = "DSS-99")
    @ApiGateway(GET= "references/bank")
    @DelPHI(wsdl = "BankReadBranchByBSB")
    public void get_policy_information_for_authenticated_user() {
        def result = apiGateway
                        .getBsb('032-272')
                        .getData()

        assertThat(result["type"], equalTo("bank"));
        AssertHelper.assertHasFields result,['type','bsbNum','name','branchName','address']
    }

    @Test @Jira(story = "DSS-99")
    @ApiGateway(GET= "references/bank")
    @DelPHI(wsdl = "BankReadBranchByBSB")
    public void get_bsb_information_for_unauthenticated_user() {
        def result = ApiGatewayClientFactory.getUnauthorisedReferencesGateway().getBsb('032-272', true).getData()
        assertThat(result["type"], equalTo("bank"));
    }
}
