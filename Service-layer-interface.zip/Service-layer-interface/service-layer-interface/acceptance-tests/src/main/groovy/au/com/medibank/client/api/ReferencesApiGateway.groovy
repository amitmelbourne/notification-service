package au.com.medibank.client.api

import groovyx.net.http.HttpResponseException
import groovyx.net.http.RESTClient

import static au.com.medibank.assertions.DescriptiveErrors.failHttpResponseException

class ReferencesApiGateway extends BaseApiGateway{
    def ReferencesApiGateway() {}
    def ReferencesApiGateway(RESTClient restClient) {
        super(restClient)
    }
    def ReferencesApiGateway(RESTClient restClient, String sessionId) {
        super(restClient, sessionId)
    }

    def getDeployedVersion() {
        restClient.get(path: "bank/version")
    }

    def getBsb(number, expectingException = false) {
        try {
            def resp = restClient.get(path: "reference/bank",
                    query: ['bsb': number])
        } catch (HttpResponseException e) {
            if (expectingException == false) {
                failHttpResponseException(e)
            }
            throw e
        }
    }



}