package au.com.medibank.tests.payments

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.api.PaymentsApiGateway
import au.com.medibank.data.TestMember
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

import java.util.regex.Pattern

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.core.IsNull.notNullValue
import static org.junit.Assert.assertTrue

class MakePayment {

    static PaymentsApiGateway paymentsApiGateway;
    static MembersApiGateway membersApiGateway;

    @BeforeClass
    public static void setup() {
        Map gateways = ApiGatewayClientFactory.getGateways(TestMember.hasUpdateableAddress)
        paymentsApiGateway = gateways.payments
        membersApiGateway = gateways.members
    }

    private static void assertHasFields(obj, fields) {
        fields.each { field ->
            assertTrue(obj.containsKey(field))
        }
    }

    @Jira(story = 'DSS-258')
    @Test
    @Ignore("Ignore due to DSS-333")
    @ApiGateway(POST = "payments/token")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void adhoc_payment_with_new_card() throws Exception {
        def result = paymentsApiGateway.postAdhocPaymentWithNewCard()

        assertThat result.getData()['token'], notNullValue()
    }

    @Jira(story = 'DSS-106')
    @Test
    @ApiGateway(GET = "members/:memberId/accounts")
    @DelPHI(wsdl = 'CustomerReadByBPID')
    public void view_stored_cards() throws Exception {
        def result = membersApiGateway.viewStoredCardList(TestMember.hasStoredCard['memberId'])

        result.getData()['accounts'].each { eachCardDetails ->

            println('Manish' + eachCardDetails)

            if (eachCardDetails['type'] == "BankAccount") {
                assertHasFields eachCardDetails, ['id', 'type', 'bsb', 'accountNum', 'accountHolderName']
            } else if (eachCardDetails['type'] == "CreditCardAccount") {
                assertHasFields eachCardDetails, ['id', 'type', 'cardType', 'cardHolderName', 'paymentCardID', 'cardToken', 'cardExpiry']

                Pattern numberPatern = Pattern.compile("^[\\d{4}*\\d{3}]*")
                java.util.regex.Matcher numberMatcher = numberPatern.matcher(eachCardDetails['paymentCardID'])
                assertTrue(numberMatcher.matches())

            }
        }
    }

    @Jira(story = 'DSS-257')
    @Test
    @ApiGateway(POST = "payments/token")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void adhoc_payment_with_stored_card() throws Exception {
        String policyId = 'P12345'
        String policyType = 'policies'
        String policyLink = '/v1/policies/P12345'
        String cardToken = 'FffNouzteeNAJp3WrrcqEJHqKpBKJFurhYpia7UockzfJgocJz'
        String cardholderName = 'Testy Tester'
        String orderNumber = 'ON123456'
        String amount = '450.50'

        def result = paymentsApiGateway.postAdhocPaymentWithStoredCard(policyId, policyType, policyLink, cardToken, cardholderName, orderNumber, amount)

        assertThat result.getData()['cardToken'], notNullValue()
        assertThat "${cardToken} is not matching with expected value", result.getData()['cardToken'].equals(cardToken)
        assertThat "${policyId} is not matching with expected value", result.getData()['policyRef']['id'].equals(policyId)
        assertThat "${policyType} is not matching with expected value", result.getData()['policyRef']['type'].equals(policyType)
        assertThat "${cardholderName} is not matching with expected value", result.getData()['cardHolderName'].equals(cardholderName)
        assertThat "${orderNumber} is not matching with expected value", result.getData()['orderNum'].equals(orderNumber)
    }

    @Jira(story = 'DSS-257')
    @Test
    @ApiGateway(POST = "payments/token")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void verify_approved_payment_with_stored_card() throws Exception {
        String policyId = 'P12345'
        String policyType = 'policies'
        String policyLink = '/v1/policies/P12345'
        String cardToken = 'FffNouzteeNAJp3WrrcqEJHqKpBKJFurhYpia7UockzfJgocJz'
        String cardholderName = 'esty Tester'
        String orderNumber = 'ON123456'
        String amount = '450.50'

        def result = paymentsApiGateway.postAdhocPaymentWithStoredCard(policyId, policyType, policyLink, cardToken, cardholderName, orderNumber, amount)

        assertThat "Transaction was not Approved...", result.getData()['desc'].equals("Approved")

        /*TODO - Fixture has the default value set and hence the assersion is failing*/
        //assertThat "Transaction was not Approved...", result.getData()['amount'].equals(amount)

    }

}