package au.com.medibank.client.non_api

import groovyx.net.http.RESTClient

class SelphiClient {
    def RESTClient restClient

    def private SelphiClient() {}

    def SelphiClient(RESTClient restClient) {
        this.restClient = restClient
    }

    def resetUserSession(sessionId){
        restClient.get(
                path: "selPHI/esb/clean/${sessionId}"
        )
    }

}