package au.com.medibank.tests.users

import au.com.medibank.Config
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.RestClientFactory
import au.com.medibank.client.non_api.NonApiClientFactory
import au.com.medibank.client.non_api.OktaClient
import groovyx.net.http.RESTClient
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class OmsActivationAfterRegistrationTest {


    @Test
    @Jira(story = "DSS-282/1.1")
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void login_attempt_with_emailverified_flag_false() {

        OktaClient oktaClient = NonApiClientFactory.getOktaClient()
        oktaClient.setEmailVerifiedFlag("C.TC13.A@medibank.com.au","M47620",false)
        RESTClient restClient = RestClientFactory.getBaseRestClient(new Config().getBaseApiUrl())
        def response = ApiGatewayClientFactory.getOktaSessionToken(restClient,"C.TC13.A@medibank.com.au","Test123.")

        assertStatusCode(response, 401, "User with email verified flag set to false not working");

        /**
         * NOTE - Manual Verification - After attempting to login with emailVerified= false, an email should be sent to the member
         */


    }

}