package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import groovyx.net.http.HttpResponseException
import org.junit.Before
import org.junit.Ignore
import org.junit.Test

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.core.IsEqual.equalTo

class GetPolicy {

    private PoliciesApiGateway container;

    // TODO: check annotations in this class

    @Before
    public void setup() {
        container = ApiGatewayClientFactory.getGateways(TestMember.hasUpdateableAddress).policies
    }

    @Test
    @Jira(stories = ["DSS-99", "DSS-165", "DSS-98"])
     @ApiGateway(GET= "policies/:policyNumber") @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void get_policy_with_credit_card_information_for_authenticated_user() {

        def result = container.getPolicy(TestPolicy.canRequestCard['policy']).getData() //Credit Card
        assertThat result.type, equalTo("policies")
    }


    @Test
    @Jira(stories = ["DSS-99", "DSS-165", "DSS-98"])
     @ApiGateway(GET= "policies/:policyNumber") @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void get_policy_with_manual_bill_with_credit_card_information_for_authenticated_user() {
        def result = container.getPolicy(TestPolicy.canRequestCard['policy']).getData() //Credit Card
        assertThat result.type, equalTo("policies")
    }


    @Test
    @Jira(stories = ["DSS-99", "DSS-165", "DSS-98"])
    @Ignore("Assertion error in PoliciesApiGateway")
    @ApiGateway(GET= "policies/:policyNumber") @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void get_policy_with_direct_debit_setup_information_for_authenticated_user() {
        container = ApiGatewayClientFactory.getGateways(TestMember.hasDirectDebit).policies
        def result = container.getPolicy(TestPolicy.hasDirectDebit).getData()
        assertThat result.type, equalTo("policies")
    }


    @Test
    @Jira(stories = ["DSS-99", "DSS-165", "DSS-98"])
    @ApiGateway(GET= "policies/:policyNumber") @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void get_policy_with_multiple_accounts_for_authenticated_user() {
        def result = container.getPolicy(TestPolicy.hasMultiplePayerWithIndividualAndCorpInAmount.policy).getData() //Credit Card
        assertThat result.type, equalTo("policies")
    }

    @Test(expected = HttpResponseException)
    @Jira(stories = ["DSS-99", "DSS-165", "DSS-98"])
    @ApiGateway(GET= "policies/:policyNumber") @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void get_policy_information_for_policy_that_does_not_exist() {
            def result = container.getPolicy(TestPolicy.doesNotExist, true)
    }

    @Test(expected = HttpResponseException)
    @Jira(stories = ["DSS-99", "DSS-165", "DSS-98"])
    @ApiGateway(GET = "policies/:policyNumber")
    @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void get_policy_information_for_unauthenticated_user() {
        PoliciesApiGateway instance = ApiGatewayClientFactory.getUnauthorisedPoliciesGateway()
        instance.getPolicy(TestPolicy.basicPolicy, true)
        throw new Exception("Exception while accessing Unauthenticated user")
    }

    @Test(expected = HttpResponseException)
    @Jira(stories = ["DSS-99", "DSS-165", "DSS-98"])
    @ApiGateway(GET= "policies/:policyNumber") @DelPHI(wsdl = "PolicyReadByPolicyID")
    public void get_policy_information_for_unauthorized_user() {
        ApiGatewayClientFactory.getUnauthorisedPoliciesGateway().getPolicy(TestPolicy.basicPolicy, true)
    }
}
