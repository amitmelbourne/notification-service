package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.NonApiClientFactory
import au.com.medibank.client.non_api.OktaClient
import groovy.json.JsonSlurper
import org.junit.Before
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class FrontlineActivationForProvisionedUserTest {
    private tokenMicroServiceClient = NonApiClientFactory.getTokenMicroService()
    private usersApiClient = ApiClientFactory.getUsersApiClient()
    private OktaClient oktaClient = NonApiClientFactory.getOktaClient()
    private response

    @Before
    public void setup() {
        String email = "user.who.should.always.be.in.a.provisioned.state@example.com"
        oktaClient.changeUserIntoProvisionedState(email)
        String token = tokenMicroServiceClient.createToken(email);
        assert token != null
        response = usersApiClient.activate(token, email)
    }

    @Test
    @Jira(story = "DSS-139")
    @ApiGateway(GET= "users/:email/activate") @DelPHI(wsdls = ["updatecustomer", "interaction"])
    public void service_should_return_a_202_code_on_success() {
        assertStatusCode(this.response, 202)
    }

    @Test
    @Jira(story = "DSS-139")
    @ApiGateway(GET= "users/:email/activate") @DelPHI(wsdls = ["updatecustomer", "interaction"])
    public void service_should_return_the_next_step_as_SetPassword() {
        String nextAction = new JsonSlurper().parseText(this.response.getBody())['_links']['next']['title']
        assert nextAction == 'SetPassword';
    }
}
