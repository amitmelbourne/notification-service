package au.com.medibank.testCoverageReporting

class AnnotationInstance {

    String testMethod
    String paramName
    String paramValue
    boolean ignored
    String ignoredReason
    boolean notImplemented
    String notImplementedReason

    AnnotationInstance() {}

}
