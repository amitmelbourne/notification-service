package au.com.medibank.tests.members

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import au.com.medibank.helpers.AssertHelper
import org.junit.BeforeClass
import org.junit.Test

import java.text.SimpleDateFormat

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.core.IsEqual.equalTo

class PostNewDirectDebit {
    static PoliciesApiGateway policiesApiGateway;
    static MembersApiGateway membersApiGateway;

    @BeforeClass
    public static void setup() {
        Map gateways = ApiGatewayClientFactory.getGateways(TestMember.hasDirectDebit)
        policiesApiGateway = gateways.policies
        membersApiGateway = gateways.members
    }

    @Test
    @ApiGateway(POST = "member/:memberId/accounts/:directDebit")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'ManagerPolicyPremiumPayer', 'ManageCustomerPaymentAccount'])
    @Jira(story = "DSS-98")
    public void post_new_direct_debit_for_authenticated_user() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']
        def resp = policiesApiGateway.getPolicy(TestPolicy.hasRegisteredAgr['policy'])

        def result = membersApiGateway.postDirectDebit(TestMember.hasCorrectPassword['memberId'],new SimpleDateFormat("yyyy-MM-dd").format(new Date()),"MONTHLY","1",policyNumber, ResponseHelper.generateResponseHeaderMap(resp).get("ETag"))
        assertThat(result.getData().get("accountType"), equalTo("Bank"));
    }

    @Test
    @ApiGateway(POST = "member/:memberId/accounts/:directDebit")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'ManagerPolicyPremiumPayer', 'ManageCustomerPaymentAccount'])
    @Jira(stories = ["DSS-160/1.7","DSS-160/1.8"])
    public void post_new_direct_debit_with_payment_frequency() {
        def deductionDay = "1"
        def effectiveDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date())
        def paymentFrequency = "MONTHLY"
        def policyNumber = TestPolicy.hasNonRegisteredAgr['policy']
        def resp = policiesApiGateway.getPolicy(TestPolicy.hasNonRegisteredAgr['policy'])

        def result = membersApiGateway.postDirectDebit(TestMember.hasDirectDebit['memberId'],effectiveDate,paymentFrequency,deductionDay,policyNumber,ResponseHelper.generateResponseHeaderMap(resp).get("ETag"))
        AssertHelper.assertHasFields(result.getData(),['accountHolderName','accountNum','accountType','bsb','id','type'])
    }

    @Test
    @ApiGateway(POST = "member/:memberId/accounts/:directDebit")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'ManagerPolicyPremiumPayer', 'ManageCustomerPaymentAccount'])
    @Jira(stories = ["DSS-160/1.7","DSS-160/1.8"])
    public void post_update_direct_debit_with_payment_frequency() {
        def deductionDay = "1"
        def effectiveDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date())
        def paymentFrequency = "MONTHLY"
        def policyNumber = TestPolicy.canRequestCard['policy']

        def gateways = ApiGatewayClientFactory.getGateways(TestMember.hasMultiplePolicies)
        def resp = gateways.policies.getPolicy(TestPolicy.canRequestCard['policy'])

        def result = gateways.members.postDirectDebit(TestMember.hasMultiplePolicies['memberId'],effectiveDate,paymentFrequency,deductionDay,policyNumber,ResponseHelper.generateResponseHeaderMap(resp).get("ETag"))
        AssertHelper.assertHasFields(result.getData(),['accountHolderName','accountNum','accountType','bsb','id','type'])
    }

    @Test
    @ApiGateway(POST = "member/:memberId/accounts/:directDebit")
    @DelPHI(wsdls = ['CustomerReadByBPID', 'ManagerPolicyPremiumPayer', 'ManageCustomerPaymentAccount'])
    @Jira(stories = ["DSS-160/1.7","DSS-160/1.8"])
    public void post_update_direct_debit_with_fortnightly_payment_frequency() {
        def deductionDay = "1"
        def effectiveDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date())
        def paymentFrequency = "FORTNIGHTLY"
        def policyNumber = TestPolicy.hasNonRegisteredAgr['policy']

        def gateways = ApiGatewayClientFactory.getGateways(TestMember.hasMultiplePolicies)
        def resp = gateways.policies.getPolicy(TestPolicy.hasNonRegisteredAgr['policy'])
        def result = gateways.members.postDirectDebit(TestMember.hasMultiplePolicies['memberId'],effectiveDate,paymentFrequency,deductionDay,policyNumber,ResponseHelper.generateResponseHeaderMap(resp).get("ETag"))

        AssertHelper.assertHasFields(result.getData(),['accountHolderName','accountNum','accountType','bsb','id','type'])
    }

}
