package au.com.medibank.tests.policies

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.annotations.TestNotImplemented
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.BeforeClass
import org.junit.Test

class ClaimsBenefitAccount {

    static Map container

    @BeforeClass
    public static void setupClass() {
        container = ApiGatewayClientFactory.getGateways(TestMember.hasUpdateableAddress)
    }


    @Test
    @Jira(stories = ['DSS-99/3.1', 'DSS-99/3.2', 'DSS-99/3.3', 'DSS-99/3.4'])
    @ApiGateway(POSTS = ['policies/:policyNumber', "member/:memberId/accounts/benefits/:benefitsClaimId"])
    @DelPHI(wsdls = ['PolicyReadByPolicyID', 'ManagePolicyBeneficiary', 'PolicyReadByPolicyID'])
    public void update_claims_benefit_account() {
        def policyScenarios = [TestPolicy.hasRegisteredAgr].collect { policy ->
            [policy.policy, policy.member.memberId, policy.member]
        }
        def updates = [
                'bsb'              : ['063-767', '082-024'],
                'accountNum'       : ['9999999999999', '1111111111111'],
                'accountHolderName': ["Sam Customer", 'Joanna Doe']
        ]
        policyScenarios.each { String updateablePolicyId, String updateableMemberId, Map a ->
            container = ApiGatewayClientFactory.getGateways(a)
            updates.each { fieldToUpdate, choice ->
                testCreateOrUpdateForClaimBenefitAccount(updateablePolicyId,
                        updateableMemberId, fieldToUpdate, choice[0], choice[1])
            }
        }
    }

    private testCreateOrUpdateForClaimBenefitAccount(policyId, memberId, fieldToUpdate, firstValue, finalValue) {
        def fieldUpdates = [:]
        fieldUpdates[fieldToUpdate] = firstValue

        def resp = container.members.getMemberContactDetails(memberId)
        def memberEtag = ResponseHelper.generateResponseHeaderMap(resp).get("ETag")

        resp = container.policies.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        Map responseMap = ResponseHelper.generateResponseHeaderMap(resp)
        def policyEtag = responseMap.get('ETag')
        def postResponse = container.members
                .alterClaimBenefitsMainAccountDetails(memberId, policyId, fieldUpdates, memberEtag + "," + policyEtag)
        assert postResponse == 201, "Could not post initial value for '$fieldToUpdate' field"
        def receiveBenefitsMember = memberWithReceiveBenefitAccount(policyId, memberId)
        def postedValue = receiveBenefitsMember.beneficiary.account[fieldToUpdate]
        assert firstValue == postedValue,
                "Setting first value for field '$fieldToUpdate' was not successful (expected='$firstValue', actual='$postedValue'"

        resp = container.members.getMemberContactDetails(memberId)
        memberEtag = ResponseHelper.generateResponseHeaderMap(resp).ETag
        resp = container.policies.getPolicy(TestPolicy.hasRegisteredAgr['policy'])
        responseMap = ResponseHelper.generateResponseHeaderMap(resp)
        policyEtag = responseMap.get('ETag')
        fieldUpdates[fieldToUpdate] = finalValue
        postResponse = container.members
                .alterClaimBenefitsMainAccountDetails memberId, policyId, fieldUpdates, memberEtag + "," + policyEtag
        assert postResponse == 201, "Could not post final value for '$fieldToUpdate' field-- response '$postResponse'"
        receiveBenefitsMember = memberWithReceiveBenefitAccount(policyId, memberId)
        postedValue = receiveBenefitsMember['beneficiary']['account'][fieldToUpdate]
        assert finalValue == postedValue, "Value for field '$fieldToUpdate' was not updated successfully (orig='$finalValue', updated='$postedValue'"
    }

    private memberWithReceiveBenefitAccount(policyId, memberId) {
        // NOTE: this function because can not rely on order of members in the API response
        def responseData = container.policies.getPolicy(policyId).getData()
        responseData['members'].find { member -> member['id'] == memberId }
    }


    @Test
    @Jira(story = 'DSS-99/4')
    @TestNotImplemented(reason = "UI-specific, no API test required")
    @ApiGateway(GET = "references/bank")
    @DelPHI(wsdl = "BankReadBranchByBSB")
    public void success_or_error_on_save_account() {
    }


    @Test
    @Jira(stories = ['DSS-165/1.1', 'DSS-160'])
    @ApiGateway(GET = 'policies/:policyNumber')
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void view_last_payment_info() {
        def testPolicy = TestPolicy.hasPaymentHistory
        def responseData = container.policies.getPolicyWithPayments(testPolicy.policy).getData()
        // assume payment history is presented in reverse order of payment
        def lastPayment = responseData['paymentSchedule']['payments'][0]
        def requiredFields = ['type', 'coverageEndDate', 'transactionDate',
                              'paymentAmount', 'paymentMethod', 'status']
        requiredFields.each { k -> assert k in lastPayment }
    }


    @Test
    @Jira(story = 'DSS-99/1')
    @TestNotImplemented(reason = 'UI only')
    @ApiGateway(POST = 'policies/:policyNumber')
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void option_to_add_or_update_bank_account_for_incoming_claims() {
    }
}
