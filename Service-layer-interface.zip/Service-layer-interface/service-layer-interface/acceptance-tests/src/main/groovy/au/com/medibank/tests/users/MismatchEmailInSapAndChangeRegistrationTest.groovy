package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.UsersApiGateway
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.MembersApiClient
import au.com.medibank.data.TestMember
import org.junit.Before
import org.junit.Ignore

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class MismatchEmailInSapAndChangeRegistrationTest {

    def static userWithEmailMatchesInSap = TestMember.member11;
    private MembersApiClient registrationRequest
    private response


    @Before
    public void setup() {
        registrationRequest = ApiClientFactory.getMembersApiClient()
        response = registrationRequest.register(UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_CHANGE)
    }



    @Jira(stories = ["DSS-23/2.0", "DSS-23/2.5"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void successful_request_for_registration_with_mismatch_email_in_sap_and_change_409_error() {
        assert this.response['statusCode'] == 409, "Registration with email mismatch not working as per expectations"
        assertStatusCode(response, 409)
    }

//
//    @Jira(stories = ["DSS-23/2.0", "DSS-23/2.5"])
//    @ApiGateway(POST = "users")
//    @DelPHI(wsdl = "N/A")
//    public void successful_request_for_registration_with_mismatch_email_in_sap_and_change_201() {
//        assertStatusCode(response, 201)
//    }


    @Jira(stories = ["DSS-23/2.0", "DSS-23/2.5"])
    @ApiGateway(POST = "users") @Ignore //fix me TODO JDF
    @DelPHI(wsdl = "N/A")
    public void successful_request_for_registration_with_mismatch_email_in_sap_and_change_202() {
        registrationRequest.rawOktaAuthenticationResponse(MismatchEmailInSapAndChangeRegistrationTest.userWithEmailMatchesInSap['username'],
                UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_CHANGE.getPassword())
        int passwordChangeReturnCode = new UsersApiGateway(registrationRequest.getRestClientInstance()).postNewPassword(MismatchEmailInSapAndChangeRegistrationTest.userWithEmailMatchesInSap['username'],
                UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_CHANGE.getPassword(), TestMember.defaultTestPassword)
        assert passwordChangeReturnCode == 202, "Unable to change default password for a new password"
    }

}