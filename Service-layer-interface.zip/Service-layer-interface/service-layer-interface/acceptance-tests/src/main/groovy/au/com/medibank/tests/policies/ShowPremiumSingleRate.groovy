package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import org.junit.BeforeClass
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

public class ShowPremiumSingleRate {
    static PoliciesApiGateway policiesApiGateway;
    static final USERWITH_FOUR_PAYMENT_FREQUENCIES_AND_NO_DUAL_RATE = TestMember.hasCorrectPassword
    static final NO_DUAL_RATE_POLICY = "P9999"
    private static response

    @BeforeClass
    public static void setup() {
        policiesApiGateway = ApiGatewayClientFactory.getPoliciesApiGateway(USERWITH_FOUR_PAYMENT_FREQUENCIES_AND_NO_DUAL_RATE)
        response = policiesApiGateway.getPremium(NO_DUAL_RATE_POLICY)
    }

    @Test
    @Jira(story = "DSS-295/1.1")
    @ApiGateway(GET = "policies/:policyId/premiums") @DelPHI(wsdl = "ProductCalculatePremiums")
    public void testPremiumReturnCode() {
        assertStatusCode(this.response, 200)
    }

    @Test
    @Jira(story = "DSS-295/1.1")
    @ApiGateway(GET = "policies/:policyId/premiums") @DelPHI(wsdl = "ProductCalculatePremiums")
    public void testCurrentAndFutureFrequenciesMatch() {
        def noOfFutureFrequencies = response.responseData.future.size()
        assert noOfFutureFrequencies == 0, "Number of frequencies should be empty"
    }

    @Test
    @Jira(story = "DSS-295/1.2")
    @ApiGateway(GET = "policies/:policyId/premiums") @DelPHI(wsdl = "ProductCalculatePremiums")
    public void testCurrentFrequencies() {
        def currentFrequencies = response.responseData.current*.coverPeriod
        assert currentFrequencies == ["FORTNIGHTLY", "MONTHLY", "QUARTERLY", "YEARLY"], "Frequencies not as expected, got ${currentFrequencies}"
    }

}
