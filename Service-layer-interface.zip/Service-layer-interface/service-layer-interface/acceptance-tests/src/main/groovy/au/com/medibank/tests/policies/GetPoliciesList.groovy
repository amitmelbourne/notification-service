package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import org.junit.BeforeClass
import org.junit.Test

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.Matchers.hasItem
import static org.hamcrest.collection.IsCollectionWithSize.hasSize
import static org.hamcrest.core.IsEqual.equalTo
import static org.hamcrest.core.IsNull.notNullValue

/**
 * Test Fetch policies list API <code>/</code>
 * Created by Simon Collins on 2/07/2015.
 */

public class GetPoliciesList {
    static PoliciesApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasMultiplePolicies)
    }


    @Test
    @Jira(story = "DSS-38")
    @ApiGateway(GET = "policies?memberId") @DelPHI(wsdl = "BankReadBranchByBSB")
    public void testReturnsPolicyList() {
        def response = container.getPoliciesList(TestMember.hasMultiplePolicies['memberId']).getData()
        def Collection policies = response['policies'] as Collection
        assertThat policies, notNullValue()
        assertThat policies, hasSize(2)

        // only insured party
        policies.each { policy ->

            // Check we have a policy ID
            assertThat policy.id, notNullValue()

            // Check the policy is for an insured person who is an active member
            def partyRole = policy.member.partyRole
            def partyStatus = policy.member.partyStatus

            assertThat partyRole as Iterable, hasItem("INSURED")
            assertThat partyStatus as String, equalTo("ACTIVE")
        }
    }
}
