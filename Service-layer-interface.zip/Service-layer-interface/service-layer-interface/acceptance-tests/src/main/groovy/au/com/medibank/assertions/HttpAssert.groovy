package au.com.medibank.assertions


class HttpAssert {
    public static void assertErrorDescription(response1, String expectedErrorDescription, errorMessage = "") {
        assert response1['response']['responseData']['errorDescription'] == expectedErrorDescription,
                errorMessage
    }

    public static void assertStatusCode(response, Integer expectedCode, String errorMessage="Incorrect status code") {
        def actualCode
        try {
            actualCode = response.getStatusCode()
        }
        catch (Exception e){
            actualCode = response.getStatus()
        }
        assert actualCode == expectedCode, "${errorMessage}\nExpected ${expectedCode}, got ${actualCode}"
    }

    public static void assertStatusCodeInRange(response, HttpCodeRange codeRange) {
        def actualCode
        try {
            actualCode = response.getStatusCode()
        }
        catch (Exception e){
            actualCode = response.getStatus()
        }
        assert actualCode >= codeRange.getLowerLimit(), "Expected code in ${codeRange.getLowerLimit()} range, got ${actualCode}"
        assert actualCode <= codeRange.getLowerLimit(), "Expected code equal or less than ${codeRange.getUpperLimit()}, got ${actualCode}"
    }
}
