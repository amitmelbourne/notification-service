package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.MembersApiClient
import au.com.medibank.client.non_api.NonApiClientFactory
import au.com.medibank.client.non_api.OktaClient
import groovy.json.JsonSlurper
import org.junit.Before
import org.junit.Ignore
import org.junit.Test

//Staged has password
//Provision has no password

class OmsActivationAfterRegistrationStagedTest {
    private MembersApiClient membersApiClient
    private usersApiClient = ApiClientFactory.getUsersApiClient()
    private tokenMicroServiceClient = NonApiClientFactory.getTokenMicroService()
    private OktaClient oktaClient = NonApiClientFactory.getOktaClient()
    private response

    @Before
    public void setup() {
        def bpId = System.currentTimeMillis()
        def email = "test.data.${bpId}@email.com"

        membersApiClient = ApiClientFactory.getMembersApiClient(bpId)

        def createNewOktaUserHttpResponse = oktaClient.createNewUser(email, bpId + "")
        //selphi does not create the user but in SIT delphi will
        def registerHttpResponse = membersApiClient.register("P9999", "Jack", "Frost", "1983-01-01", email, "Abcd123.", false)
        String token = tokenMicroServiceClient.createToken(email);
        print("Token - "+token)
        response = usersApiClient.activate(token, email);
    }


    @Test
    @Ignore("Defect - DSS-516")
    @Jira(story = "DSS-139")
    @ApiGateway(GET= "users/:email/activate") @DelPHI(wsdls = ["updatecustomer", "interaction"])
    public void should_get_202_code_for_creating_a_new_user() {
        assert response.statusCode == 202
    }

    @Test
    @Ignore("Defect - DSS-516")
    @Jira(story = "DSS-139")
    @ApiGateway(GET= "users/:email/activate") @DelPHI(wsdls = ["updatecustomer", "interaction"])
    public void should_get_Authenticate_as_the_next_step() {
        String nextAction = new JsonSlurper().parseText(this.response.getBody())['_links']['next']['title']
        assert nextAction == 'Authenticate';
    }

}
