package au.com.medibank.tests.authentication

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.TokenApiGateway
import au.com.medibank.client.api.UsersApiGateway
import au.com.medibank.client.non_api.NonApiClientFactory
import au.com.medibank.client.non_api.OktaClient
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class LoginIDChange {
    static UsersApiGateway apiGateway
    static TokenApiGateway tokenApiGateway
    static UsersApiGateway usersApiGateway

    @BeforeClass
    public static void setup() {
        Map gateways = ApiGatewayClientFactory.getGateways(TestMember.hasCorrectPassword)
        tokenApiGateway = gateways.tokens
        usersApiGateway = gateways.users
    }

    @Test
    @Ignore('awaiting automation of Okta')
    @Jira(story = 'DSS-39/1.4')
    @DelPHI(wsdl = 'AccessManagementRetrieveUser')
    @ApiGateway(GET = 'users?policyNum={policyNumber}&firstName={name}&lastName={lastName}&dob={dob}')
    public void change_userId_with_valid_user() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']
        def firstName = 'Manish'
        def lastName = 'Nigade'
        def dob = '1990-01-01'

        UsersApiGateway instance = new UsersApiGateway(apiGateway.getRestClientInstance())

        def resp = instance.getChangeUserId(policyNumber, firstName, lastName, dob)
        assertStatusCode(resp, 200)
    }

    @Test
    @Ignore //due to DSS-300
    @Jira(story = 'DSS-39/1.4')
    @DelPHI(wsdl = 'AccessManagementRetrieveUser')
    @ApiGateway(GET = 'users?policyNum={policyNumber}&firstName={name}&lastName={lastName}&dob={dob}')
    public void test_change_userId_with_optout_user() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']
        def firstName = 'Anna'
        def lastName = 'Smith'
        def dob = '1985-01-01'

        UsersApiGateway instance = new UsersApiGateway(apiGateway.getRestClientInstance())

        def resp = instance.getChangeUserId(policyNumber, firstName, lastName, dob)
        assert resp.status != 200, "Unable to change user ID"
    }


    @Test
    @Ignore //due to DSS-300
    @Jira(story = 'DSS-39/1.4')
    @DelPHI(wsdl = 'AccessManagementRetrieveUser')
    @ApiGateway(GET = 'users?policyNum={policyNumber}&firstName={name}&lastName={lastName}&dob={dob}')
    public void change_userId_with_under_investigation_user() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']
        def firstName = 'Bad'
        def lastName = 'Guy'
        def dob = '1985-01-01'

        UsersApiGateway instance = new UsersApiGateway(apiGateway.getRestClientInstance())

        def resp = instance.getChangeUserId(policyNumber, firstName, lastName, dob)
        assert resp.status != 200, "Unable to change user ID"
    }


    @Test
    @Ignore //due to DSS-300
    @Jira(story = 'DSS-39/1.4')
    @DelPHI(wsdl = 'AccessManagementRetrieveUser')
    @ApiGateway(GET = 'users?policyNum={policyNumber}&firstName={name}&lastName={lastName}&dob={dob}')
    public void change_userId_with_no_email_user() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']
        def firstName = 'No'
        def lastName = 'Email'
        def dob = '1985-01-01'

        UsersApiGateway instance = new UsersApiGateway(apiGateway.getRestClientInstance())

        def resp = instance.getChangeUserId(policyNumber, firstName, lastName, dob)
        assert resp.status != 200, "Unable to change user ID"
    }


    @Test
    @Ignore //due to DSS-300
    @Jira(story = 'DSS-39/1.4')
    @DelPHI(wsdl = 'AccessManagementRetrieveUser')
    @ApiGateway(GET = 'users?policyNum={policyNumber}&firstName={name}&lastName={lastName}&dob={dob}')
    public void change_userId_with_not_register_user() {
        def policyNumber = TestPolicy.hasRegisteredAgr['policy']
        def firstName = 'No'
        def lastName = 'Email'
        def dob = '1985-01-01'

        UsersApiGateway instance = new UsersApiGateway(apiGateway.getRestClientInstance())

        def resp = instance.getChangeUserId(policyNumber, firstName, lastName, dob)
        assert resp.status != 200, "Unable to change user ID"
    }

    @Test
    @Jira(story = 'DSS-256/1.1')
    @DelPHI(wsdl = 'AccessManagementRetrieveUser')
    @ApiGateway(GET = 'users?policyNum={policyNumber}&firstName={name}&lastName={lastName}&dob={dob}')
    public void forgot_userid_with_register_but_not_activated_provision() {
        def policyNumber = TestPolicy.hasUserInProvision['policy']
        def firstName = 'Aaron'
        def lastName = 'Finch'
        def dob = '1990-01-01'


        new NonApiClientFactory().getOktaClient().changeUserIntoProvisionedState(TestMember.userInProvisionState['username'])
        def resp = usersApiGateway.getChangeUserId(policyNumber, firstName, lastName, dob)


        assertStatusCode(resp, 200)
        assert resp.getData()['errorCode'] == '6', "Error code in the response for the user not activated yet is not correct"
    }

    @Test @Ignore("Check with Manish")
    @Jira(story = 'DSS-256/1.1')
    @DelPHI(wsdl = 'AccessManagementRetrieveUser')
    @ApiGateway(GET = 'users?policyNum={policyNumber}&firstName={name}&lastName={lastName}&dob={dob}')
    public void forgot_userid_with_register_but_not_activated_stage() {
        def policyNumber = TestPolicy.hasUserInStage['policy']
        def firstName = 'James'
        def lastName = 'Faulkner'
        def dob = '1990-01-01'

        UsersApiGateway usersApiGateway = ApiGatewayClientFactory.getUsersApiGateway(TestMember.userInStageState)

        new NonApiClientFactory().getOktaClient().changeUserIntoProvisionedState(TestMember.userInStageState['username'])
        def resp = usersApiGateway.getChangeUserId(policyNumber, firstName, lastName, dob)

        assertStatusCode(resp, 200, "Forgot userID for non activated user is not returning appropriate response code")

        assert resp.getData()['errorCode'] == '6', "Error code in the response for the user not activated yet is not correct"
    }

    @Test
    @Ignore
    @Jira(story = 'DSS-256/1.1')
    @DelPHI(wsdl = 'AccessManagementRetrieveUser')
    @ApiGateway(GET = 'users?policyNum={policyNumber}&firstName={name}&lastName={lastName}&dob={dob}')
    public void forgot_userid_with_recovery_mode() {
        def policyNumber = TestPolicy.hasUserInStage['policy']
        def firstName = 'Shane'
        def lastName = 'Watson'
        def dob = '1990-01-01'

        UsersApiGateway apiGateway = ApiGatewayClientFactory.getUsersApiGateway(TestMember.hasWrongPassword)

        def resp = apiGateway.getChangeUserId(policyNumber, firstName, lastName, dob)

        assertStatusCode(resp, 200)
        assert resp.getData()['errorCode'] == '7', "Error code in the response for the user not activated yet is not correct"
    }

    @Test
    @Ignore
    @Jira(story = 'DSS-267/1.1')
    @DelPHI(wsdl = 'AccessManagementRetrieveUser')
    @ApiGateway(POST = 'users/$memberId/confirmEmail')
    public void verify_email_address_on_change_change_email() {
        OktaClient oktaInstance = NonApiClientFactory.getOktaClient()
        oktaInstance.unlockAccount(TestMember.hasPoliciesWithCorporatePremiumPayer['memberId'])
        TokenApiGateway tokenApiGateway = ApiGatewayClientFactory.getTokensApiGateway(TestMember.hasPoliciesWithCorporatePremiumPayer)
        UsersApiGateway usersApiGateway = ApiGatewayClientFactory.getUsersApiGateway(TestMember.hasPoliciesWithCorporatePremiumPayer)

        def updateLoginToken = tokenApiGateway.postTokenRequest("", "2018-12-20", "UpdateLogin", TestMember.hasPoliciesWithCorporatePremiumPayer['memberId'], false)
        // confirmChangeEmail was never implemented it seems
        assert usersApiGateway.confirmChangeEmail(TestMember.hasPoliciesWithCorporatePremiumPayer['memberId'], updateLoginToken).getStatus() == 201

        def oktaResponse = oktaInstance.getMemberDetails(TestMember.hasPoliciesWithCorporatePremiumPayer['memberId'])
        assert oktaResponse.body.toString().contains('"emailVerified":true')

    }
}
