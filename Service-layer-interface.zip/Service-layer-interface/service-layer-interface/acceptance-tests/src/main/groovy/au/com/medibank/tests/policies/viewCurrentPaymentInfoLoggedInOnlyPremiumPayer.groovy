package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import org.junit.BeforeClass
import org.junit.Ignore

class viewCurrentPaymentInfoBpIsOnlyPremiumPayer {


    static def responseData
    static def accounts

    static PoliciesApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasUpdateableAddress)
        // TODO: check [0] subscript is valid-- order may vary
        //responseData = restClient.getAuthenticatedUser().getPolicy('P.TC2.B1').getData()
        //accounts = responseData['members'][0]['accounts']
    }

    @Jira(story = 'DSS-98/1.2')
    @Ignore

    @ApiGateway(url = 'policies/:policyNumber')
    // TODO: check wsdl
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void check_payPremiums_present() {
        assert 'payPremiums' in accounts
    }

    @Jira(story = 'DSS-98/1.2')
    @Ignore

    @ApiGateway(url = 'policies/:policyNumber')
    // TODO: check wsdl
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void check_paidToDate_present() {
        assert 'coveragePaidUpToDate' in responseData
    }

    @Jira(story = 'DSS-98/1.2')
    @Ignore

    @ApiGateway(url = 'policies/:policyNumber')
    // TODO: check wsdl
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void check_paymentAmount_present() {
        assert 'paymentAmount' in responseData['premiums']['current']
    }

    @Jira(story = 'DSS-98/1.2')
    @Ignore

    @ApiGateway(url = 'policies/:policyNumber')
    // TODO: check wsdl
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void check_paymentMethod_present() {
        def mostRecentPayment = responseData['paymentHistory'][0]
        assert mostRecentPayment['paymentMethod'] in ['DD', 'EFT', 'Payroll', 'Manual']
        // TODO: wait for DSS-199: check multiple active accounts have no corporate involvement
    }

    @Jira(story = 'DSS-98/1.2')
    @Ignore

    @ApiGateway(url = 'policies/:policyNumber')
    // TODO: check wsdl
    @DelPHI(wsdl = 'PolicyReadByPolicyID')
    public void check_paymentFrequency_present() {
        def paymentFrequency = responseData['premiums']['current']['coverPeriod']
        assert paymentFrequency in ['YEARLY', 'HALF YEARLY', 'QUARTERLY', 'MONTHLY', 'FORTNIGHTLY']
    }
}