package au.com.medibank.tests.members

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.Ignore
import org.junit.Test

class PostClaimBenefit {

    static MembersApiGateway apiGateway


    //Happy Days
    @Test
    @Ignore
    @Jira(story = "DSS-99/3")
    @ApiGateway(POSTS = ["members/:memberId/accounts/benefits", "policies/:policyNumber"])
    @DelPHI(wsdls = ['CustomerReadByBPID','ManagerPolicyBeneficiary','ManageCustomerPaymentAccount'])
    public void post_benefits_claim_for_authenticated_user() {
        apiGateway = ApiGatewayClientFactory.getMembersApiGateway(TestMember.hasCorrectPassword)
        def result = apiGateway.postClaimBenefit(TestMember.hasCorrectPassword['memberId'], TestPolicy.hasRegisteredAgr['policy'], true)
        assert result == 201, "Response 201 not received during claim benefits"
    }

    @Test
    @Jira(story = "DSS-99/3")
    @Ignore
    @ApiGateway(POST= "members/:memberId/accounts/benefits")
    @DelPHI(wsdls = ['CustomerReadByBPID','ManagerPolicyBeneficiary','ManageCustomerPaymentAccount'])
    public void post_benefits_claim_for_unauthenticated_user() {
        def apiGatewayWithWrongPassword = ApiGatewayClientFactory.getUnauthorisedMembersGateway()
        apiGatewayWithWrongPassword.postClaimBenefit(TestMember.hasUpdateableAddress['memberId'], TestPolicy.canRequestCard['policy'], true)
        throw new Exception()
    }
}
