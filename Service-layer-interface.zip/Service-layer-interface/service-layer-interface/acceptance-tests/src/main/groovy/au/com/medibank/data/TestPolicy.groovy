package au.com.medibank.data

import au.com.medibank.Config

class TestPolicy {
    static DevToSitPolicyMapping = [
            'P1234': '40001591', // Johnny Depp BPId 4100001626-- how to override a default--
            // except use a non-default SIT BPId
    ]

    static defaultSitPolicyId = '40001591' // Johnny Depp BPId 4100001626

    static canRequestCard = composePolicy 'P.TC5.A1', TestMember.hasMultiplePolicies
    static hasPaymentHistory = composePolicy 'P.TC5.A1', TestMember.hasPaymentHistory
    static hasReceiveBenefitsAccount = composePolicy 'P1234', TestMember.hasReceivedBenefitsAccount
    static hasMultipleMembersOneHasReceiveBenefitsAccount = composePolicy 'P.TC4.D1', TestMember.memberOfPolicyThatHasReceiveBenefitsAccount
    static hasOneMemberWithPayPremiumsAccount = composePolicy 'P.TC2.B1', TestMember.onlyMemberOfPolicyHasReceiveBenefitsAccount
    static hasRegisteredAgr = composePolicy 'P9999', TestMember.hasCorrectPassword
    static hasNonRegisteredAgr = composePolicy 'P.TC1.A1', TestMember.hasPolicywithNoAgr
    static hasMultiplePayerWithIndividualAndCorpInAmount = composePolicy 'P.TC11.A1', TestMember.hasPoliciesWithMultiplePayer
    static hasMultiplePayerWithIndividualInAmount = composePolicy 'P.TC12.A1', TestMember.hasPoliciesWithMultiplePayer
    static hasMultiplePayerWithIndividualAndCorpInPercentage = composePolicy 'P.TC13.A1', TestMember.hasPoliciesWithMultiplePayer
    static hasMultiplePayerWithIndividualInPercentage = composePolicy 'P.TC14.A1', TestMember.hasPoliciesWithMultiplePayer
    static hasMultiplePayerWithPaymentMethod = composePolicy 'P.TC15.A1', TestMember.hasPoliciesWithMultiplePayer
    static hasCorporatePremiumPayer = composePolicy 'P.TC16.A1', TestMember.hasPoliciesWithCorporatePremiumPayer
    static hasUserInProvision = composePolicy 'P.TC19.A1', TestMember.userInProvisionState
    static hasUserInStage = composePolicy 'P.TC20.A1', TestMember.userInStageState
    static nonCorpHasExtrasOnlyCoverage = composePolicy 'P.Excess.8', TestMember.nonCorpHasExtrasOnlyCoverage
    static nonCorpHas2OrMoreExcessLevels = composePolicy 'P1236', TestMember.nonCorpHas2OrMoreExcessLevels
    static corp2OrMoreExcessLevelsSubsidised = composePolicy 'P.Excess.5', TestMember.corp2OrMoreExcessLevelsSubsidised
    static corp2OrMoreExcessLevelsUnsubsidised = composePolicy 'P.Excess.6', TestMember.corp2OrMoreExcessLevelsUnsubsidised
    static corpExcessLevelsMixedSubsidisedAndNotSubsidised = composePolicy 'P.Excess.7', TestMember.corpExcessLevelsMixedSubsidisedAndNotSubsidised
    static nonCorpOneExcessLevel = composePolicy 'P9999', TestMember.nonCorpOneExcessLevel
    static corpOneExcessLevelNonSubsidised = composePolicy 'P.Excess.2', TestMember.corpOneExcessLevelNonSubsidised
    static hasMultiplePayeesWithIndividualAndCorp = composePolicy 'P.TC13.A1', TestMember.hasMultiplePayerPolicyWithIndividualAndCorp
    static doesNotExist = composePolicy '6666', TestMember.doesNotExist
    static hasDirectDebit = composePolicy 'P.TC1.A1', TestMember.hasDirectDebit
    static basicPolicy = composePolicy 'P9999', TestMember.hasBasicPolicy
    static hasNoBankAccount = composePolicy 'P9999', TestMember.corpCanHaveCreditCardAdded
    static corpHasNoAccount = composePolicy 'P.TC1.A1', TestMember.corpHasNoAccount



    // ASSUMPTION: ids will be the same for SIT and PreProd, but will differ from DEV
    static composePolicy(devPolicyId, member) {
        def envPolicyId = Config.environment.startsWith('DEV') ? devPolicyId : DevToSitPolicyMapping[devPolicyId]
        if (!envPolicyId) {
            envPolicyId = defaultSitPolicyId
        }
        return [
                'policy': envPolicyId,
                'member': member
        ]
    }
}
