package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.UsersApiGateway
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.MembersApiClient
import au.com.medibank.data.TestMember
import org.junit.Before

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class MatchEmailInSapRegistrationTest {

    def static userWithEmailMatchesInSap = TestMember.member11;
    private MembersApiClient registrationRequest
    private response


    @Before
    public void setup() {
        registrationRequest = ApiClientFactory.getMembersApiClient()
        response = this.registrationRequest.register(UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MATCHES_IN_SAP)
    }



     @Jira(stories = ["DSS-23/1.0", "DSS-23/1.3"])
    @ApiGateway(POST = "users") @DelPHI(wsdl = "N/A")
    public void successful_request_for_registration_with_match_email_in_sap_201_error() {
        assertStatusCode(response, 201, "Registration with appropriate member details not working as per expectations")
    }


    @Jira(stories = ["DSS-23/1.0", "DSS-23/1.3"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void successful_request_for_registration_with_match_email_in_sap_202_error() {
        this.registrationRequest.rawOktaAuthenticationResponse(MatchEmailInSapRegistrationTest.userWithEmailMatchesInSap['username'],
                UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MATCHES_IN_SAP.getPassword())
        def passwordChangeReturnCode = new UsersApiGateway(this.registrationRequest.getRestClientInstance()).postNewPassword(MatchEmailInSapRegistrationTest.userWithEmailMatchesInSap['username'],
                UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MATCHES_IN_SAP.getPassword(), TestMember.defaultTestPassword)
        assertStatusCode(passwordChangeReturnCode, 202, "Unable to change default password for a new password")
    }
}