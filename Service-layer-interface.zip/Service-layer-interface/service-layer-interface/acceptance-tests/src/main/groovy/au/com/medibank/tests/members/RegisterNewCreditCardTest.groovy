package au.com.medibank.tests.creditcard

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.Before
import org.junit.Test

class RegisterNewCreditCardTest {

    Map gateway
    private MembersApiGateway membersApiGateway
    private PoliciesApiGateway policyApiGateway
    def testMember = TestMember.corpHasNoAccount
    def testPolicy = TestPolicy.corpHasNoAccount

    @Before
    public void setup() {
        gateway = ApiGatewayClientFactory.getGateways(testMember)
        membersApiGateway = gateway.members
        policyApiGateway = gateway.policies
    }

    @Test
    @Jira(story = 'DSS-296/2.?')
    @ApiGateway(GETS = ['/members/:id/accounts', '/members/:id'])
    @DelPHI(wsdls = ['PolicyReadByBPID',
            'ManageCustomerUpdateCustomer',
            'ManagePolicyPremiumPayer',
            'ManagePolicyUpdatePremium'])
    public void list_credit_cards_when_none_exist() {
        def testPolicyId = testPolicy.policy
        def accountsList = membersApiGateway.listCreditCards(testPolicyId).responseData.accounts
        assert accountsList.size() == 0, "Found account when none was expected"
    }

    @Test
    @Jira(stories = ['DSS-296/2.?'])
    @ApiGateway(POST = '/members/:id/accounts{directDebit}')
    @DelPHI(wsdls = [
            'PolicyReadByBPID',
            'ManageCustomerUpdateCustomer',
            'ManagePolicyPremiumPayer',
            'ManagePolicyUpdatePremium',
            'CustomerReadByBPID'
    ]
    )
    public void assign_new_credit_card() {
        def getPolicyResp = policyApiGateway.getPolicy(testPolicy.policy)
        def policyEtag = ResponseHelper.generateResponseHeaderMap(getPolicyResp).ETag
        def memberResp = membersApiGateway.getContactDetails(testMember.memberId)
        def memberEtag = ResponseHelper.generateResponseHeaderMap(memberResp).ETag
        def response = membersApiGateway.assignCreditCard(
                testMember.memberId,
                testPolicy.policy,
                "John Smith",
                "****-******-0789",
                "03/16",
                memberEtag + ',' + policyEtag)
        assert response.getStatus() == 201
    }
}