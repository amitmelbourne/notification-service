package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.api.UsersApiGateway
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.MembersApiClient
import au.com.medibank.data.TestMember
import org.junit.Before

import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class MismatchEmailInSapAndOverrideRegistrationTest {
    private MembersApiGateway apiGatewayInstance

    def static userWithEmailMatchesInSap = TestMember.member11;
    def static userWithEmailMisMatchesInSap = "mismatch@example.com"
    private MembersApiClient registrationRequest


    @Before
    public void setup() {
        apiGatewayInstance = ApiGatewayClientFactory.getMembersApiGateway()
        registrationRequest = ApiClientFactory.getMembersApiClient()
    }



    @Jira(stories = ["DSS-23/2.0", "DSS-23/2.5", "DSS-107/1.5"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void successful_request_for_registration_with_mismatch_email_in_sap_and_override_409() {
        def response = this.registrationRequest.register(UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_OVERRIDE)
//        assert response['statusCode'] == 409, "Registration with email mismatch not working as per expectations"
        assertStatusCode(response, 409)
    }


    @Jira(stories = ["DSS-23/2.0", "DSS-23/2.5", "DSS-107/1.5"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void successful_request_for_registration_with_mismatch_email_in_sap_and_override_201() {
      def  response = this.registrationRequest.register(UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_OVERRIDE_TRUE)
        assertStatusCode(response, 201)
    }


    @Jira(stories = ["DSS-23/2.0", "DSS-23/2.5", "DSS-107/1.5"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void successful_request_for_registration_with_mismatch_email_in_sap_and_override_202() {
        this.registrationRequest.rawOktaAuthenticationResponse(MismatchEmailInSapAndOverrideRegistrationTest.userWithEmailMatchesInSap['username'],
                UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_OVERRIDE.getPassword())
        int passwordChangeReturnCode = new UsersApiGateway(this.registrationRequest.getRestClientInstance()).postNewPassword(MismatchEmailInSapAndOverrideRegistrationTest.userWithEmailMatchesInSap['username'],
                UserTestData.SUCCESSFUL_REGISTRATION_REQUEST_WITH_EMAIL_MISMATCHES_IN_SAP_AND_OVERRIDE.getPassword(), TestMember.defaultTestPassword)
        assert passwordChangeReturnCode == 202, "Expected 202, got ${passwordChangeReturnCode}"
    }

}