package au.com.medibank.client.non_api

import com.mashape.unirest.http.HttpResponse
import groovy.json.JsonOutput

class UsersApiClient extends BaseApiClient {

    UsersApiClient(String baseUrl, Map defaultHeaders) {
        super(baseUrl, defaultHeaders)
    }

    def activate(String token, String email) {
        HttpResponse<String> response = postWithDefaultHeaders("users/${email}/activate")
                .body(JsonOutput.toJson([tokenID: token]))
                .asString();
        return response;
    }


}
