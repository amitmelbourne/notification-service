package au.com.medibank.tests.users

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.non_api.ApiClientFactory
import au.com.medibank.client.non_api.MembersApiClient
import org.junit.Before
import org.junit.Test

import static au.com.medibank.assertions.HttpAssert.assertErrorDescription
import static au.com.medibank.assertions.HttpAssert.assertStatusCode

class MultipleBusinessPartnersRegistrationTest {

    private MembersApiClient registrationRequest
    private response


    @Before
    public void setup() {
        registrationRequest = ApiClientFactory.getMembersApiClient()
        response = this.registrationRequest.register(UserTestData.REGISTRATION_REQUEST_WITH_MULTIPLE_BUSINESS_PARTNER)

    }


    @Test
    @Jira(stories = ["DSS-23/1.1", "DSS-107/1.3"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void request_for_registration_with_multiple_business_partner_should_return_422() {
//        assert response['statusCode'] == 422,
//        "Error description either not return OR might differ with expected: ${UserTestData.REGISTRATION_REQUEST_WITH_MULTIPLE_BUSINESS_PARTNER.getErrorDescription()}"
        assertStatusCode(response, 422)
    }


    @Test
    @Jira(stories = ["DSS-23/1.1", "DSS-107/1.3"])
    @ApiGateway(POST = "users")
    @DelPHI(wsdl = "N/A")
    public void request_for_registration_with_multiple_business_partner_should_have_an_error_message() {
        assertErrorDescription(this.response,
                UserTestData.REGISTRATION_REQUEST_WITH_MULTIPLE_BUSINESS_PARTNER.getErrorDescription(),
                "Error description either not return OR might differ with expected: ${UserTestData.REGISTRATION_REQUEST_WITH_MULTIPLE_BUSINESS_PARTNER.getErrorDescription()}")
    }

}