package au.com.medibank.client.api

import au.com.medibank.Config
import au.com.medibank.client.non_api.NonApiClientFactory
import groovyx.net.http.HttpResponseException
import groovyx.net.http.RESTClient

import static au.com.medibank.assertions.DescriptiveErrors.failHttpResponseException
import static groovyx.net.http.ContentType.JSON

class RestClientFactory {

    public static List getAuthenticatedRestClient(member) {
        NonApiClientFactory.getOktaClient().unlockAccount(member.memberId)
        RESTClient restClient = getBaseRestClient(new Config().getBaseApiUrl());
        def postResponse
        try {
            postResponse = restClient.post(path: "sessions", headers: ['Content-Type': 'application/json'],
                    body: member, requestContentType: JSON)
        }
        catch (HttpResponseException e) {
            failHttpResponseException(e)
        }
        def sessionId = postResponse.responseData.sessionId
        def apiSessionToken = postResponse.getHeaders().'APISessionToken'
        if (apiSessionToken == null) {
            throw new RuntimeException("No APISessionToken, so no point in proceeding")
        }
        restClient.headers['APISessionToken'] = apiSessionToken
        return [restClient, sessionId]
    }

    public static RESTClient getUnauthenticatedRestClient() {
        def restClient = getBaseRestClient(new Config().getBaseApiUrl())
        restClient.headers['APISessionToken'] = 'tokenWhichDoesNotHaveRightsToLookAtData'
        return restClient
    }

    private static RESTClient getBaseRestClient(baseUrl) {
        RESTClient restClient = new RESTClient(baseUrl)
        def config = new Config()
        restClient.headers['client_id'] = config.getClientId()
        restClient.headers['client_secret'] = config.getClientSecret()
        restClient.ignoreSSLIssues();
        return restClient
    }
}
