package au.com.medibank.tests.members

import au.com.medibank.ResponseHelper
import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.client.non_api.NonApiClientFactory
import au.com.medibank.client.non_api.SelphiClient
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.After
import org.junit.Before
import org.junit.Ignore
import org.junit.Test

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.core.IsEqual.equalTo

//@Jira(story = "DSS-208") TODO: why is DSS-208 annotation here?
public class UpdateBankAccountTest {

        // TODO: check annotations in this class

    private MembersApiGateway membersApiGateway
    private PoliciesApiGateway policiesApiGateway
    private SelphiClient selphiClient
    private result

    @Before
    public void setup() {
        Map gateways = ApiGatewayClientFactory.getGateways(TestMember.hasCorrectPassword)
        membersApiGateway = gateways.members
        policiesApiGateway = gateways.policies
        selphiClient = NonApiClientFactory.getSelphiClient()
        selphiClient.resetUserSession(membersApiGateway.getCurrentSessionId())
        def resp = membersApiGateway.getMemberContactDetails(TestMember.hasCorrectPassword['memberId'])
        def memberEtag = ResponseHelper.generateResponseHeaderMap(resp).get("ETag")


        resp = policiesApiGateway.getPolicy(TestPolicy.hasRegisteredAgr)
        result = this.membersApiGateway.postNewBankAccount(TestMember.hasCorrectPassword, "082-024",memberEtag + "," + apiGatewayInstance.generateResponseHeaderMap(resp).get('ETag'))
    }

    @After
    public void teardown(){
        selphiClient.resetUserSession(membersApiGateway.getCurrentSessionId())
    }

    @Test
    @Ignore("Jarrod to look")
    @Jira(story = 'DSS-99')
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    public void POST_response_code_is_201(){
        assertThat(this.result.status, equalTo(201));
    }

    @Test
    @Ignore("Jarrod to look")
    @Jira(story = 'DSS-99')
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"], GETS=["members/:memberId/accounts"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    public void GET_bank_account_should_no_more_than_2_accounts_after_update(){
        def accounts = policiesApiGateway.getPolicy(TestPolicy.hasRegisteredAgr['policy']).getData();

        assertThat("Number of Bank accounts is exceeding more than one for selected member",accounts['members']['payment']['account'].size <= 2)
    }

    @Test
    @Ignore("Jarrod to look")
    @Jira(story = 'DSS-99/2.2')
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"]) @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    public void assertResponsePayloadAccountNum(){
        assertThat(this.result.responseData.get("accountNum"), equalTo("123456"));
    }

    @Test
    @Ignore("Jarrod to look")
    @Jira(story = 'DSS-99')
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"]) @DelPHI(wsdls = ["CustomerReadByBPID"])
    public void assertResponsePayloadAccountType(){
        assertThat(this.result.responseData.get("accountType"), equalTo("Bank"));
    }

    @Test
    @Ignore("Jarrod to look")
    @Jira(story = 'DSS-99/2.1')
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    public void assertResponsePayloadAccountBsb(){
        assertThat(this.result.responseData.get("bsb"), equalTo("123-456"));
    }

    @Test
    @Ignore("Jarrod to look")
    @Jira(story = 'DSS-99/2.3')
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"]) @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    public void assertResponsePayloadAccountHolderName(){
        assertThat(this.result.responseData.get("accountHolderName"), equalTo("John Smith"));
    }

    @Test
    @Ignore("Jarrod to look")
    @Jira(story = 'DSS-99')
    @ApiGateway(POSTS =  ["members/:memberId/accounts/directdebit"])
    @DelPHI(wsdls = ["PolicyReadByBPID", "ManageCustomerPaymentAccount", "ManagePolicyPremiumPayer"])
    public void assertResponsePayloadType(){
        assertThat(this.result.responseData.get("type"), equalTo("accounts"));
    }
}
