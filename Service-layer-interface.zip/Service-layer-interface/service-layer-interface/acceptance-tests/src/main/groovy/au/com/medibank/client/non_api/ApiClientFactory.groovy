package au.com.medibank.client.non_api

import au.com.medibank.Config

public class ApiClientFactory {
    static private config = new Config()

    public static UsersApiClient getUsersApiClient() {
        return new UsersApiClient(config.getUsersMicroServiceUrl(),
                [
                        "content-type": "application/json",
                        "client_id": config.getClientId(),
                        "client_secret": config.getClientSecret()
                ]
        );
    }

    public static MembersApiClient getMembersApiClient() {
        return new MembersApiClient(config.getBaseApiUrl(),
                [
                        "content-type": "application/json",
                        "client_id": config.getClientId(),
                        "client_secret": config.getClientSecret()
                ]);
    }

}
