package au.com.medibank

class ResponseHelper {
    public static Map generateResponseHeaderMap(responseData){
        ArrayList headers = responseData.getAllHeaders()
        Map responseMap = [:]

        headers.each {
            String[] mapValue = it.toString().split(":")
            responseMap.put(mapValue[0].trim(), mapValue[1].trim())
        }
        return responseMap
    }

}
