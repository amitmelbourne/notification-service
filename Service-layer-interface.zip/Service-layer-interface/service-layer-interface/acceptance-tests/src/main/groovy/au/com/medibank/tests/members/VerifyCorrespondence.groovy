package au.com.medibank.tests.members


import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.MembersApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.helpers.AssertHelper
import au.com.medibank.helpers.DateHelper
import org.junit.BeforeClass
import org.junit.Test

import static org.hamcrest.MatcherAssert.assertThat
import static org.hamcrest.core.IsEqual.equalTo
import static org.hamcrest.core.IsNull.notNullValue

class VerifyCorrespondence {
    static MembersApiGateway container;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getMembersApiGateway(TestMember.hasUpdateableAddress)
    }


    @Test
    @Jira(stories = ["DSS-60/1.2", "DSS-60/1.3"])
    @ApiGateway(GET = "members/:memberId/correspondence")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void correspondence_response_details() throws Exception {
        MembersApiGateway correspondenceHelper = new MembersApiGateway(container.restClient)

        def response = correspondenceHelper.getCorrespondence(TestMember.hasStoredCard['memberId'], '01', '', '', '').getData()
        def numberOfRecords = 0

        response['items'].each { eachCorrespondence ->
            assertThat response, notNullValue()
            AssertHelper.assertHasFields "Response", eachCorrespondence, ['type', 'timestamp', 'status', 'typeCode', 'description', 'channelId']
            numberOfRecords++;
        }
        assertThat "Number of records are ${numberOfRecords} whereas expected is 10 or less", numberOfRecords <= 10
    }

    @Test
    @Jira(story = "DSS-60/1.5")
    @ApiGateway(GET = "members/:memberId/correspondence")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void correspondence_with_no_records() throws Exception {
        MembersApiGateway correspondenceHelper = new MembersApiGateway(container.restClient)

        def response = correspondenceHelper.getCorrespondence(TestMember.hasStoredCard['memberId'], '01', '2015-01-01', '2015-01-01', '').getData()
        def numberOfRecords = 0

        response['items'].each { eachCorrespondence ->
            assertThat response, notNullValue()
            AssertHelper.assertHasFields "Response", eachCorrespondence, ['type', 'timestamp', 'status', 'typeCode', 'description', 'channelId']
            numberOfRecords++;
        }
        assertThat "Number of records are ${numberOfRecords} whereas expected is 10 or less", numberOfRecords == 0
    }

    @Test
    @Jira(story = "DSS-60")
    @ApiGateway(GET = "members/:memberId/correspondence")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void validate_correspondence_with_typeCode() throws Exception {

        MembersApiGateway correspondenceHelper = new MembersApiGateway(container.restClient)
        def typeCodeId = '01'

        def response = correspondenceHelper.getCorrespondence(TestMember.hasStoredCard['memberId'], typeCodeId, '', '', '').getData()
        def numberOfRecords = 0

        assertThat response, notNullValue()
        response['items'].each { eachCorrespondence ->
            assertThat response, notNullValue()
            assertThat eachCorrespondence['typeCode'] as String, equalTo(typeCodeId)
        }
    }

    @Test
    @Jira(story = "DSS-60/1.2")
    @ApiGateway(GET = "members/:memberId/correspondence")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void correspondence_with_limit() throws Exception {
        MembersApiGateway correspondenceHelper = new MembersApiGateway(container.restClient)
        def limitRecords = '20'

        def response = correspondenceHelper.getCorrespondence(TestMember.hasStoredCard['memberId'], '01', '', '', limitRecords).getData()
        def numberOfRecords = 0

        response['items'].each { eachCorrespondence ->
            assertThat response, notNullValue()
            AssertHelper.assertHasFields "Response", eachCorrespondence, ['type', 'timestamp', 'status', 'typeCode', 'description', 'channelId']
            numberOfRecords++;
        }
        assertThat "Number of records are ${numberOfRecords} whereas expected are ${limitRecords}", numberOfRecords.toString() == limitRecords
    }

    @Test
    @Jira(story = "DSS-60/1.4")
    @ApiGateway(GET = "members/:memberId/correspondence")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void correspondence_with_from_without_until() throws Exception {
        MembersApiGateway correspondenceHelper = new MembersApiGateway(container.restClient)
        def from = DateHelper.getDateInPast(20)
        def until = ''

        def response = correspondenceHelper.getCorrespondence(TestMember.hasStoredCard['memberId'], '01', from, until, '').getData()
        response['items'].each { eachCorrespondence ->
            assertThat eachCorrespondence, notNullValue()

            assertThat "Actual - ${DateHelper.dateFormatter(eachCorrespondence['timestamp'])} && Expected - ${DateHelper.dateFormatter(from)}",
                    DateHelper.dateFormatter(eachCorrespondence['timestamp']).after(DateHelper.dateFormatter(from)) ||
                            DateHelper.dateFormatter(eachCorrespondence['timestamp']).equals(DateHelper.dateFormatter(from))

        }
    }

    @Test
    @Jira(story = "DSS-60/1.1")
    @ApiGateway(GET = "members/:memberId/correspondence")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void correspondence_without_from_with_until() throws Exception {
        MembersApiGateway correspondenceHelper = new MembersApiGateway(container.restClient)
        def from = ''
        def until = DateHelper.getDateInPast(20)

        def response = correspondenceHelper.getCorrespondence(TestMember.hasStoredCard['memberId'], '01', from, until, '').getData()
        response['items'].each { eachCorrespondence ->
            assertThat eachCorrespondence, notNullValue()

            assertThat "Actual - ${DateHelper.dateFormatter(eachCorrespondence['timestamp'])} && Expected - ${DateHelper.dateFormatter(until)}",
                    DateHelper.dateFormatter(eachCorrespondence['timestamp']).before(DateHelper.dateFormatter(until)) ||
                            DateHelper.dateFormatter(eachCorrespondence['timestamp']).equals(DateHelper.dateFormatter(until))

            assertThat "Actual - ${DateHelper.dateFormatter(eachCorrespondence['timestamp'])} && Expected - ${DateHelper.dateFormatter(DateHelper.getDateInPast(30))}",
                    DateHelper.dateFormatter(eachCorrespondence['timestamp']).after(DateHelper.dateFormatter(DateHelper.getDateInPast(30))) ||
                            DateHelper.dateFormatter(eachCorrespondence['timestamp']).equals(DateHelper.dateFormatter(DateHelper.getDateInPast(30)))


        }
    }

    @Test
    @Jira(story = "DSS-60/1.1")
    @ApiGateway(GET = "members/:memberId/correspondence")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void correspondence_with_from_with_until() throws Exception {
        MembersApiGateway correspondenceHelper = new MembersApiGateway(container.restClient)
        def from = DateHelper.getDateInPast(25)
        def until = DateHelper.getDateInPast(10)

        def response = correspondenceHelper.getCorrespondence(TestMember.hasStoredCard['memberId'], '01', from, until, '').getData()
        response['items'].each { eachCorrespondence ->
            assertThat eachCorrespondence, notNullValue()

            assertThat "Actual - ${DateHelper.dateFormatter(eachCorrespondence['timestamp'])} && Expected - ${DateHelper.dateFormatter(until)}",
                    DateHelper.dateFormatter(eachCorrespondence['timestamp']).before(DateHelper.dateFormatter(until)) ||
                            DateHelper.dateFormatter(eachCorrespondence['timestamp']).equals(DateHelper.dateFormatter(until))

            assertThat "Actual - ${DateHelper.dateFormatter(eachCorrespondence['timestamp'])} && Expected - ${DateHelper.dateFormatter(from)}",
                    DateHelper.dateFormatter(eachCorrespondence['timestamp']).after(DateHelper.dateFormatter(from)) ||
                            DateHelper.dateFormatter(eachCorrespondence['timestamp']).equals(DateHelper.dateFormatter(from))

        }
    }

    @Test
    @Jira(story = "DSS-60/1.1")
    @ApiGateway(GET = "members/:memberId/correspondence")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void correspondence_with_from_with_until_for_morethan_month() throws Exception {
        MembersApiGateway correspondenceHelper = new MembersApiGateway(container.restClient)
        def from = DateHelper.getDateInPast(45)
        def until = DateHelper.getDateInPast(1)

        def response = correspondenceHelper.getCorrespondence(TestMember.hasStoredCard['memberId'], '01', from, until, '').getData()
        response['items'].each { eachCorrespondence ->
            assertThat eachCorrespondence, notNullValue()

            assertThat "Actual - ${DateHelper.dateFormatter(eachCorrespondence['timestamp'])} && Expected - ${DateHelper.dateFormatter(until)}",
                    DateHelper.dateFormatter(eachCorrespondence['timestamp']).before(DateHelper.dateFormatter(until)) ||
                            DateHelper.dateFormatter(eachCorrespondence['timestamp']).equals(DateHelper.dateFormatter(until))

            assertThat "Actual - ${DateHelper.dateFormatter(eachCorrespondence['timestamp'])} && Expected - ${DateHelper.dateFormatter(from)}",
                    DateHelper.dateFormatter(eachCorrespondence['timestamp']).after(DateHelper.dateFormatter(from)) ||
                            DateHelper.dateFormatter(eachCorrespondence['timestamp']).equals(DateHelper.dateFormatter(from))

        }
    }

    @Test
    @Jira(story = "DSS-60/1.1")
    @ApiGateway(GET = "members/:memberId/correspondence")
    @DelPHI(wsdl = 'MemberCommsReadCorrespondenceItemByBPID')
    public void correspondence_with_from_with_until_futuredate() throws Exception {
        MembersApiGateway correspondenceHelper = new MembersApiGateway(container.restClient)
        def from = DateHelper.getDateInPast(45)
        def until = DateHelper.getDateInPast(-1)

        def response = correspondenceHelper.getCorrespondence(TestMember.hasStoredCard['memberId'], '01', from, until, '').getData()
        response['items'].each { eachCorrespondence ->
            assertThat eachCorrespondence, notNullValue()

            assertThat "Actual - ${DateHelper.dateFormatter(eachCorrespondence['timestamp'])} && Expected - ${DateHelper.dateFormatter(until)}",
                    DateHelper.dateFormatter(eachCorrespondence['timestamp']).before(DateHelper.dateFormatter(until)) ||
                            DateHelper.dateFormatter(eachCorrespondence['timestamp']).equals(DateHelper.dateFormatter(until))

            assertThat "Actual - ${DateHelper.dateFormatter(eachCorrespondence['timestamp'])} && Expected - ${DateHelper.dateFormatter(from)}",
                    DateHelper.dateFormatter(eachCorrespondence['timestamp']).after(DateHelper.dateFormatter(from)) ||
                            DateHelper.dateFormatter(eachCorrespondence['timestamp']).equals(DateHelper.dateFormatter(from))

        }
    }
}