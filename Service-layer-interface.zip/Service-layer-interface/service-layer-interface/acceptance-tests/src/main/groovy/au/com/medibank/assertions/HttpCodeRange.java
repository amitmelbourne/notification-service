package au.com.medibank.assertions;


public enum HttpCodeRange {

    _400(400, 499), _500(500, 599);

    int lowerLimit;
    int upperLimit;

    HttpCodeRange(int lowerLimit, int upperLimit) {
        this.lowerLimit = lowerLimit;
        this.upperLimit = upperLimit;
    }

    public int getLowerLimit() {
        return lowerLimit;
    }

    public int getUpperLimit() {
        return upperLimit;
    }
}
