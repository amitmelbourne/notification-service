package au.com.medibank.client.api

import groovyx.net.http.HttpResponseDecorator
import groovyx.net.http.HttpResponseException
import groovyx.net.http.RESTClient

import static au.com.medibank.assertions.DescriptiveErrors.failHttpResponseException
import static groovyx.net.http.ContentType.JSON

class PaymentsApiGateway extends BaseApiGateway {
    def PaymentsApiGateway() {}
    def PaymentsApiGateway(RESTClient restClient) {
        super(restClient)
    }
    def PaymentsApiGateway(RESTClient restClient, String sessionId) {
        super(restClient, sessionId)
    }

    def getDeployedVersion() {
        restClient.get(path: "payments/version")
    }

    def HttpResponseDecorator postAdhocPaymentWithNewCard() {
        def sessionToken = restClient.headers['APISessionToken']
        try {
            def resp = restClient.post(path: "payments/token", body: [type: 'paymentTokenRequest', amount: '512.57', successURL: 'http://medibank.com.au/oms/payment', errorURL: 'http://medibank.com.au/oms/payment-error'], headers: [
                    APISessionToken: sessionToken, 'Content-Type': 'application/json'], requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
    }

    def HttpResponseDecorator postAdhocPaymentWithStoredCard(String policyId, String policyType, String policyLink, String cardToken, String cardholderName, String orderNumber, String amount) {
        def sessionToken = restClient.headers['APISessionToken']
        def policyDetails = [id: policyId, type: policyType, _link: policyLink]


        try {
            def resp = restClient.post(path: "payments", body: [type: 'payments', id: '12300023', policyRef: policyDetails, customerRefID: '123456', amount: amount, cardToken: cardToken, cardHolderName: cardholderName, orderNum: orderNumber]
                    , headers: [
                    APISessionToken: sessionToken, 'Content-Type': 'application/json'], requestContentType: JSON)
        } catch (HttpResponseException e) {
            failHttpResponseException(e)
            throw e
        }
    }

    def HttpResponseDecorator postTokenRequest(String secretId, String expiryDate, String tokenType, String memberId, expectingException = false) {
        def tokenDetails = [tokenType: tokenType, expiryDate: expiryDate, tokenProperties: [INTERACTION_ID: memberId, CHANGE_STATE_ID: 123456, BP_ID: memberId, USERNAME: memberId + '@medibank.com.au']]
        def sessionToken = restClient.headers['APISessionToken']

        try {
            def resp = restClient.post(path: "tokens", body: tokenDetails, headers: [
                    APISessionToken: sessionToken, 'Content-Type': 'application/json'], requestContentType: JSON)
        } catch (HttpResponseException e) {
            if (expectingException == false) {
                failHttpResponseException(e)
            }
            throw e
        }
    }

    def HttpResponseDecorator postUsedTokenRequest(String token, String secretId, expectingException = false) {
        def tokenDetails = [token: token, secret: secretId]
        def sessionToken = restClient.headers['APISessionToken']

        try {
            def resp = restClient.post(path: "tokens/used", body: tokenDetails, headers: [
                    APISessionToken: sessionToken, 'Content-Type': 'application/json'], requestContentType: JSON)
        } catch (HttpResponseException e) {
            if (expectingException == false) {
                failHttpResponseException(e)
            }
            throw e
        }
    }


}