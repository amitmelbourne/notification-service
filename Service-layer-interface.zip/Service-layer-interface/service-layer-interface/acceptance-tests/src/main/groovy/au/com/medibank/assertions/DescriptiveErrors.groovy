package au.com.medibank.assertions;

import groovyx.net.http.HttpResponseException;

public class DescriptiveErrors {
    public static void failHttpResponseException(HttpResponseException e) {
        assert false, e.getResponse().responseData.toString()
    }
}
