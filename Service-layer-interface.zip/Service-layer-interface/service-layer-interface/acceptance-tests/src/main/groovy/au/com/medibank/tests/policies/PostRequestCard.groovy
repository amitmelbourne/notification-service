package au.com.medibank.tests.policies

import au.com.medibank.annotations.ApiGateway
import au.com.medibank.annotations.DelPHI
import au.com.medibank.annotations.Jira
import au.com.medibank.client.api.ApiGatewayClientFactory
import au.com.medibank.client.api.PoliciesApiGateway
import au.com.medibank.data.TestMember
import au.com.medibank.data.TestPolicy
import org.junit.BeforeClass
import org.junit.Ignore
import org.junit.Test

class PostRequestCard {

    String updateableMemberId
    static PoliciesApiGateway container;
    def noOfCards;
    def reason;

    @BeforeClass
    public static void setup() {
        container = ApiGatewayClientFactory.getPoliciesApiGateway(TestMember.hasMultiplePolicies)
    }

    // happy path
    @Test
    @Jira(stories = ['DSS-58'])
    @ApiGateway(POST = 'policies/:policyId/cardRequest')
    @DelPHI(wsdls = ['PolicyRequestCard'])
    public void post_card_request() {
        noOfCards = 1
        reason = 'LOST CARD'
        def response = container.postCardRequest(noOfCards, reason,
                TestPolicy.canRequestCard, 'test@test.com')
        assert response == 202, "Replacement card request failed (No of Cards = $noOfCards, reason = $reason)"
    }

    @Test
    @Ignore('Check not implemented in API')
    @Jira(stories = ['DSS-58'])
    @ApiGateway(POST = 'policies/:policyId/cardRequest')
    @DelPHI(wsdls = ['PolicyRequestCard'])
    public void post_card_request_too_many_cards() {
        noOfCards = 1000000
        reason = 'LOST CARD'
        def response = container.postCardRequest(noOfCards, reason,
                TestPolicy.canRequestCard, 'test@test.com')
        assert response == 401, "Should be challenged if try to order this many cards (No of Cards = $noOfCards, reason = $reason)"
    }

    @Test
    @Ignore('Check not implemented in API')
    @Jira(stories = ['DSS-58'])
    @ApiGateway(POST = 'policies/:policyId/cardRequest')
    @DelPHI(wsdls = ['PolicyRequestCard'])
    public void post_card_request_invalid_reason() {
        noOfCards = 1
        reason = 'I WANT TO BUY MORE ICE-CREAMS'
        def response = container.postCardRequest(noOfCards, reason,
                TestPolicy.canRequestCard, 'test@test.com'
        )
        assert response == 401, "Only the following reasons are allowed (reason given = '$reason')"
    }
}