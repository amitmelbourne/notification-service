/**
 * Copyright © 2010-2014 Nokia
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.medibank.digital;

import org.jsonschema2pojo.AbstractAnnotator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.JsonNode;

import com.sun.codemodel.JClass;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JAnnotationArrayMember;
import com.sun.codemodel.JAnnotationUse;

/**
 */
public class SubtypeAnnotator extends AbstractAnnotator {

	@Override
	public void propertyOrder(JDefinedClass clazz, JsonNode propertiesNode) {

		if (clazz.fullName().equals("com.medibank.digital.api.model.PaymentAccount")) {

			System.out.println(">>> Applying subtype annotations to "+clazz.fullName());
			clazz.annotate(JsonIgnoreProperties.class).param("ignoreUnknown",true);
	
			JAnnotationUse jsonTypeInfo = clazz.annotate(JsonTypeInfo.class);
			jsonTypeInfo.param("use", JsonTypeInfo.Id.NAME);
			jsonTypeInfo.param("include", JsonTypeInfo.As.EXTERNAL_PROPERTY);
			jsonTypeInfo.param("property", "accountType"); 
			JAnnotationUse jsonSubTypes = clazz.annotate(JsonSubTypes.class);
			JAnnotationArrayMember jsonSubTypesValues = jsonSubTypes.paramArray("value");
	
			JAnnotationUse jsonSubType = jsonSubTypesValues.annotate(JsonSubTypes.Type.class);
			JClass subClazz = clazz.owner().ref("com.medibank.digital.api.model.BankAccount");
			jsonSubType.param("value",subClazz);
			jsonSubType.param("name","Bank");
	
			jsonSubType = jsonSubTypesValues.annotate(JsonSubTypes.Type.class);
			subClazz = clazz.owner().ref("com.medibank.digital.api.model.CreditCardAccount");
			jsonSubType.param("value",subClazz);
			jsonSubType.param("name","CreditCard");

			jsonSubType = jsonSubTypesValues.annotate(JsonSubTypes.Type.class);
			subClazz = clazz.owner().ref("com.medibank.digital.api.model.ChequeAccount");
			jsonSubType.param("value",subClazz);
			jsonSubType.param("name","Cheque");			
	
			jsonSubType = jsonSubTypesValues.annotate(JsonSubTypes.Type.class);
			subClazz = clazz.owner().ref("com.medibank.digital.api.model.PayrollAccount");
			jsonSubType.param("value",subClazz);
			jsonSubType.param("name","Payroll");
		}
	}
}
