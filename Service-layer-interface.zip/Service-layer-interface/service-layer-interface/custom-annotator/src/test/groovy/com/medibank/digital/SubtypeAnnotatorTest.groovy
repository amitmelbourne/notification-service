package com.medibank.digital

import com.sun.codemodel.JAnnotationArrayMember
import com.sun.codemodel.JAnnotationUse
import com.sun.codemodel.JClass
import com.sun.codemodel.JCodeModel
import com.sun.codemodel.JDefinedClass
import com.sun.codemodel.JPackage
import spock.lang.Specification

/**
 * Created by m44184 on 4/08/2015.
 */
class SubtypeAnnotatorTest extends Specification {

    SubtypeAnnotator annotator = []

    def 'verify class is annotated'() {
        given: 'a class of type PaymentAccount'
        JCodeModel model = []
        JPackage jPackage = ['com.medibank.digital.api.model', model]
        JDefinedClass paymentAccountClass = [jPackage, 0, 'PaymentAccount', null]
        JAnnotationUse annotationUse = [paymentAccountClass]

        when: 'the annotator is invoked'
        annotator.propertyOrder(paymentAccountClass, null)

        then: 'the class is annotated'
        paymentAccountClass.annotations().size() == 3
    }
}
