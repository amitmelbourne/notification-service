import org.junit.Assert;
import org.junit.Test;

/**
 * Created by m44184 on 4/08/2015.
 */
public class DummyTest {

    @Test
    public void dummyTest() {
        Assert.assertTrue(true);
    }
}
