package au.com.medibank

import au.com.medibank.message.notification.esb.DeliveryType
import au.com.medibank.message.notification.esb.HeaderType;
import au.com.medibank.message.notification.esb.IdentifierType;
import au.com.medibank.message.notification.esb.SendIAMCredentialNotificationType
import com.amazonaws.services.sqs.AmazonSQS
import com.amazonaws.services.sqs.model.GetQueueAttributesRequest

import javax.xml.bind.JAXBContext;

public class SqsFacade {
    private final static String AEM_MESSAGE_ELEMENT = "Message";
    private final static String AEM_MESSAGE_URI = "http://www.medibank.com.au/data/IdentityNotificationMessage/1";
    private AmazonSQS sqs = null;
    String queueUrl = null;

    public SqsFacade(AmazonSQS sqs) {
        this.sqs = sqs;
    }

    public void list() {
        sqs = SqsClientFactory.getAmazonSQS();
        try {
            for (String url : sqs.listQueues().getQueueUrls()) {
                System.out.println("  QueueUrl: " + url);
                queueUrl = url;
            }
        } catch (Exception e) {
            System.out.println("error");
        }
    }

    public void sendNotification(String messageType, String deliverTo, String oldLogin="Old Login") {

        SendIAMCredentialNotificationType notification = new SendIAMCredentialNotificationType(
                header: new HeaderType(
                        auditID1: "bpId",
                        auditID2: deliverTo
                ),
                loginID: deliverTo,
                oldLoginID: oldLogin,
                businessPartnerID: "C1234",
                notificationType: messageType,
                token: "token",
                delivery: new DeliveryType(
                        emailAddress: deliverTo,
                        phoneNumber: "123412341234"

                ),
                additionalInfo: [
                        new IdentifierType(
                                key: "Key2",
                                value: "Value2"
                        ),
                ]
        )
        JAXBContext ctx = JAXBContext.newInstance(SendIAMCredentialNotificationType.class)
        String text = JaxbTransformer.marshal(SendIAMCredentialNotificationType.class, notification, AEM_MESSAGE_URI, AEM_MESSAGE_ELEMENT, ctx)
        println text
        sqs.sendMessage("dev01_test_message_queue", text);

    }

    public void getNotificationCount(String messageType, String deliverTo, String oldLogin="Old Login") {

        SendIAMCredentialNotificationType notification = new SendIAMCredentialNotificationType(
                header: new HeaderType(
                        auditID1: "bpId",
                        auditID2: deliverTo
                ),
                loginID: deliverTo,
                businessPartnerID: "C1234",
                notificationType: messageType,
                token: "token",
                delivery: new DeliveryType(
                        emailAddress: deliverTo,
                        phoneNumber: "123412341234"
                ),
                additionalInfo: [
                        new IdentifierType(
                                key: "OLD_LOGIN",
                                value: oldLogin
                        ),
                        new IdentifierType(
                                key: "Key2",
                                value: "Value2"
                        ),
                ]
        )
        JAXBContext ctx = JAXBContext.newInstance(SendIAMCredentialNotificationType.class)
        String text = JaxbTransformer.marshal(SendIAMCredentialNotificationType.class, notification, AEM_MESSAGE_URI, AEM_MESSAGE_ELEMENT, ctx)

        GetQueueAttributesRequest qar = new GetQueueAttributesRequest(sqs.listQueues().getQueueUrls().get(0));
        qar.setAttributeNames(Arrays.asList("ApproximateNumberOfMessages"));

        Map map = sqs.getQueueAttributes( qar ).getAttributes();

    }
}
