package au.com.medibank

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClient;

public class SqsClientFactory {

    public static final String PROXY_SERVER = "ausydisa02.au.imckesson.com"
    public static final int PROXY_PORT = 8080
    public static final String AWS_ACCESS_KEY = "AKIAICJETIWM5B7UCLSQ"
    public static final String  AWS_SECRET = "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"
    public static AmazonSQS getAmazonSQS() {
        ClientConfiguration clientConfiguration = new ClientConfiguration();
        clientConfiguration.setProxyHost(PROXY_SERVER);
        clientConfiguration.setProxyPort(PROXY_PORT);
        BasicAWSCredentials credentials = new BasicAWSCredentials(AWS_ACCESS_KEY, AWS_SECRET);
        AmazonSQS sqsLocal = new AmazonSQSClient(credentials, clientConfiguration);
        Region region = Region.getRegion(Regions.AP_SOUTHEAST_2);
        sqsLocal.setRegion(region);
        return sqsLocal;
    }
}
