package au.com.medibank;

import com.amazonaws.services.sqs.AmazonSQS;
import org.apache.commons.cli.*;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cli {

    private String[] args = null;
    private static final Logger log = Logger.getLogger(Cli.class.getName());

    private Options options = new Options();
    private Map<String, String> storiesToType;


    public Cli(String[] args) {
        storiesToType = new HashMap<String, String>();
        storiesToType.put("DSS-180", "FRONTLINE_REGISTER"); //no interaction ID
        storiesToType.put("DSS-233", "RESEND_ACTIVATION");
        storiesToType.put("DSS-???", "AUTO_REGISTER");

        storiesToType.put("DSS-122", "UPDATE_LOGIN");
        storiesToType.put("DSS-523", "UPDATE_LOGIN");

        this.args = args;
        options.addOption("h", "help", false, "Show Help");
        options.addOption("e", "email", true, "Email address to send to");
        options.addOption("l", "list", false, "List user stories");
        options.addOption("u", "userStory", true, "Associated User Story");
        options.addOption("o", "oldEmail", true, "Old Email");
    }

    public void parse() throws ParseException {
        CommandLineParser parser = new BasicParser();
        CommandLine cmd = null;
        try {
                    cmd = parser.parse(options, args);
                    if (cmd.hasOption("l")) {
                        listUserStories();
                        System.exit(0);
                    }
                    if (cmd.hasOption("h"))
                        help();
                    if (!cmd.hasOption("e") || !cmd.hasOption("u")) {
                        help();
            }
            else if(cmd.hasOption("o")){
                run(cmd.getOptionValue("e"), cmd.getOptionValue("u"), cmd.getOptionValue("o"));
            }
            else {
                run(cmd.getOptionValue("e"), cmd.getOptionValue("u"));
            }
        } catch (ParseException e) {
            log.log(Level.SEVERE, "Failed to parse command line properties", e);
            help();
        }
    }

    private void listUserStories() {
        StringBuilder sb =new StringBuilder();
        Iterator<String> iterator = storiesToType.keySet().iterator();
        while (iterator.hasNext()){
            String storyId = iterator.next();
            sb.append(storyId + ": " + storiesToType.get(storyId) + "\n");
        }
        log.log(Level.INFO, sb.toString());
    }

    private void run(String email, String userStory, String oldEmail){
        if (storiesToType.get(userStory) == null) {
            log.log(Level.SEVERE, "\nNo such user story " + userStory );
            System.exit(1);
        }
        AmazonSQS sqs = SqsClientFactory.getAmazonSQS();
        SqsFacade sqsFacade = new SqsFacade(sqs);
        sqsFacade.sendNotification(storiesToType.get(userStory), email, oldEmail);

    }

    private void run(String email, String userStory){
        if (storiesToType.get(userStory) == null) {
            log.log(Level.SEVERE, "\nNo such user story " + userStory );
            System.exit(1);
        }
        AmazonSQS sqs = SqsClientFactory.getAmazonSQS();
        SqsFacade sqsFacade = new SqsFacade(sqs);
        sqsFacade.sendNotification(storiesToType.get(userStory), email, "oldEmail@email.com");

    }

    private void help() {
        log.log(Level.INFO, "\nUsing cli argument" +
                "\n\tjava -jar <file.jar> -e=<email to send to> -u=<User story DSS-XYZ>" +
                "\n\tjava -jar <file.jar> -l Lists all user stories");
        System.exit(0);
    }

}
