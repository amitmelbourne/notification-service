package au.com.medibank;

import au.com.medibank.Cli;
import com.amazonaws.services.sqs.AmazonSQS;
import org.apache.commons.cli.ParseException;

public class Main {
    private static AmazonSQS sqs = null;

    public static void main(String[] args) throws ParseException {
        new Cli(args).parse();

//        sqs = SqsClientFactory.getAmazonSQS();
//        SqsFacade sqsFacade = new SqsFacade(sqs);
//        sqsFacade.list();
//        sqsFacade.sendNotification("FRONTLINE_REGISTER", "simon.collins@medibank.com.au"); //DSS-180 no interaction ID
//        sqsFacade.sendNotification("ONLINE_REGISTER", "simon.collins@medibank.com.au"); //DSS-233 has an interaction ID
//        sqsFacade.sendNotification("AUTO_REGISTER", "simon.collins@medibank.com.au");
//        sqsFacade.sendNotification("UPDATE_LOGIN", "manish.nigade@medibank.com.au", "simon.collins@medibank.com.au"); //DSS-122

        // need to base64 decode the token
    }
}
