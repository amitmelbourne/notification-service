package au.com.medibank

import javax.xml.bind.*;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class JaxbTransformer {

    public static <T> T unmarshal(Class<T> clazz, JAXBContext context, String s)
            throws JAXBException, XMLStreamException {
        Unmarshaller un = context.createUnmarshaller();
        XMLStreamReader reader = XMLInputFactory.newInstance().createXMLStreamReader(new StringReader(s));
        JAXBElement<T> element = un.unmarshal(reader, clazz);
        return element.getValue();
    }

    public static <T> String marshal(Class<T> clazz, T obj, String uri, String elementName, JAXBContext context)
            throws JAXBException {
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
        StringWriter sw = new StringWriter();
        marshaller.marshal(new JAXBElement<T>(new QName(uri, elementName), clazz, obj), sw);
        return sw.toString();
    }
}