ReadBP/SearcHBP Service
---------------------------------------------------------------------------

#### Tech Stack ####

* Java 8
* Spring Boot
* Spock test framework
* Code coverage module (JaCoCo, CheckStyle, FindBugs, PMD)
* Swagger 2 API Generation

    
---------------------------------------------------------------------------

#### Health Check ####
Spring actuator endpoints are available at `admin/info` and `admin/health`

    
---------------------------------------------------------------------------

#### Swagger API ####

Generated Swagger2 JSON schema can be found here:

* Schema: [Swagger2 JSON Schema](src/docs/json/generated/swagger2.json). 

Generated Swagger Markdown documentation can be found here:

* Overview: [overview.md](src/docs/markdown/generated/overview.md). 
* Definitions: [definitions.md](src/docs/markdown/generated/definitions.md). 
* Paths: [paths.md](src/docs/markdown/generated/paths.md). 

Generated AsciiDocs can be found here:

* Overview: [overview.adoc](src/docs/asciidoc/generated/overview.adoc). 
* Definitions: [definitions.adoc](src/docs/asciidoc/generated/definitions.adoc). 
* Paths: [paths.adoc](src/docs/asciidoc/generated/paths.adoc). 

     
---------------------------------------------------------------------------

#### RAML Generation ####
* Run `gradle integrationTest` to generate API documentation.
* Locate the JSON schema at `src/docs/json/generated/api.swagger2.json`.
* Upload this file to [https://apitransformer.com/](https://apitransformer.com/), and convert to RAML.

     
---------------------------------------------------------------------------

#### Running locally ####
This microservice works as a standalone application, Tomcat is not required.

    gradle bootRun
    
Once the service has started, you should be able to access it at 
`http://localhost:8080/`

Useful links:

* Swagger JSON API definition:      `http://localhost:8080/v2/api-docs`.  
* Swagger graphical API definition: `http://localhost:8080/swagger-ui.html`.  
* Spring Actuator health endpoint:  `http://localhost:8080/admin/health`. 

    
---------------------------------------------------------------------------

#### Running locally with Docker ####
Build the container by running the following command from the project 
root directory. The build argument `PROFILE` will set the `ENVIRONMENT` 
and `spring.profile.active` environment variables.

    docker build --build-arg PROFILE=local -t readbp-service:local .
    
Start the container 
(optionally change the exposed port number, e.g. `-p=80:8080`):

    docker run -p=8080:8080 --name=readbp-service -d readbp-service:local

You can verify the container is running with `docker ps`. You should now 
be able to access the service at your Docker machine's IP address and the
port number you specified in the `run` command.
e.g. `192.168.99.100:8080` or `localhost:8080` depending on your setup.

Stop and remove the container:

    docker stop readbp-service && docker rm readbp-service

