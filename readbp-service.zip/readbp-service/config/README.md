# Code analysis common configuration 

## Tech Stack
* Checkstyle
* Findbugs
* PMD
* JaCoCo

## Adding the folder into a repository
`git subtree add --prefix config ssh://git@stash.aws.medibank.local:7999/dig/code-analysis-config.git master --squash`

### Update from the central config repository
`git subtree pull --prefix config ssh://git@stash.aws.medibank.local:7999/dig/code-analysis-config.git master --squash`