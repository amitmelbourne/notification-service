#!/bin/sh

set -x
set -e

if [ -z "${ENVIRONMENT}" ]; then
    echo "ENVIRONMENT variable not set"
    exit 1
fi

java -javaagent:/medibank/newrelic/newrelic.jar \
     -Dnewrelic.environment=$ENVIRONMENT \
     -Dspring.profiles.active=$ENVIRONMENT \
     -jar /medibank/service/readbp-service.jar
