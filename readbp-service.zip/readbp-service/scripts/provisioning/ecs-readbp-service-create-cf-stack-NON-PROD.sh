
if [[ -z "$ENVIRONMENT" ]] || [[ -z "$DOCKER_IMAGE_VERSION" ]] || [[ -z "$STACK_NAME" ]]; then
   echo "One or more ENV variable is unset or set to the empty string"
   echo "STACK_NAME: $STACK_NAME"
   echo "ENVIRONMENT: $ENVIRONMENT"
   echo "DOCKER_IMAGE_vERSION: $DOCKER_IMAGE_VERSION"
   exit 1
fi

sed -i -e "s;%DOCKER_IMAGE_VERSION%;$DOCKER_IMAGE_VERSION;g" -e "s;%ENVIRONMENT%;$ENVIRONMENT;g" params/ecs-readbp-service-nonprod.json

cat params/ecs-readbp-service-nonprod.json

aws cloudformation create-stack --stack-name $STACK_NAME \
 --template-body file://ecs-readbp-service.yaml \
 --region ap-southeast-2 \
 --parameters file://params/ecs-readbp-service-nonprod.json \
 --capabilities CAPABILITY_IAM 