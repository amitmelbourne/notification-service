#!/bin/bash

set -e
set -x

aws configure set default.region ap-southeast-2

ENV=${ENVIRONMENT}
STACK=${ENVIRONMENT_STACK}
IMAGE_VERSION=${DOCKER_IMAGE_VERSION}

if [ -z "${IMAGE_VERSION}" ]; then
    echo "IMAGE_VERSION is unset or set to the empty string"
    exit 1
fi

TIMEOUT=${DEPLOY_SUCCESS_TIMEOUT:-600}
CLUSTER_NAME=`aws cloudformation describe-stacks --stack-name $STACK --query 'Stacks[].Outputs[]' --output text | grep EcsClusterName | awk '{ print $2 }'`
SERVICE_NAME=`aws cloudformation describe-stacks --stack-name $STACK --query 'Stacks[].Outputs[]' --output text | grep EcsServiceName | awk '{ print $2 }'`
TASK_DEFINITION_ARN=`aws cloudformation describe-stacks --stack-name $STACK --query 'Stacks[].Outputs[]' --output text | grep taskdefinition | awk '{ print $2 }'`
TASK_FAMILY=`aws ecs describe-task-definition --task-definition $TASK_DEFINITION_ARN --output text --query 'taskDefinition.family'`

# Create a new task definition for this build

sed -e "s;%IMAGE_VERSION%;$IMAGE_VERSION;g" -e "s;%ENVIRONMENT%;$ENV;g" -e "s;%ENVIRONMENT_STACK%;$STACK;g" scripts/deploy/task-definition.json > deploy-task-definition-$IMAGE_VERSION.json

# Register new task definition return new new arn
NEW_TASK_DEFINITION=`aws ecs register-task-definition --family $TASK_FAMILY --cli-input-json file://deploy-task-definition-$IMAGE_VERSION.json | jq -r .taskDefinition.taskDefinitionArn`

if [ -z "${NEW_TASK_DEFINITION}" ]; then
    echo "NEW_TASK_DEFINITION registration failed."
    exit 1
fi

# Update the service with the new task definition
TASK_REVISION=`aws ecs describe-task-definition --task-definition $TASK_FAMILY | egrep "revision" | tr "/" " " | awk '{print $2}' | sed 's/"$//'`
aws ecs update-service --cluster $CLUSTER_NAME --service ${SERVICE_NAME} --task-definition ${TASK_FAMILY}:${TASK_REVISION}

DESIRED_TASK_COUNT=`aws ecs describe-services --cluster ${CLUSTER_NAME} --services ${SERVICE_NAME} | jq '.services[].desiredCount'`

if [ -z "$DESIRED_TASK_COUNT" ]; then
    echo "Desired count is empty"
    exit 1
fi

### See if new version of the task definition is running on service
###################################################################
every=10
i=0
while [ $i -lt $TIMEOUT ]
do
    # Query the list of running tasks for service, and
    # Check count of the new version of the task definition
    RUNNING_COUNT=$(aws ecs list-tasks --cluster $CLUSTER_NAME  --service-name $SERVICE_NAME --desired-status RUNNING \
                     | jq -r '.taskArns[]' \
                     | xargs -I{} aws ecs describe-tasks --cluster $CLUSTER_NAME --tasks {} \
                     | jq ".tasks[]| if .taskDefinitionArn == \"$NEW_TASK_DEFINITION\" then . else empty end|.lastStatus" \
                     | grep -c "RUNNING" || : )

    if [ "$RUNNING_COUNT" == "$DESIRED_TASK_COUNT" ]; then
        echo "Service updated successfully, new task definition running.";
        exit 0
    fi

    sleep $every
    i=$(( $i + $every ))
done

# Timed out
echo "ERROR: New task definition not running within $TIMEOUT seconds"
exit 1
