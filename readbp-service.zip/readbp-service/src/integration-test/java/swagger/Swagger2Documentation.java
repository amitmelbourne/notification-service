package swagger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.integration.loyalty.Application;
import io.github.robwin.markup.builder.MarkupLanguage;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import springfox.documentation.staticdocs.Swagger2MarkupResultHandler;

import java.io.File;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@WebAppConfiguration
@ContextConfiguration(classes = Application.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class Swagger2Documentation {

    private static final String SWAGGER2_DOCS_PATH     = "/v2/api-docs";
    private static final String MARKDOWN_OUTPUT_PATH   = "src/docs/markdown/generated";
    private static final String ASCIIDOC_OUTPUT_PATH   = "src/docs/asciidoc/generated";
    private static final String JSON_OUTPUT_PATH_SRC   = "src/docs/json/generated/api.swagger2.json";
    private static final String JSON_OUTPUT_PATH_BUILD = "build/docs/api/product-service.swagger2.json";

    @Autowired
    private WebApplicationContext context;
    private MockMvc mockMvc;

    @Before
    public void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.context).build();
    }

    @Test
    public void outputSwaggerJson() throws Exception {
        MvcResult result = this.mockMvc.perform(get(SWAGGER2_DOCS_PATH)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        ObjectMapper mapper = new ObjectMapper();
        Object json   = mapper.readValue(result.getResponse().getContentAsString(), Object.class);
        String output = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);

        /* Output to /src directory for repository README links. */
        FileUtils.writeStringToFile(new File(JSON_OUTPUT_PATH_SRC), output);

        /* Output to /build directory for Bamboo to auto generate with every build. */
        FileUtils.writeStringToFile(new File(JSON_OUTPUT_PATH_BUILD), output);
    }

    @Test
    public void convertSwaggerToMarkdown() throws Exception {
        this.mockMvc.perform(get(SWAGGER2_DOCS_PATH).accept(MediaType.APPLICATION_JSON))
                .andDo(Swagger2MarkupResultHandler.outputDirectory(MARKDOWN_OUTPUT_PATH)
                        .withMarkupLanguage(MarkupLanguage.MARKDOWN).build())
                .andExpect(status().isOk());
    }

    @Test
    public void convertSwaggerToAsciiDoc() throws Exception {
        this.mockMvc.perform(get(SWAGGER2_DOCS_PATH).accept(MediaType.APPLICATION_JSON))
                .andDo(Swagger2MarkupResultHandler.outputDirectory(ASCIIDOC_OUTPUT_PATH).build())
                .andExpect(status().isOk());
    }

}
