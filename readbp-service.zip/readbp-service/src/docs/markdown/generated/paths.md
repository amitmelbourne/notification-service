## Paths
### Reads a Business Partner by ID
```
OPTIONS /api/loyalty/v1/businessPartnerHW
```

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|HeaderParameter|RequestID|RequestID|false|string||
|QueryParameter|bpid|bpid|true|string||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|Success|ReadBPResponse|
|204|No Content|No Content|
|400|Failure on bad request|Error|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|


#### Consumes

* application/json

#### Produces

* application/json

#### Tags

* read-bp-controller-impl

### Reads a Business Partner by ID
```
GET /api/loyalty/v1/businessPartnerHW
```

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|HeaderParameter|RequestID|RequestID|false|string||
|QueryParameter|bpid|bpid|true|string||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|Success|ReadBPResponse|
|400|Failure on bad request|Error|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* application/json

#### Tags

* read-bp-controller-impl

### Participant Loyalty Point Burn Information
```
OPTIONS /api/loyalty/v1/businessPartnerHW/{bpid}/burnIndicator
```

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|PathParameter|bpid|bpid|true|string||
|HeaderParameter|RequestID|RequestID|false|string||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|Success|GetBPFinancialStatusBurnResponse|
|204|No Content|No Content|
|400|Failure on bad request|Error|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|


#### Consumes

* application/json

#### Produces

* application/json

#### Tags

* get-bp-financial-status-controller-impl

### Participant Loyalty Point Burn Information
```
GET /api/loyalty/v1/businessPartnerHW/{bpid}/burnIndicator
```

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|PathParameter|bpid|bpid|true|string||
|HeaderParameter|RequestID|RequestID|false|string||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|Success|GetBPFinancialStatusBurnResponse|
|400|Failure on bad request|Error|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* application/json

#### Tags

* get-bp-financial-status-controller-impl

### Participant Loyalty Point Earn Information
```
OPTIONS /api/loyalty/v1/businessPartnerHW/{bpid}/earnIndicator
```

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|PathParameter|bpid|bpid|true|string||
|HeaderParameter|RequestID|RequestID|false|string||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|Success|GetBPFinancialStatusEarnResponse|
|204|No Content|No Content|
|400|Failure on bad request|Error|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|


#### Consumes

* application/json

#### Produces

* application/json

#### Tags

* get-bp-financial-status-controller-impl

### Participant Loyalty Point Earn Information
```
GET /api/loyalty/v1/businessPartnerHW/{bpid}/earnIndicator
```

#### Parameters
|Type|Name|Description|Required|Schema|Default|
|----|----|----|----|----|----|
|PathParameter|bpid|bpid|true|string||
|HeaderParameter|RequestID|RequestID|false|string||


#### Responses
|HTTP Code|Description|Schema|
|----|----|----|
|200|Success|GetBPFinancialStatusEarnResponse|
|400|Failure on bad request|Error|
|401|Unauthorized|No Content|
|403|Forbidden|No Content|
|404|Not Found|No Content|


#### Consumes

* application/json

#### Produces

* application/json

#### Tags

* get-bp-financial-status-controller-impl

