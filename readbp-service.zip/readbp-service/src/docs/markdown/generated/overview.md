# Medibank Digital Integration Services - ReadBP Service

## Overview
Medibank Loyalty API - ReadBP Service

### Version information
Version: 1.0.0-SNAPSHOT

### URI scheme
Host: localhost
BasePath: /

### Tags

* get-bp-financial-status-controller-impl: Get BP Financial Status Controller Impl
* read-bp-controller-impl: Read BP Controller Impl


