## Definitions
### Error

Generic Error Object

|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|errorCode||false|string||
|errorDescription||false|string||


### GetBPFinancialStatusBurnResponse

Get BP Financial Status Burn Response object

|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|BPID||false|string||
|BurnIndicator||false|boolean||


### GetBPFinancialStatusEarnResponse

Get BP Financial Status Earn Response object

|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|BPID||false|string||
|BaseHWEarnIndicator||false|boolean||
|HICAPSEarnIndicator||false|boolean||
|PartnerEarnIndicator||false|boolean||


### HWUser

SAP HWUser object

|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|ActiveIndicator||false|string||
|ConsentApprovalDateTime||false|string||
|CreationDateTime||false|string||
|ID||false|string||


### ReadBPResponse

ReadBP Response object

|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|BirthDate||false|string||
|ChangeStateId||false|string||
|EmailURI||false|string||
|FamilyName||false|string||
|GivenName||false|string||
|HWUser||false|HWUser||
|ID||false|string||
|PolicyAssignedIndicator||false|string||
|Telephone||false|Telephone||
|UserRegisteredIndicator||false|string||


### Telephone

SAP Telephone object

|Name|Description|Required|Schema|Default|
|----|----|----|----|----|
|CountryCode||false|string||
|NumberText||false|string||


