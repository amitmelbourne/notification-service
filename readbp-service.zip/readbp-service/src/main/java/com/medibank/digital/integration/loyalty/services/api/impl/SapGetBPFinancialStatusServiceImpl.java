package com.medibank.digital.integration.loyalty.services.api.impl;

import com.medibank.digital.integration.loyalty.config.LogExecutionTime;
import com.medibank.digital.integration.loyalty.services.api.SapErrorHandling;
import com.medibank.digital.integration.loyalty.services.api.SapGetBPFinancialStatusService;
import com.medibank.digital.integration.loyalty.services.api.model.SapGetBPFinancialStatusResponseWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import java.net.URI;

@Service
public class SapGetBPFinancialStatusServiceImpl implements SapGetBPFinancialStatusService {


    private static final Logger LOGGER = LoggerFactory.getLogger(SapGetBPFinancialStatusServiceImpl.class);

    @Value("${medibank.sap.getfinancialstatus.uri}")
    private String getFinancialStatusUri;

    @Autowired()
    @Qualifier("authRestTemplate")
    RestTemplate restTemplate;

    @Autowired
    SapErrorHandling sapErrorHandling;

    @Override
    @LogExecutionTime
    public ResponseEntity<?> getFinancialStatus(String bpid, String requestId) {
        try {
            LOGGER.info("SAP Get Financial Status called: " + bpid);

            URI uri = new UriTemplate(getFinancialStatusUri).expand(bpid);

            RequestEntity request = RequestEntity.get(uri)
                    .accept(MediaType.APPLICATION_JSON)
                    .header("RequestID", requestId)
                    .build();

            LOGGER.info("Request Headers: " + request.getHeaders());

            ResponseEntity<SapGetBPFinancialStatusResponseWrapper> response = restTemplate.exchange(request, SapGetBPFinancialStatusResponseWrapper.class);

            LOGGER.info("SAP Get Financial Status response: " + response.toString());


            if (response.getStatusCode().is2xxSuccessful()) {
                return response;
            } else {
                return new ResponseEntity<>(response.getStatusCode());
            }
        } catch(HttpClientErrorException clientEx) {
            LOGGER.error("HttpClientError SAP:: Get Policy Number :: {} ", clientEx.getResponseBodyAsString());
            return sapErrorHandling.handleErrorResponse(clientEx, clientEx.getStatusCode());

        } catch(HttpServerErrorException serverEx) {
            LOGGER.error("HttpServerError SAP:: Get Policy Number :: {} ", serverEx.getResponseBodyAsString());
            return sapErrorHandling.handleErrorResponse(serverEx, serverEx.getStatusCode());
        }
    }

}
