package com.medibank.digital.integration.loyalty.interceptor;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import com.medibank.digital.integration.loyalty.config.Constants;
import com.medibank.digital.integration.loyalty.services.api.SapCSRFTokenService;

/**
 * Adds the X-CSRF-Token header to all outgoing requests.
 * <p>
 * This is required for all SAP calls, at the moment we will
 * fetch a new token each time (does have a long TTL so we may need
 * to evaluate how this is used).
 * 
 * @author 920477
 *
 */
@Component
public class CSRFTokenInterceptor implements ClientHttpRequestInterceptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(CSRFTokenInterceptor.class);
	
	@Autowired
	private SapCSRFTokenService csrfService;

	/*
	 * Not the greatest, need to change.
	 * <p>
	 * We need to send the cookies across along with the CSRF Token, at the moment the call
	 * to create interaction will send back updated cookies, however these are not valid for the
	 * CSRF token, hence resulting in 403's, so for now just cache them here.
	 */
	private static CopyOnWriteArrayList<String> csrfHeaders = new CopyOnWriteArrayList<String>();


	/**
	 * Calls the SAP CSRF Token Request service and adds the returned CSRF token to the
	 * original request headers.
	 */
	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
		HttpHeaders headers = request.getHeaders();

		ResponseEntity<String> tokenResponse = csrfService.requestToken();
		
		if((tokenResponse != null) && (HttpStatus.OK.equals(tokenResponse.getStatusCode())) && 
				tokenResponse.getHeaders().containsKey(Constants.X_CSRF_TOKEN_HEADER)) {
			
			LOGGER.info("Adding CSRF Token to request.");
					
			headers.add(Constants.X_CSRF_TOKEN_HEADER, 
					tokenResponse.getHeaders().get(Constants.X_CSRF_TOKEN_HEADER).get(0));
			
			checkCookies(tokenResponse.getHeaders());
			
			for(String cookieValue : csrfHeaders) {
				headers.add(HttpHeaders.COOKIE, cookieValue);
			}

		} else {
			LOGGER.info("Unable to add CSRF Token to request, token not returned from CSRF Token Service.");
		}
		
        return execution.execute(request, body);
	}
	
	/**
	 * Checks if we have any set-cookie headers, if so will call to
	 * update the currently cached list.
	 * 
	 * @param tokenHeaders HttpHeaders returned from the token service.
	 */
	private void checkCookies(HttpHeaders tokenHeaders) {
		if(tokenHeaders.get(HttpHeaders.SET_COOKIE) != null) {
			setCachedHeaders(tokenHeaders.get(HttpHeaders.SET_COOKIE));
		}
	}
	
	/**
	 * Updates the cookies that we have cached.
	 * 
	 * @param newHeaders list of cookies from the returned set-cookie.
	 */
	private synchronized void setCachedHeaders(List<String> newHeaders) {
		csrfHeaders.clear();
		csrfHeaders.addAll(newHeaders);
	}
}
