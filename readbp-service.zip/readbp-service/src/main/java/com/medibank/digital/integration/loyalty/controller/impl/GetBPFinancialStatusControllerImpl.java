package com.medibank.digital.integration.loyalty.controller.impl;

import com.medibank.digital.integration.loyalty.config.Constants;
import com.medibank.digital.integration.loyalty.config.Helper;
import com.medibank.digital.integration.loyalty.config.LogExecutionTime;
import com.medibank.digital.integration.loyalty.controller.GetBPFinancialStatusController;
import com.medibank.digital.integration.loyalty.model.DigitalError;
import com.medibank.digital.integration.loyalty.model.GetBPFinancialStatusBurnResponse;
import com.medibank.digital.integration.loyalty.model.GetBPFinancialStatusEarnResponse;
import com.medibank.digital.integration.loyalty.services.api.SapGetBPFinancialStatusService;
import com.medibank.digital.integration.loyalty.services.api.model.SapGetBPFinancialStatusResponseWrapper;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

@RestController
public class GetBPFinancialStatusControllerImpl implements GetBPFinancialStatusController {

    private final static Logger LOGGER = LoggerFactory.getLogger(GetBPFinancialStatusControllerImpl.class);
    @Autowired
    SapGetBPFinancialStatusService sapGetBPFinancialStatusService;

    @Override
    @ApiOperation(value = "Participant Loyalty Point Earn Information")
    @RequestMapping(path = Constants.V1.BusinessPartnerHW.EARN_INDICATOR,
            method = {RequestMethod.GET, RequestMethod.OPTIONS},
            produces = APPLICATION_JSON_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = GetBPFinancialStatusEarnResponse.class),
            @ApiResponse(code = 400, message = "Failure on bad request", response = DigitalError.class)}
    )
    @LogExecutionTime
    public ResponseEntity<?> earnIndicator(@PathVariable(value = "bpid") String bpid,
                                           @RequestHeader(value = "RequestID", required = false) String requestId) {
//        GetBPFinancialStatusEarnResponse r = new GetBPFinancialStatusEarnResponse();
//        r.setBpId(memberID);

        try {
            LOGGER.info("Financial Status(Earn Indicator) called: with bpid " + bpid);
            if(!Helper.isValid(requestId)){
                requestId = Helper.get32BitUUID();
            } else if(requestId.length() > 32){
                requestId = Helper.trimRequestId(requestId);
            }

            LOGGER.info("EarnIndicator RequestID : {} " , requestId);

            ResponseEntity<?> sapResponse = sapGetBPFinancialStatusService.getFinancialStatus(bpid, requestId);
            if(sapResponse.getStatusCode().is2xxSuccessful()) {
                SapGetBPFinancialStatusResponseWrapper sapResBody = (SapGetBPFinancialStatusResponseWrapper) sapResponse.getBody();
                GetBPFinancialStatusEarnResponse response = new GetBPFinancialStatusEarnResponse();
                BeanUtils.copyProperties(response, sapResBody.getD());

                response.setBpId(sapResBody.getD().getID());

                LOGGER.info("Response: " + response.toString());
                return new ResponseEntity<>(response, sapResponse.getStatusCode());
            }

            return sapResponse;
        } catch(Exception ex) {
            LOGGER.error("Error whilst handling  Financial Status(Earn).", ex);

            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    @Override
    @ApiOperation(value = "Participant Loyalty Point Burn Information")
    @RequestMapping(path = Constants.V1.BusinessPartnerHW.BURN_INDICATOR,
            method = {RequestMethod.GET, RequestMethod.OPTIONS},
            produces = APPLICATION_JSON_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = GetBPFinancialStatusBurnResponse.class),
            @ApiResponse(code = 400, message = "Failure on bad request", response = DigitalError.class)}
    )
    @LogExecutionTime
    public ResponseEntity<?> burnIndicator(@PathVariable(value = "bpid") String bpid,
                                           @RequestHeader(value = "RequestID", required = false) String requestId) {

//        GetBPFinancialStatusBurnResponse r= new GetBPFinancialStatusBurnResponse();
//        r.setBpId(memberID);

        try {
            LOGGER.info("Financial Status(Burn Indicator) called: with bpid " + bpid);
            if(!Helper.isValid(requestId)){
                requestId = Helper.get32BitUUID();
            } else if(requestId.length() > 32){
                requestId = Helper.trimRequestId(requestId);
            }

            LOGGER.info("BurnIndicator RequestID : {} " , requestId);

            ResponseEntity<?> sapResponse = sapGetBPFinancialStatusService.getFinancialStatus(bpid, requestId);
            if(sapResponse.getStatusCode().is2xxSuccessful()) {
                SapGetBPFinancialStatusResponseWrapper sapResBody = (SapGetBPFinancialStatusResponseWrapper) sapResponse.getBody();
                GetBPFinancialStatusBurnResponse response = new GetBPFinancialStatusBurnResponse();
                BeanUtils.copyProperties(response, sapResBody.getD());

                response.setBpId(sapResBody.getD().getID());
                LOGGER.info("Response: " + response.toString());
                return new ResponseEntity<>(response, sapResponse.getStatusCode());
            }

            return sapResponse;
        } catch(Exception ex) {
            LOGGER.error("Error whilst handling Financial Status(Burn).", ex);

            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
