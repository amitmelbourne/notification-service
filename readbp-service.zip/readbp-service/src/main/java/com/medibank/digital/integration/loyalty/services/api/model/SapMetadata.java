package com.medibank.digital.integration.loyalty.services.api.model;

import java.util.Objects;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

/**
 * SAPMetadata
 */
@Validated
public class SapMetadata   {
  @JsonProperty("id")
  private String id = null;

  @JsonProperty("uri")
  private String uri = null;

  @JsonProperty("type")
  private String type = null;

  @JsonProperty("etag")
  private String etag = null;

  
  public SapMetadata() {
	  super();
  }
  
  public SapMetadata(String id, String uri, String type, String etag) {
    super();

    this.id = id;
    this.uri = uri;
    this.type = type;
    this.etag = etag;
  }
  
  public SapMetadata id(String id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(value = "")


  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public SapMetadata uri(String uri) {
    this.uri = uri;
    return this;
  }

  /**
   * Get uri
   * @return uri
  **/
  @ApiModelProperty(value = "")


  public String getUri() {
    return uri;
  }

  public void setUri(String uri) {
    this.uri = uri;
  }

  public SapMetadata type(String type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
  **/
  @ApiModelProperty(value = "")


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }


    public SapMetadata etag(String etag) {
        this.etag = etag;
        return this;
    }

    /**
     * Get etag
     * @return etag
     **/
    @ApiModelProperty(value = "")
    public String getETag() {
        return etag;
    }

    public void setETag(String etag) {
        this.etag = etag;
    }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SapMetadata saPMetadata = (SapMetadata) o;
    return Objects.equals(this.id, saPMetadata.id) &&
        Objects.equals(this.uri, saPMetadata.uri) &&
        Objects.equals(this.etag, saPMetadata.etag) &&
        Objects.equals(this.type, saPMetadata.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, uri, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SAPMetadata {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    uri: ").append(toIndentedString(uri)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    etag: ").append(toIndentedString(etag)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

