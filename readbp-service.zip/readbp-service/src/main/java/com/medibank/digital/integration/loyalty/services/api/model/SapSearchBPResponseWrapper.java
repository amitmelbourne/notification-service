package com.medibank.digital.integration.loyalty.services.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.util.Objects;

@ApiModel(description = "SAP SearchBP response object")
@Validated

public class SapSearchBPResponseWrapper {
  @JsonProperty("d")
  private SapSearchBPResponse d = null;

  public SapSearchBPResponseWrapper d(SapSearchBPResponse d) {
    this.d = d;
    return this;
  }

  /**
   * Get d
   * @return d
  **/
  @ApiModelProperty(value = "")

  @Valid

  public SapSearchBPResponse getD() {
    return d;
  }

  public void setD(SapSearchBPResponse d) {
    this.d = d;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SapSearchBPResponseWrapper saPreadbpRequestWrapper = (SapSearchBPResponseWrapper) o;
    return Objects.equals(this.d, saPreadbpRequestWrapper.d);
  }

  @Override
  public int hashCode() {
    return Objects.hash(d);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SapSearchBPResponseWrapper {\n");

    sb.append("    d: ").append(toIndentedString(d)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

