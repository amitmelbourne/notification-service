package com.medibank.digital.integration.loyalty.controller;

import com.medibank.digital.integration.loyalty.model.GetBPFinancialStatusBurnResponse;
import com.medibank.digital.integration.loyalty.model.GetBPFinancialStatusEarnResponse;
import org.springframework.http.ResponseEntity;

/**
 * ReadBP Controller
 * <p>
 * Allow Business Partner details to be read and searched
 *
 * @author 921348
 *
 */
public interface GetBPFinancialStatusController {

    /**
     * Reads Financial status (Earn) of a specific BP based on bpid (MemberId)
     * <P>
     * If successful will return a status code of 200 and the response
     * will contain the Participant Earn Information.
     *
     * @param bpid
     *
     * @return GetBPFinancialStatusEarnResponse
     */
    ResponseEntity<?> earnIndicator(String bpid, String requestId);

    /**
     * Reads Financial status (Burn) of a specific BP based on bpid (MemberId)
     * <P>
     * If successful will return a status code of 200 and the response
     * will contain the Participant Burn Information.
     *
     * @param bpid
     *
     * @return GetBPFinancialStatusBurnResponse
     */
    ResponseEntity<?> burnIndicator(String bpid, String requestId);
}
