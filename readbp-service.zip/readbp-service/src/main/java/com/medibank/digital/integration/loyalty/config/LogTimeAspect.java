package com.medibank.digital.integration.loyalty.config;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LogTimeAspect {

    private final static Logger LOGGER = LoggerFactory.getLogger(LogTimeAspect.class);

    @Around("@annotation(LogExecutionTime)")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
        final long start = System.currentTimeMillis();

        final Object proceed = joinPoint.proceed();

        final long executionTime = System.currentTimeMillis() - start;
//        LOGGER.info(" Name : {}" , joinPoint.getSignature().getName());
//        LOGGER.info(" Short String  : {}" , joinPoint.getSignature().toShortString());
//        LOGGER.info(" Dec Type Name : {}" , joinPoint.getSignature().getDeclaringTypeName());

        LOGGER.info("{} executed in {} ms." , joinPoint.getSignature().toShortString(), executionTime);

        return proceed;
    }

}
