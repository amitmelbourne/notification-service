package com.medibank.digital.integration.loyalty.services.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.util.Collection;
import java.util.Objects;

/**
 * SAP readbp response object
 */
@ApiModel(description = "SAP readbp response object")
@Validated

public class SapSearchBPResponse {
  @JsonProperty("results")
  private Collection<SapReadBPResponse> results;

  public SapSearchBPResponse results(Collection<SapReadBPResponse> results) {
    this.results = results;
    return this;
  }

  /**
   * Get metadata
   * @return metadata
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Collection<SapReadBPResponse> getResults() {
    return results;
  }

  public void setResults(Collection<SapReadBPResponse> results) {
    this.results = results;
  }


  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SapSearchBPResponse saPreadbpRequest = (SapSearchBPResponse) o;
    return Objects.equals(this.results, saPreadbpRequest.results);
  }

  @Override
  public int hashCode() {
    return Objects.hash(results);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SAPSearchBPResponse {\n");
    sb.append("    results: ").append(toIndentedString(results)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

