package com.medibank.digital.integration.loyalty.services.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;

@ApiModel(description = "SAP HWUser object")
public class HWUser {

    @JsonProperty("CreationDateTime")
    private String creationDateTime;
    @JsonProperty("ID")
    private String ID;
    @JsonProperty("ConsentApprovalDateTime")
    private String consentApprovalDateTime;
    @JsonProperty("ActiveIndicator")
    private String activeIndicator;

//    public String getCreationDateTime() {
//        return creationDateTime;
//    }
//
//    public void setCreationDateTime(String creationDateTime) {
//        this.creationDateTime = creationDateTime;
//    }
//
//    public String getID() {
//        return ID;
//    }
//
//    public void setID(String ID) {
//        this.ID = ID;
//    }
//
//    public String getConsentApprovalDateTime() {
//        return consentApprovalDateTime;
//    }
//
//    public void setConsentApprovalDateTime(String consentApprovalDateTime) {
//        this.consentApprovalDateTime = consentApprovalDateTime;
//    }
//
//    public String getActiveIndicator() {
//        return activeIndicator;
//    }
//
//    public void setActiveIndicator(String activeIndicator) {
//        this.activeIndicator = activeIndicator;
//    }

    public HWUser ID(String ID) {
        this.ID = ID;
        return this;
    }

    public HWUser creationDateTime(String creationDateTime) {
        this.creationDateTime = creationDateTime;
        return this;
    }

    public HWUser consentApprovalDateTime(String consentApprovalDateTime) {
        this.consentApprovalDateTime = consentApprovalDateTime;
        return this;
    }

    public HWUser activeIndicator(String activeIndicator) {
        this.activeIndicator = activeIndicator;
        return this;
    }




    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class HWUser {\n");

        sb.append("    ID: ").append(toIndentedString(ID)).append("\n");
        sb.append("    CreationDateTime: ").append(toIndentedString(creationDateTime)).append("\n");
        sb.append("    ConsentApprovalDateTime: ").append(toIndentedString(consentApprovalDateTime)).append("\n");
        sb.append("    ActiveIndicator: ").append(toIndentedString(activeIndicator)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
