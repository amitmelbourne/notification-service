package com.medibank.digital.integration.loyalty.services.api;

import com.medibank.digital.integration.loyalty.services.api.model.SapGetBPFinancialStatusResponseWrapper;
import org.springframework.http.ResponseEntity;

public interface SapGetBPFinancialStatusService {

    /**
     * Reads financial status form SAP
     * <p>
     *
     *
     * @param bpid The BPID(memberId) of the BP to get financial status
     *
     * @return SapGetBPFinancialStatusResponseWrapper response from SAP.
     */
    public ResponseEntity<?> getFinancialStatus(String bpid, String requestId);
}
