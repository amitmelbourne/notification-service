package com.medibank.digital.integration.loyalty.services.api;

import com.medibank.digital.integration.loyalty.services.api.model.SapSearchBPResponseWrapper;
import org.springframework.http.ResponseEntity;

import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponseWrapper;


/**
 * Service wrapper for the SAP readbp endpoint.
 * <p>
 * For now we'll keep this simple and just have it return the ResponseEntity from
 * the SAP endpoint, any HttpClientErrorException error will be wrapped and returned.
 * 
 * @author 920477
 *
 */
public interface SapReadBPService {

	/**
	 * Reads a BP form SAP
	 * <p>
	 *
	 * 
	 * @param bpid The BPID of the BP to read
	 * 
	 * @return SapReadBPResponseWrapper response from SAP, only ID field is relevant.
	 */
	public ResponseEntity<?> readbp(String bpid, String requestId);

	/**
	 * Searches for a BP based on email address
	 * <p>
	 *
	 *
	 * @param email The email address to search for related BPs
	 *
	 * @return SapReadBPResponseWrapper response from SAP.
	 */
	public ResponseEntity<?> searchbp(String email, String requestId);
}
