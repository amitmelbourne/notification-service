package com.medibank.digital.integration.loyalty.controller;


import com.medibank.digital.integration.loyalty.exceptions.ExceptionDetails;
import com.medibank.digital.integration.loyalty.exceptions.InvalidDataException;
import com.medibank.digital.integration.loyalty.exceptions.InvalidInputException;
import com.medibank.digital.integration.loyalty.exceptions.NotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.UUID;

@RestControllerAdvice
public class GlobalExceptionHandling {
    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandling.class);

    @ExceptionHandler({InvalidDataException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ExceptionDetails handleInvalidDataException(InvalidDataException e) {
        LOGGER.error(e.getMessage(), e);
        return new ExceptionDetails("1", e.getMessage());
    }

    @ExceptionHandler({InvalidInputException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ExceptionDetails handleInvalidInputException(InvalidInputException e) {
        LOGGER.error(e.getMessage(), e);
        return new ExceptionDetails("2", e.getMessage());
    }

    @ExceptionHandler({NotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ExceptionDetails handleNotFoundException(NotFoundException e) {
        LOGGER.error(e.getMessage(), e);
        return new ExceptionDetails("3", e.getMessage());
    }

    @ExceptionHandler({Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ExceptionDetails handleAnyException(Exception e) {
        final String id = UUID.randomUUID().toString();
        LOGGER.error(id, e);
        return new ExceptionDetails("4", "An error occurred:" + id);
    }
}