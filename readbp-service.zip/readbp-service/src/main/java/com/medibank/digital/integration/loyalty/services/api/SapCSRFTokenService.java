package com.medibank.digital.integration.loyalty.services.api;

import org.springframework.http.ResponseEntity;

/**
 * SAP CSRF Token Service
 * <p>
 * As it stands all SAP endponts will be required to provide
 * the CSRF token (currently used for authentication).
 * 
 * @author 920477
 *
 */
public interface SapCSRFTokenService {

	/**
	 * Gets the CSRF Token from the SAP endpoint.
	 * 
	 * @return ResponseEntity<String> String contains the XSRF Token
	 */
	public ResponseEntity<String> requestToken();
}
