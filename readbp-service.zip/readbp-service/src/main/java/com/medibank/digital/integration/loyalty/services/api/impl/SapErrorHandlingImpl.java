package com.medibank.digital.integration.loyalty.services.api.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.medibank.digital.integration.loyalty.model.DigitalError;
import com.medibank.digital.integration.loyalty.services.api.SapErrorHandling;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;

@Service
public class SapErrorHandlingImpl implements SapErrorHandling {
    private static final Logger LOGGER = LoggerFactory.getLogger(SapReadBPServiceImpl.class);

    @Override
    public ResponseEntity<?> handleErrorResponse(RestClientResponseException error, HttpStatus statusCode){
        ObjectMapper mapper = new ObjectMapper();
        DigitalError errorObj = new DigitalError();
        try {
            JsonNode actualObj = mapper.readTree(error.getResponseBodyAsString());
            errorObj.errorCode(actualObj.get("error").get("code").asText())
                    .errorDescription(actualObj.get("error").get("message").get("value").asText());
        } catch (Exception ex) {
            errorObj.setErrorDescription("Unknown Error.");
        }
        LOGGER.debug("Error Response Object: " + errorObj.toString());
        return new ResponseEntity<>(errorObj, statusCode);
    }
}
