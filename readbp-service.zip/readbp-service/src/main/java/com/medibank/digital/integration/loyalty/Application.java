package com.medibank.digital.integration.loyalty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * Medibank Loyalty API
 * <p>
 * Really just acting as a proxy for the SAP gateway endpoints, as
 * it stands all endpoints and models/payloads etc have the same
 * exact design as the SAP gateway.
 * <p>
 * This could of all been done via API Gateway HTTP Integration and mapping
 * templates, but there's a requirement to use Spring Cache (Redis) for some
 * functions later.
 * 
 * @author 920477
 *
 */
@SpringBootApplication
@ComponentScan({"com.medibank.digital.integration.loyalty"})
@EnableAutoConfiguration(exclude = {
	    org.springframework.boot.autoconfigure.security.SecurityAutoConfiguration.class,
	    org.springframework.boot.actuate.autoconfigure.ManagementWebSecurityAutoConfiguration.class
})
@EnableAspectJAutoProxy(proxyTargetClass=true)
public class Application {
	
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}