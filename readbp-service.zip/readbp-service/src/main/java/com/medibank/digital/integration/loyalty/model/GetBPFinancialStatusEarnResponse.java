package com.medibank.digital.integration.loyalty.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;

@ApiModel(description = "Get BP Financial Status Earn Response object")
public class GetBPFinancialStatusEarnResponse {
    @JsonProperty("BPID")
    private String bpId = null;

    @JsonProperty("BaseHWEarnIndicator")
    private Boolean baseHWEarnIndicator;

    @JsonProperty("PartnerEarnIndicator")
    private Boolean partnerEarnIndicator;

    @JsonProperty("HICAPSEarnIndicator")
    private Boolean hicapsEarnIndicator;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class GetBPFinancialStatusEarnResponse {\n");
        sb.append("    BPID: ").append(toIndentedString(getBpId())).append("\n");
        sb.append("    BaseHWEarnIndicator: ").append(toIndentedString(getBaseHWEarnIndicator())).append("\n");
        sb.append("    PartnerEarnIndicator: ").append(toIndentedString(getPartnerEarnIndicator())).append("\n");
        sb.append("    HICAPSEarnIndicator: ").append(toIndentedString(getHicapsEarnIndicator())).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    public String getBpId() {
        return bpId;
    }

    public void setBpId(String bpId) {
        this.bpId = bpId;
    }

    public Boolean getBaseHWEarnIndicator() {
        return baseHWEarnIndicator;
    }

    public void setBaseHWEarnIndicator(Boolean baseHWEarnIndicator) {
        this.baseHWEarnIndicator = baseHWEarnIndicator;
    }

    public Boolean getPartnerEarnIndicator() {
        return partnerEarnIndicator;
    }

    public void setPartnerEarnIndicator(Boolean partnerEarnIndicator) {
        this.partnerEarnIndicator = partnerEarnIndicator;
    }

    @JsonProperty("HICAPSEarnIndicator")
    public Boolean getHicapsEarnIndicator() {
        return hicapsEarnIndicator;
    }

    public void setHicapsEarnIndicator(Boolean hicapsEarnIndicator) {
        this.hicapsEarnIndicator = hicapsEarnIndicator;
    }
}
