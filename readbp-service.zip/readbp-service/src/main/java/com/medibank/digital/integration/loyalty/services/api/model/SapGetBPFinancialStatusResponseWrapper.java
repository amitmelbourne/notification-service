package com.medibank.digital.integration.loyalty.services.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.Valid;
import java.util.Objects;

public class SapGetBPFinancialStatusResponseWrapper {
    @JsonProperty("d")
    private SapGetBPFinancialStatusResponse d = null;

    public SapGetBPFinancialStatusResponseWrapper d(SapGetBPFinancialStatusResponse d) {
        this.d = d;
        return this;
    }

    /**
     * Get d
     * @return d
     **/
    @ApiModelProperty(value = "")

    @Valid

    public SapGetBPFinancialStatusResponse getD() {
        return d;
    }

    public void setD(SapGetBPFinancialStatusResponse d) {
        this.d = d;
    }


    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SapGetBPFinancialStatusResponseWrapper sapFinStatusWrapper = (SapGetBPFinancialStatusResponseWrapper) o;
        return Objects.equals(this.d, sapFinStatusWrapper.d);
    }

    @Override
    public int hashCode() {
        return Objects.hash(d);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class SapGetBPFinancialStatusResponseWrapper {\n");

        sb.append("    d: ").append(toIndentedString(d)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
