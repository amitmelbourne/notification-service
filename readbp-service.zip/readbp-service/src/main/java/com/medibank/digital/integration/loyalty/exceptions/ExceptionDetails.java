package com.medibank.digital.integration.loyalty.exceptions;


import javax.xml.bind.annotation.XmlRootElement;

/**
 * The custom exception class
 *
 * @author jlu
 *
 */
@XmlRootElement
public class ExceptionDetails {
    // error code
    private String errorCode;
    // error message
    private String description;

    private String stackTrace;

    public ExceptionDetails() {}

    public ExceptionDetails(String code, String desc) {
        this.errorCode = code;
        this.description = desc;
        this.stackTrace = null;
    }

    public ExceptionDetails(String code, String desc, String stackTrace) {
        this.errorCode = code;
        this.description = desc;
        this.stackTrace = stackTrace;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getStackTrace() {
        return stackTrace;
    }

    public void setStackTrace(String stackTrace) {
        this.stackTrace = stackTrace;
    }

    public String toString() {
        return "code=" + errorCode + ", description=" + description + ", stack trace=" + stackTrace;
    }
}
