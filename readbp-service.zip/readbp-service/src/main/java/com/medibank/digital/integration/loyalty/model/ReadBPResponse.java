package com.medibank.digital.integration.loyalty.model;

import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.medibank.digital.integration.loyalty.services.api.model.HWUser;
import com.medibank.digital.integration.loyalty.services.api.model.Telephone;
import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;

/**
 * ReadBP Response object
 */
@ApiModel(description = "ReadBP Response object")
@Validated
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReadBPResponse {
    @JsonProperty("EmailURI")
    private String email = null;

    @JsonProperty("BirthDate")
    private String birthDate = null;

    @JsonProperty("FamilyName")
    private String familyName = null;

    @JsonProperty("GivenName")
    private String givenName = null;

    @JsonProperty("Telephone")
    private Telephone telephone = null;

    @JsonProperty("ID")
    private String ID = null;

    @JsonProperty("HWUser")
    private HWUser hwUser;

    @JsonProperty("UserRegisteredIndicator")
    private String userRegisteredIndicator;

    @JsonProperty("PolicyAssignedIndicator")
    private String policyAssignedIndicator;

    @JsonProperty("ChangeStateId")
    private String changeStateId;


    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ReadBPResponse saPreadbpRequest = (ReadBPResponse) o;
        return
            Objects.equals(this.getEmail(), saPreadbpRequest.getEmail()) &&
            Objects.equals(this.getGivenName(), saPreadbpRequest.getGivenName()) &&
            Objects.equals(this.getFamilyName(), saPreadbpRequest.getFamilyName()) &&
            Objects.equals(this.getBirthDate(), saPreadbpRequest.getBirthDate()) &&
            Objects.equals(this.getHWUser(), saPreadbpRequest.getHWUser()) &&
            Objects.equals(this.getTelephone(), saPreadbpRequest.getTelephone()) &&
            Objects.equals(this.getID(), saPreadbpRequest.getID()) &&
            Objects.equals(this.getPolicyAssignedIndicator(), saPreadbpRequest.getPolicyAssignedIndicator()) &&
            Objects.equals(this.getUserRegisteredIndicator(), saPreadbpRequest.getUserRegisteredIndicator()) &&
            Objects.equals(this.getChangeStateId(), saPreadbpRequest.getChangeStateId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getEmail(), getTelephone(), getFamilyName(), getGivenName(), getHWUser(), getBirthDate(), getID(), getPolicyAssignedIndicator(), getUserRegisteredIndicator(), getChangeStateId());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class ReadBPResponse {\n");
        sb.append("    email: ").append(toIndentedString(getEmail())).append("\n");
        sb.append("    givenName: ").append(toIndentedString(getGivenName())).append("\n");
        sb.append("    familyName: ").append(toIndentedString(getFamilyName())).append("\n");
        sb.append("    birthDate: ").append(toIndentedString(getBirthDate())).append("\n");
        sb.append("    telephone: ").append(toIndentedString(getTelephone())).append("\n");
        sb.append("    hwUser: ").append(toIndentedString(getHWUser())).append("\n");
        sb.append("    policyAssignedIndicator: ").append(toIndentedString(getPolicyAssignedIndicator())).append("\n");
        sb.append("    userRegisteredIndicator: ").append(toIndentedString(getUserRegisteredIndicator())).append("\n");
        sb.append("    changeStateId: ").append(toIndentedString(getChangeStateId())).append("\n");
        sb.append("    ID: ").append(toIndentedString(getID())).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public Telephone getTelephone() {
        return telephone;
    }

    public void setTelephone(Telephone telephone) {
        this.telephone = telephone;
    }

    @JsonProperty("ID")
    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    @JsonProperty("HWUser")
    public HWUser getHWUser() {
        return hwUser;
    }

    public void setHWUser(HWUser hwUser) {
        this.hwUser = hwUser;
    }

    public String getUserRegisteredIndicator() {
        return userRegisteredIndicator;
    }

    public void setUserRegisteredIndicator(String userRegisteredIndicator) {
        this.userRegisteredIndicator = userRegisteredIndicator;
    }

    public String getPolicyAssignedIndicator() {
        return policyAssignedIndicator;
    }

    public void setPolicyAssignedIndicator(String policyAssignedIndicator) {
        this.policyAssignedIndicator = policyAssignedIndicator;
    }

    public String getChangeStateId() {
        return changeStateId;
    }

    public void setChangeStateId(String changeStateId) {
        this.changeStateId = changeStateId;
    }
}

