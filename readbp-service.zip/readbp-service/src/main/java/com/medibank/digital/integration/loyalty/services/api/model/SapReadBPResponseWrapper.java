package com.medibank.digital.integration.loyalty.services.api.model;

import java.util.Objects;

import javax.validation.Valid;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "SAP ReadBP response object")
@Validated

public class SapReadBPResponseWrapper {
  @JsonProperty("d")
  private SapReadBPResponse d = null;

  public SapReadBPResponseWrapper d(SapReadBPResponse d) {
    this.d = d;
    return this;
  }

  /**
   * Get d
   * @return d
  **/
  @ApiModelProperty(value = "")

  @Valid

  public SapReadBPResponse getD() {
    return d;
  }

  public void setD(SapReadBPResponse d) {
    this.d = d;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SapReadBPResponseWrapper saPreadbpRequestWrapper = (SapReadBPResponseWrapper) o;
    return Objects.equals(this.d, saPreadbpRequestWrapper.d);
  }

  @Override
  public int hashCode() {
    return Objects.hash(d);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SAPreadbpResponseWrapper {\n");
    
    sb.append("    d: ").append(toIndentedString(d)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

