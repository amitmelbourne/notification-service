package com.medibank.digital.integration.loyalty.services.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;


@ApiModel(description = "SAP Telephone object")
public class Telephone {
    @JsonProperty("NumberText")
    private String numberText;


//    public String getNumberText() {
//        return numberText;
//    }
//
//    public void setNumberText(String numberText) {
//        this.numberText = numberText;
//    }

    public Telephone numberText(String numberText) {
        this.numberText = numberText;
        return this;
    }

    public Telephone countryCode(String countryCode) {
        this.countryCode = countryCode;
        return this;
    }

    @JsonProperty("CountryCode")
    private String countryCode;


//    public String getCountryCode() {
//        return countryCode;
//    }
//
//    public void setCountryCode(String countryCode) {
//        this.countryCode = countryCode;
//    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class Telephone {\n");

        sb.append("    NumberText: ").append(toIndentedString(numberText)).append("\n");
        sb.append("    CountryCode: ").append(toIndentedString(countryCode)).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
