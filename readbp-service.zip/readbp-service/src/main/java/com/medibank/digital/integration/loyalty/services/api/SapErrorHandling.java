package com.medibank.digital.integration.loyalty.services.api;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientResponseException;

public interface SapErrorHandling {
    ResponseEntity<?> handleErrorResponse(RestClientResponseException error, HttpStatus statusCode);
}
