package com.medibank.digital.integration.loyalty.config;

/**
 * Constants class.
 * 
 * @author 920477
 *
 */
public final class Constants {

    private Constants() {
    }

    public static final String BASE_URL = "api/loyalty";

    public static class V1 {
        private static final String VERSION = "/v1";

        public static class BusinessPartnerHW {
            public static final String BASE = BASE_URL + V1.VERSION + "/businessPartnerHW";

            public static final String BURN_INDICATOR = BASE + "/{bpid}/burnIndicator";
            public static final String EARN_INDICATOR = BASE + "/{bpid}/earnIndicator";
        }
    }
    
    public static final String X_CSRF_TOKEN_HEADER = "x-csrf-token";
}
