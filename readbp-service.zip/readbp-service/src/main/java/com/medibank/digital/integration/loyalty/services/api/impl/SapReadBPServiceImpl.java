package com.medibank.digital.integration.loyalty.services.api.impl;

import com.medibank.digital.integration.loyalty.config.LogExecutionTime;
import com.medibank.digital.integration.loyalty.services.api.SapErrorHandling;
import com.medibank.digital.integration.loyalty.services.api.SapReadBPService;
import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponseWrapper;
import com.medibank.digital.integration.loyalty.services.api.model.SapSearchBPResponseWrapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import java.net.URI;

/**
 * SAP Implementation of the Read and Search BP endpoints.
 * 
 * @author 920477
 *
 */
@Service
public class SapReadBPServiceImpl implements SapReadBPService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SapReadBPServiceImpl.class);
	
	@Value("${medibank.sap.readbp.uri}")
	private String readBpUri;

    @Value("${medibank.sap.searchbp.uri}")
    private String searchBpUri;

    @Autowired()
	@Qualifier("authRestTemplate")
	RestTemplate restTemplate;

    @Autowired
	SapErrorHandling sapErrorHandling;
	
	
	@Override
	@LogExecutionTime
	public ResponseEntity<?> readbp(String bpid, String requestId) {
		try {
			LOGGER.info("SAP ReadBP called: " + bpid);

			URI uri = new UriTemplate(readBpUri).expand(bpid);

			RequestEntity request = RequestEntity.get(uri)
					.accept(MediaType.APPLICATION_JSON)
					.header("RequestID", requestId)
					.build();

			ResponseEntity<SapReadBPResponseWrapper> response = restTemplate.exchange(request, SapReadBPResponseWrapper.class);

			LOGGER.info("SAP ReadBP response: " + response.toString());


			if (response.getStatusCode().is2xxSuccessful()) {
				return response;
			} else {
				return new ResponseEntity<SapReadBPResponseWrapper>(response.getStatusCode());
			}
		} catch(HttpClientErrorException clientEx) {
			LOGGER.error("HttpClientError SAP:: Get Policy Number :: {} ", clientEx.getResponseBodyAsString());
			return sapErrorHandling.handleErrorResponse(clientEx, clientEx.getStatusCode());

		} catch(HttpServerErrorException serverEx) {
			LOGGER.error("HttpServerError SAP:: Get Policy Number :: {} ", serverEx.getResponseBodyAsString());
			return sapErrorHandling.handleErrorResponse(serverEx, serverEx.getStatusCode());
		}
	}

	@Override
	@LogExecutionTime
	public ResponseEntity<?> searchbp(String email, String requestId) {
		try {
			LOGGER.info("SAP SearchBP called: " + email);

            URI uri = new UriTemplate(searchBpUri).expand(email);
            LOGGER.info(uri.toASCIIString());

            RequestEntity request = RequestEntity.get(uri)
                    .accept(MediaType.APPLICATION_JSON)
					.header("RequestID", requestId)
					.build();

            ResponseEntity<SapSearchBPResponseWrapper> response = restTemplate.exchange(request, SapSearchBPResponseWrapper.class);

            LOGGER.info("SAP SearchBP response: " + response.toString());

			if (response.getStatusCode().is2xxSuccessful()) {
				return response;
			} else {
				return new ResponseEntity<SapSearchBPResponseWrapper>(response.getStatusCode());
			}
		} catch(HttpClientErrorException clientEx) {
			LOGGER.error("HttpClientError SAP:: Get Policy Number :: {} ", clientEx.getResponseBodyAsString());
			return sapErrorHandling.handleErrorResponse(clientEx, clientEx.getStatusCode());

		} catch(
		HttpServerErrorException serverEx) {
			LOGGER.error("HttpServerError SAP:: Get Policy Number :: {} ", serverEx.getResponseBodyAsString());
			return sapErrorHandling.handleErrorResponse(serverEx, serverEx.getStatusCode());
		}
	}
}
