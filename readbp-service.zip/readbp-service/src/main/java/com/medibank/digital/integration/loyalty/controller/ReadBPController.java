package com.medibank.digital.integration.loyalty.controller;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import com.medibank.digital.integration.loyalty.model.ReadBPResponse;
import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponse;
import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponseWrapper;
import com.medibank.digital.integration.loyalty.services.api.model.SapSearchBPResponse;
import com.medibank.digital.integration.loyalty.services.api.model.SapSearchBPResponseWrapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collection;

/**
 * ReadBP Controller
 * <p>
 * Allow Business Partner details to be read and searched
 * 
 * @author 920967
 *
 */
public interface ReadBPController {

	/**
	 * Reads a specific BP based on BPID
	 * <P>
	 * If successful will return a status code of 200 and the response
	 * will contain the details of the BOP.
	 * 
	 * @param bpid
	 * 
	 * @return BusinessPartnerResponse ID not null, if post was successful
	 */
    ResponseEntity<?> readbp(Long bpid, String requestId);

	/**
	 * Searches for a Business Partner (BP) based on email address
	 * <P>
	 * If successful will return a status code of 200 and the response
	 * will contain the details of the BOP.
	 *
	 * @param email
	 *
	 * @return BusinessPartnerResponse ID not null, if post was successful
	 */
	ResponseEntity<?> searchbp(@RequestParam(value = "email") String email, String requestId);
}
