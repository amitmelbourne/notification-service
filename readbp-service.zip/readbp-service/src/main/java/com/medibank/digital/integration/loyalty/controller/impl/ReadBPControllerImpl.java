package com.medibank.digital.integration.loyalty.controller.impl;

import com.medibank.digital.integration.loyalty.config.Helper;
import com.medibank.digital.integration.loyalty.config.LogExecutionTime;
import com.medibank.digital.integration.loyalty.controller.ReadBPController;
import com.medibank.digital.integration.loyalty.model.DigitalError;
import com.medibank.digital.integration.loyalty.model.GetBPFinancialStatusBurnResponse;
import com.medibank.digital.integration.loyalty.model.ReadBPResponse;
import com.medibank.digital.integration.loyalty.services.api.SapReadBPService;
import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponse;
import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponseWrapper;
import com.medibank.digital.integration.loyalty.services.api.model.SapSearchBPResponse;
import com.medibank.digital.integration.loyalty.services.api.model.SapSearchBPResponseWrapper;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.medibank.digital.integration.loyalty.config.Constants;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

/**
 * Read/Search BP Controller.
 * <p>
 *
 * 
 * @author 920967
 *
 */
@RestController

public class ReadBPControllerImpl implements ReadBPController {

	private final static Logger LOGGER = LoggerFactory.getLogger(ReadBPControllerImpl.class);
	
	/**
	 * We'll basically just proxy/pass though to this service to handle the request.
	 */
	@Autowired
	private SapReadBPService sapReadBPService;


	@Override
    @ApiOperation(value = "Reads a Business Partner by ID")
    @RequestMapping(method = {RequestMethod.GET, RequestMethod.OPTIONS},
            produces = APPLICATION_JSON_VALUE, path = Constants.V1.BusinessPartnerHW.BASE, params = "bpid")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = ReadBPResponse.class),
            @ApiResponse(code = 400, message = "Failure on bad request", response = DigitalError.class)}
    )
    @LogExecutionTime
    public ResponseEntity<?> readbp(@RequestParam(value = "bpid") Long bpid,
                                    @RequestHeader(value = "RequestID", required = false) String requestId) {
		try {
			LOGGER.info("ReadBP called: with bpid " + bpid);

			if(!Helper.isValid(requestId)){
                requestId = Helper.get32BitUUID();
            } else if(requestId.length() > 32){
                requestId = Helper.trimRequestId(requestId);
            }

            LOGGER.info("ReadBP RequestID : {} " , requestId);

			ResponseEntity<?> sapResponse = sapReadBPService.readbp(bpid.toString(), requestId);

			if(sapResponse.getStatusCode().is2xxSuccessful()) {
                SapReadBPResponseWrapper sapResBody = (SapReadBPResponseWrapper) sapResponse.getBody();
                ReadBPResponse response = new ReadBPResponse();
                BeanUtils.copyProperties(response, sapResBody.getD());
//            response.setChangeStateId(sapResponse.getBody().getD().getMetadata().getETag());
                response.setChangeStateId(sapResBody.getD().getETag());
                LOGGER.info("Response" + response.toString());
                return new ResponseEntity<>(response, sapResponse.getStatusCode());
            }

            return sapResponse;

		} catch(Exception ex) {
			LOGGER.error("Error whilst handling read BP.", ex);
			
			return new ResponseEntity<ReadBPResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

    @Override
    @ApiOperation(value = "Searches a Business Partner by email address")
    @RequestMapping(method = {RequestMethod.GET, RequestMethod.OPTIONS},
            produces = APPLICATION_JSON_VALUE,
            path = Constants.V1.BusinessPartnerHW.BASE,
            params = "email")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", responseContainer = "List", response = ReadBPResponse.class),
            @ApiResponse(code = 400, message = "Failure on bad request", response = DigitalError.class)}
    )
    @LogExecutionTime
    public ResponseEntity<?> searchbp(@RequestParam(value = "email") String email,
                                      @RequestHeader(value = "RequestID", required = false) String requestId) {
        try {
            LOGGER.info("ReadBP called: with email: " + email);

            if(!Helper.isValid(requestId)){
                requestId = Helper.get32BitUUID();
            } else if(requestId.length() > 32){
                requestId = Helper.trimRequestId(requestId);
            }

            LOGGER.info("SearchBP RequestID : {} " , requestId);

            ResponseEntity<?> sapResponse = sapReadBPService.searchbp(email, requestId);
//            SapSearchBPResponseWrapper
            if(sapResponse.getStatusCode().is2xxSuccessful()) {
                SapSearchBPResponseWrapper sapResBody = (SapSearchBPResponseWrapper) sapResponse.getBody();
                List<ReadBPResponse> readBPResponses= new ArrayList<>();

                for (SapReadBPResponse source: sapResBody.getD().getResults() ) {
                    ReadBPResponse target = new ReadBPResponse();
                    BeanUtils.copyProperties(target , source);
//                target.setChangeStateId(source.getMetadata().getETag());
                    target.setChangeStateId(source.getETag());
                    LOGGER.info("Response" + target.toString());
                    readBPResponses.add(target);
                }
                return new ResponseEntity<Collection<ReadBPResponse>>(readBPResponses, sapResponse.getStatusCode());
            }

            return sapResponse;

        } catch(Exception ex) {
            LOGGER.error("Error whilst handling search BP.", ex);

            return new ResponseEntity<Collection<ReadBPResponse>>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
