package com.medibank.digital.integration.loyalty.services.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;

import javax.validation.Valid;
import java.util.Objects;

/**
 * SAP Get Financial Status response object
 */
@ApiModel(description = "SAP Get Financial Status Response object")
@Validated
public class SapGetBPFinancialStatusResponse {
    @JsonProperty("__metadata")
    private SapMetadata metadata = null;

    @JsonProperty("ID")
    private String ID = null;

    @JsonProperty("BaseHWEarnIndicator")
    private String baseHWEarnIndicator = null;

    @JsonProperty("PartnerEarnIndicator")
    private String partnerEarnIndicator = null;

    @JsonProperty("HICAPSEarnIndicator")
    private String hicapsEarnIndicator = null;


    @JsonProperty("BurnIndicator")
    private String burnIndicator = null;

    public SapGetBPFinancialStatusResponse metadata(SapMetadata metadata) {
        this.metadata = metadata;
        return this;
    }

    /**
     * Get metadata
     * @return metadata
     **/
    @ApiModelProperty(value = "")
    @Valid
    public SapMetadata getMetadata() {
        return metadata;
    }

    public void setMetadata(SapMetadata metadata) {
        this.metadata = metadata;
    }

    @Override
    public boolean equals(java.lang.Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SapGetBPFinancialStatusResponse sapGetBPFinancialStatusResponse = (SapGetBPFinancialStatusResponse) o;
        return
                Objects.equals(this.metadata, sapGetBPFinancialStatusResponse.metadata) &&
                        Objects.equals(this.getID(), sapGetBPFinancialStatusResponse.getID()) &&
                        Objects.equals(this.getBaseHWEarnIndicator(), sapGetBPFinancialStatusResponse.getBaseHWEarnIndicator()) &&
                        Objects.equals(this.getPartnerEarnIndicator(), sapGetBPFinancialStatusResponse.getPartnerEarnIndicator()) &&
                        Objects.equals(this.getHicapsEarnIndicator(), sapGetBPFinancialStatusResponse.getHicapsEarnIndicator()) &&
                        Objects.equals(this.getBurnIndicator(), sapGetBPFinancialStatusResponse.getBurnIndicator());
    }

    @Override
    public int hashCode() {
        return Objects.hash(metadata, getID(), getBaseHWEarnIndicator(), getPartnerEarnIndicator(), getHicapsEarnIndicator(), getBurnIndicator());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class SapReadBPResponse {\n");
        sb.append("    metadata: ").append(toIndentedString(metadata)).append("\n");
        sb.append("    ID: ").append(toIndentedString(getID())).append("\n");
        sb.append("    BaseHWEarnIndicator: ").append(toIndentedString(getBaseHWEarnIndicator())).append("\n");
        sb.append("    PartnerEarnIndicator: ").append(toIndentedString(getPartnerEarnIndicator())).append("\n");
        sb.append("    HicapsEarnIndicator: ").append(toIndentedString(getHicapsEarnIndicator())).append("\n");
        sb.append("    BurnIndicator: ").append(toIndentedString(getBurnIndicator())).append("\n");
        sb.append("}");
        return sb.toString();
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(java.lang.Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }


    //@JsonProperty("ID")
    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getBaseHWEarnIndicator() {
        return baseHWEarnIndicator;
    }

    public void setBaseHWEarnIndicator(String baseHWEarnIndicator) {
        this.baseHWEarnIndicator = baseHWEarnIndicator;
    }

    public String getPartnerEarnIndicator() {
        return partnerEarnIndicator;
    }

    public void setPartnerEarnIndicator(String partnerEarnIndicator) {
        this.partnerEarnIndicator = partnerEarnIndicator;
    }

    public String getBurnIndicator() {
        return burnIndicator;
    }

    public void setBurnIndicator(String burnIndicator) {
        this.burnIndicator = burnIndicator;
    }

    @JsonProperty("HICAPSEarnIndicator")
    public String getHicapsEarnIndicator() {
        return hicapsEarnIndicator;
    }

    public void setHicapsEarnIndicator(String hicapsEarnIndicator) {
        this.hicapsEarnIndicator = hicapsEarnIndicator;
    }
}
