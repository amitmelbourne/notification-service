package com.medibank.digital.integration.loyalty.config;

import org.apache.http.HttpException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.protocol.HttpContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.medibank.digital.integration.loyalty.interceptor.CSRFTokenInterceptor;

import javax.net.ssl.SSLContext;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

/**
 * Config for RestTemplate beans.
 * <p>
 * All SAP calls are presumed to require basic auth (current not
 * implemented across all SAP endpoints) and CSRF Token.
 * 
 * @author 920477
 *
 */
@Configuration
public class RestTemplateConfig {

	@Value("${medibank.sap.csrf.username}")
	private String username;
	
	@Value("${medibank.sap.csrf.password}")
	private String password;

	@Value("${medibank.proxy.host}")
	private String proxy;

    @Value("${checkCertificates}")
    private boolean checkCertificates;

    @Value("${useProxy}")
    private boolean useProxy;

	private HttpComponentsClientHttpRequestFactory getProxy()  {
		HttpHost proxyHost = HttpHost.create(proxy);
        HttpClientBuilder builder = HttpClientBuilder.create();
        if (useProxy) {

            builder.setRoutePlanner(new DefaultProxyRoutePlanner(proxyHost) {

                @Override
                public HttpHost determineProxy(HttpHost target,
                                               HttpRequest request, HttpContext context)
                        throws HttpException {
                    return proxyHost;
                }

            }).setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE);
        }

        if (!checkCertificates) {
            TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

            SSLContext sslContext = null;
            try {
                sslContext = org.apache.http.ssl.SSLContexts.custom()
                        .loadTrustMaterial(null, acceptingTrustStrategy)
                        .build();
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            } catch (KeyManagementException e) {
                e.printStackTrace();
            } catch (KeyStoreException e) {
                e.printStackTrace();
            }

            SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
            builder = builder.setSSLSocketFactory(csf);
        }

        HttpClient httpClient = builder.build();

        return new HttpComponentsClientHttpRequestFactory(httpClient);
	}
	/**
	 * RestTemplate with Basic Auth already set.
	 * <p>
	 * Confluence design specs indicate that this is required for all calls,
	 * however its currently not implemented/enforced in SAP as calls will work
	 * without it.
	 * 
	 * @param builder RestTemplateBuilder
	 * 
	 * @return RestTemplate with Basic Auth added.
	 */
	@Bean(name = "authRestTemplate")
	public RestTemplate authRestTemplate(RestTemplateBuilder builder) {
		return builder
			//.setReadTimeout(5000)
			.requestFactory(getProxy()).basicAuthorization(username, password).build();
	}
	
	/**
	 * RestTemplate with Basic Auth and the CSRF Token interceptor configured.
	 * <p>
	 * All calls to SAP, except for the CSRF Token Request, require the CSRF token
	 * to be within the header.
	 * 
	 * @param builder RestTemplateBuilder
	 * 
	 * @return RestTemplate with Basic Auth and CSRF Interceptor.
	 */
	@Bean(name = "authAndTokenRestTemplate")
	@Primary
	public RestTemplate authAndTokenrestTemplate(RestTemplateBuilder builder) {
		return builder.requestFactory(getProxy()).basicAuthorization(username, password).additionalInterceptors(csrfTokenInterceptor()).build();
	}
	
	@Bean
	public CSRFTokenInterceptor csrfTokenInterceptor() {
		return new CSRFTokenInterceptor();
	}
}
