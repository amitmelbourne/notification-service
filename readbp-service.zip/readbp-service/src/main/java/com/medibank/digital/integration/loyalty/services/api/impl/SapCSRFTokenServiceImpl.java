package com.medibank.digital.integration.loyalty.services.api.impl;

import java.util.Collections;

import com.medibank.digital.integration.loyalty.config.LogExecutionTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.medibank.digital.integration.loyalty.config.Constants;
import com.medibank.digital.integration.loyalty.services.api.SapCSRFTokenService;

/**
 * Implementation of the SAP CSRF Token Service call.
 * <p>
 * The CSRF Token and cookies must be included in any call to SAP.
 * <p>
 * See https://confluence.aws.medibank.local/pages/viewpage.action?spaceKey=LD&title=SAP+Gateway+-+Authentication+Method
 * 
 * @author 920477
 *
 */
@Service
public class SapCSRFTokenServiceImpl implements SapCSRFTokenService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SapCSRFTokenServiceImpl.class);
	
	@Value("${medibank.sap.csrf.uri}")
	private String uri;

	@Autowired
	@Qualifier("authRestTemplate")
	private RestTemplate restTemplate;
	
	
	@Override
	@LogExecutionTime
	public ResponseEntity<String> requestToken() {
		try { 
			LOGGER.info("Requesting CSRF Token...");
			
			ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.GET, getHttpEntityWithHeaders(), String.class);
			
			LOGGER.info("CSRF Token response: " + response.toString());
			
			return response;
		} catch(Throwable ex) {
			LOGGER.error("Error whilst fetching CSRF Token.", ex);
			
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/**
	 * Returns the HttpEntity with headers configured as required, in this
	 * case simply Accept.
	 * 
	 * @return HttpEntity configured HttpEntity
	 */
	private HttpEntity<String> getHttpEntityWithHeaders() {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
		httpHeaders.add(Constants.X_CSRF_TOKEN_HEADER, "Fetch");
		
		return new HttpEntity<String>(httpHeaders);
	}
}
