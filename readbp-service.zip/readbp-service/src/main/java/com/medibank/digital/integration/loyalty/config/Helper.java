package com.medibank.digital.integration.loyalty.config;

import com.medibank.digital.integration.common.utils.UUIDGenerator;

import java.util.Collection;

public class Helper {

    public static <E> boolean isValid(E item) {

        if (item == null)
            return false;

        if (item instanceof Character)
            return !("".equals(item.toString()));

        if (item instanceof String)
            return !("".equals(item));

        if (item instanceof Integer || item instanceof Float || item instanceof Long || item instanceof Double)
            return true;

        if (item instanceof Collection)
            return !(((Collection<?>) item).isEmpty());

        //TODO Add additional Data types for checking
        return false;
    }

    public static String get32BitUUID(){
        return UUIDGenerator.getGuid().replaceAll("-","");
    }

    public static String trimRequestId(String requestId) {
        if(requestId.replaceAll("-","").length() <= 32){
            return requestId.replaceAll("-","");
        }

        return requestId.substring(0,32);
    }
}
