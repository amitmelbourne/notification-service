package com.medibank.digital.integration.loyalty.util;

import java.util.Collections;

import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponseWrapper;
import org.springframework.http.HttpHeaders;

import com.medibank.digital.integration.loyalty.config.Constants;
import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponse;

/**
 * Holds some helper methods for testing i.e creating mock onjects etc.
 * 
 * @author 920477
 *
 */
public class TestHelper {

	public final static String TEST_SAP_RESPONSE_ID = "11111";
	
	public final static String TEST_CSRF_TOKEN = "abwr8392==";

	
	/**
	 * Creates a SapReadBPResponseWrapper, with ID set to the default test ID.
	 * 
	 * @return SapReadBPResponseWrapper with ID field set.
	 */
	public static SapReadBPResponseWrapper getTestSapReadBPResponseWrapper() {
		SapReadBPResponseWrapper sapResponse = new SapReadBPResponseWrapper();
		sapResponse.setD(new SapReadBPResponse());
		sapResponse.getD().setID(TEST_SAP_RESPONSE_ID);
		
		return sapResponse;
	}
	
	/**
	 * Returns a HttpHeaders with the CSRF Token and cookies set.
	 * 
	 * @return HttpHeaders
	 */
	public static HttpHeaders getTestHeaderWithCSRFToken() {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add(Constants.X_CSRF_TOKEN_HEADER, TEST_CSRF_TOKEN);
		httpHeaders.add(HttpHeaders.SET_COOKIE, "sap-usercontext=sap-client=130; path=/");
		httpHeaders.add(HttpHeaders.SET_COOKIE, "SAP_SESSIONID_MGD_130=sqZr-yETh4ZuPxeNkU2m0IRMsrZCnxHogcUCSfna-go%3d; path=/");
				
		return httpHeaders;
	}
}
