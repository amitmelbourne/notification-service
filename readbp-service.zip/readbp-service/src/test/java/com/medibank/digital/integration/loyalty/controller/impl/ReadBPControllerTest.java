package com.medibank.digital.integration.loyalty.controller.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * Unit Tests for the ReadBPControllerImpl class.
 * 
 * @author 920477
 *
 */
@Ignore
@RunWith(MockitoJUnitRunner.class)
public class ReadBPControllerTest {

//	@InjectMocks
//	private ReadBPControllerImpl interactionController;
//
//	@Mock
//	private SapReadBPService sapreadbpService;

	
//	/**
//	 * Tests a successful response,
//	 */
//	@Test
//	public void interactionSuccess() {
//		SapReadBPResponseWrapper sapResponse = TestHelper.getTestSapReadBPResponseWrapper();
//
//		ResponseEntity<SapReadBPResponseWrapper> mockedResponse = new ResponseEntity<>(sapResponse, HttpStatus.CREATED);
//		Mockito.when(sapreadbpService.readbp(Matchers.any())).thenReturn(mockedResponse);
//
//		ResponseEntity<BusinessPartnerResponse> response = interactionController.interaction(TestHelper.getTestInteractionRequest());
//
//		assertNotNull(response);
//		assertEquals(TestHelper.TEST_SAP_RESPONSE_ID, response.getBody().getID());
//		assertEquals(HttpStatus.CREATED, response.getStatusCode());
//	}
//
//	/**
//	 * At the moment we are still returning the wrapped ResponseEntity from the SAP Services,
//	 * this probably should change, but for now it will allow is to return the actual response
//	 * code from the SAP server.
//	 */
//	@Test
//	public void sapServerErrorCodeReturnedOnError() {
//		ResponseEntity<SapReadBPResponseWrapper> mockedResponse = new ResponseEntity<>(HttpStatus.FORBIDDEN);
//		Mockito.when(sapreadbpService.readbp(Matchers.any())).thenReturn(mockedResponse);
//
//		ResponseEntity<BusinessPartnerResponse> response = interactionController.interaction(new ReadBPRequest());
//
//		assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
//	}
//
//	/**
//	 * If an exception is thrown, then we expect in most cases, to handle it and
//	 * return a 500 Internal Server Error.
//	 */
//	@SuppressWarnings("unchecked")
//	@Test
//	public void testExceptionHandled() {
//		Mockito.when(sapreadbpService.readbp(Matchers.any())).thenThrow(TimeoutException.class);
//
//		ResponseEntity<BusinessPartnerResponse> response = interactionController.interaction(TestHelper.getTestInteractionRequest());
//
//		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
//	}
}
