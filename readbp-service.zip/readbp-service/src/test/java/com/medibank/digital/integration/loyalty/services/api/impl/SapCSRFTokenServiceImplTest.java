package com.medibank.digital.integration.loyalty.services.api.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeoutException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.medibank.digital.integration.loyalty.config.Constants;
import com.medibank.digital.integration.loyalty.util.TestHelper;

/**
 * 
 * @author 920477
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class SapCSRFTokenServiceImplTest {

	@InjectMocks
	private SapCSRFTokenServiceImpl sapCSRFTokenServiceImpl;
	
	@Mock
	private RestTemplate restTemplate;

	
	@Test
	public void validResponse() {
		ResponseEntity<String> mockedResponse = new ResponseEntity<String>(TestHelper.getTestHeaderWithCSRFToken(), HttpStatus.OK);
		
		Mockito.when(restTemplate.exchange(Matchers.anyString(), 
										  Matchers.eq(HttpMethod.GET), 
										  Matchers.<HttpEntity<String>>any(), 
										  Matchers.<Class<String>>any())).thenReturn(mockedResponse);

		ResponseEntity<String> response = sapCSRFTokenServiceImpl.requestToken();
		
		assertNotNull(response);
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertTrue(response.getHeaders().containsKey(Constants.X_CSRF_TOKEN_HEADER));
		assertEquals(TestHelper.TEST_CSRF_TOKEN, response.getHeaders().get(Constants.X_CSRF_TOKEN_HEADER).get(0));
	}
	
	@Test
	public void errorResponse() {
		ResponseEntity<String> mockedResponse = new ResponseEntity<String>(new HttpHeaders(), HttpStatus.FORBIDDEN);
		
		Mockito.when(restTemplate.exchange(Matchers.anyString(), 
				  Matchers.eq(HttpMethod.GET), 
				  Matchers.<HttpEntity<String>>any(), 
				  Matchers.<Class<String>>any())).thenReturn(mockedResponse);
		
		ResponseEntity<String> response = sapCSRFTokenServiceImpl.requestToken();
		
		assertNotNull(response);
		assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
		assertFalse(response.getHeaders().containsKey(Constants.X_CSRF_TOKEN_HEADER));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void exceptionHandled() {
		Mockito.when(restTemplate.exchange(Matchers.anyString(), 
				  Matchers.eq(HttpMethod.GET), 
				  Matchers.<HttpEntity<String>>any(), 
				  Matchers.<Class<String>>any())).thenThrow(TimeoutException.class);
		
		ResponseEntity<String> response = sapCSRFTokenServiceImpl.requestToken();
		
		assertNotNull(response);
		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}	
}
