package com.medibank.digital.integration.loyalty.interceptor;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.net.URI;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.SimpleClientHttpRequestFactory;

import com.medibank.digital.integration.loyalty.config.Constants;
import com.medibank.digital.integration.loyalty.services.api.SapCSRFTokenService;
import com.medibank.digital.integration.loyalty.util.TestHelper;

/**
 * 
 * @author 920477
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class CSRFTokenInterceptorTest {

	@Mock
	private SapCSRFTokenService csrfService;
	
	@InjectMocks
	private CSRFTokenInterceptor csrfTokenInterceptor;
	
	private final static String TEST_URI = "http://localhost/test";


	@Test
	public void succesfullyAddTokenToHeader() throws Throwable {
		ResponseEntity<String> mockedResponse = new ResponseEntity<String>(TestHelper.getTestHeaderWithCSRFToken(), HttpStatus.OK);
		
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
	    ClientHttpRequest request = requestFactory.createRequest(new URI(TEST_URI), HttpMethod.GET);
	    
		Mockito.when(csrfService.requestToken()).thenReturn(mockedResponse);
		ClientHttpRequestExecution execution = Mockito.mock(ClientHttpRequestExecution.class);
		
		csrfTokenInterceptor.intercept(request, new byte[0], execution);
		
		assertTrue(request.getHeaders().containsKey(Constants.X_CSRF_TOKEN_HEADER));
		assertEquals(TestHelper.TEST_CSRF_TOKEN, request.getHeaders().get(Constants.X_CSRF_TOKEN_HEADER).get(0));
	}
	
	@Test
	public void failsToAddTokenToHeader() throws Throwable {
		ResponseEntity<String> mockedResponse = new ResponseEntity<String>(HttpStatus.FORBIDDEN);
		
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
	    ClientHttpRequest request = requestFactory.createRequest(new URI(TEST_URI), HttpMethod.GET);
	    
		Mockito.when(csrfService.requestToken()).thenReturn(mockedResponse);
		ClientHttpRequestExecution execution = Mockito.mock(ClientHttpRequestExecution.class);
		
		csrfTokenInterceptor.intercept(request, new byte[0], execution);
		
		assertFalse(request.getHeaders().containsKey(Constants.X_CSRF_TOKEN_HEADER));
	}
}
