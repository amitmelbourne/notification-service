package com.medibank.digital.integration.loyalty.services.api.impl;

import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponseWrapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.medibank.digital.integration.loyalty.util.TestHelper;

import junit.framework.TestCase;

/**
 * Test cases for the SapreadbpServiceImpl class.
 * 
 * @author 920477
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class SapReadBPServiceImplTest extends TestCase {

	@InjectMocks
	private SapReadBPServiceImpl sapReadBPServiceImpl;
	
	@Mock
	private RestTemplate restTemplate;

	
	@Test
	public void validRequest() {
		ResponseEntity<SapReadBPResponseWrapper> mockedResponse = new ResponseEntity<SapReadBPResponseWrapper>(TestHelper.getTestSapReadBPResponseWrapper(), HttpStatus.CREATED);
		
//		Mockito.when(restTemplate.exchange(Matchers.anyString(),
//										  Matchers.eq(HttpMethod.POST),
//										  Matchers.<HttpEntity<SapreadbpRequestWrapper>>any(),
//										  Matchers.<Class<SapReadBPResponseWrapper>>any())).thenReturn(mockedResponse);

//		ResponseEntity<SapReadBPResponseWrapper> response = sapreadbpServiceImpl.readbp(TestHelper.getTestInteractionRequest());
//
//		assertNotNull(response);
//		assertEquals(HttpStatus.CREATED, response.getStatusCode());
//		assertEquals(TestHelper.TEST_SAP_RESPONSE_ID, response.getBody().getD().getID());
	}
	
	
	@Test
	public void exceptionThrown() {
//		Mockito.when(restTemplate.exchange(Matchers.anyString(),
//										  Matchers.eq(HttpMethod.POST),
//										  Matchers.<HttpEntity<SapreadbpRequestWrapper>>any(),
//										  Matchers.<Class<SapReadBPResponseWrapper>>any())).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));

//		ResponseEntity<SapReadBPResponseWrapper> response = sapreadbpServiceImpl.readbp(TestHelper.getTestInteractionRequest());
		
//		assertNotNull(response);
//		assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
	}
}
