package com.medibank.digital.integration.loyalty.controller.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.medibank.digital.integration.loyalty.Application;
import com.medibank.digital.integration.loyalty.services.api.model.SapReadBPResponseWrapper;
import com.medibank.digital.integration.loyalty.util.TestHelper;

/**
 * Tests for the ReadBPControllerImpl class.
 * 
 * @author 920477
 *
 */
@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, classes = Application.class)
public class ReadBPControllerIT {

	@InjectMocks
	private ReadBPControllerImpl controller;
	
	@LocalServerPort
	private int port;
	
	@Autowired
	private TestRestTemplate testRestTemplate;
	
	@MockBean(name="authAndTokenRestTemplate")
	private RestTemplate restTemplate;
	
	@MockBean(name="authRestTemplate")
	private RestTemplate restTemplate2;
	
	@Test
	public void testreadbpSuccessfull() {
		SapReadBPResponseWrapper mockedResponse = TestHelper.getTestSapReadBPResponseWrapper();
		
		// this is the CSRF Token Request
		Mockito.when(restTemplate.exchange(
						Matchers.anyString(),
						Matchers.eq(HttpMethod.GET),
						Matchers.<HttpEntity<String>>any(),
						Matchers.<Class<String>>any())).thenReturn(new ResponseEntity<String>(TestHelper.getTestHeaderWithCSRFToken(), HttpStatus.OK));
		
//		// SAP Create Interaction Request
//		Mockito.when(restTemplate.exchange(Matchers.anyString(),
//										  Matchers.eq(HttpMethod.POST),
//										  Matchers.<HttpEntity<SapreadbpRequestWrapper>>any(),
//										  Matchers.<Class<SapReadBPResponseWrapper>>any())).thenReturn(new ResponseEntity<SapReadBPResponseWrapper>(mockedResponse, HttpStatus.CREATED));
//
		
//		ResponseEntity<BusinessPartnerResponse> response =
//				testRestTemplate.postForEntity("http://localhost:" + port + Constants.V1.Interactions.BASE,
//											  TestHelper.getTestInteractionRequest(),
//											  BusinessPartnerResponse.class);
//
//		assertNotNull(response);
//		assertEquals(HttpStatus.CREATED, response.getStatusCode());
	}
	
	/**
	 * At the moment we are still returning the wrapped ResponseEntity from the SAP Services,
	 * this probably should change, but for now it will allow is to return the actual response
	 * code from the SAP server.
	 */
	@Test
	public void testSapServerErrorCodeReturnedOnError() {
		
		// this is the CSRF Token Request
		Mockito.when(restTemplate.exchange(
						Matchers.anyString(),
						Matchers.eq(HttpMethod.GET),
						Matchers.<HttpEntity<String>>any(),
						Matchers.<Class<String>>any())).thenReturn(new ResponseEntity<String>(TestHelper.getTestHeaderWithCSRFToken(), HttpStatus.OK));
		
//		// SAP Create Interaction Request
//		Mockito.when(restTemplate.exchange(Matchers.anyString(),
//										  Matchers.eq(HttpMethod.POST),
//										  Matchers.<HttpEntity<SapreadbpRequestWrapper>>any(),
//										  Matchers.<Class<SapreadbpRequestWrapper>>any())).thenReturn(new ResponseEntity<SapreadbpRequestWrapper>(HttpStatus.FORBIDDEN));
//
		
//		ResponseEntity<BusinessPartnerResponse> response =
//				testRestTemplate.postForEntity("http://localhost:" + port + Constants.V1.Interactions.BASE,
//											  TestHelper.getTestInteractionRequest(),
//											  BusinessPartnerResponse.class);
//
//		assertNotNull(response);
//		assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
	}
	
	/**
	 * If an exception is thrown, then we expect in most cases, to handle it and
	 * return a 500 Internal Server Error.
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testExceptionHandled() {
		// this is the CSRF Token Request
		Mockito.when(restTemplate.exchange(
						Matchers.anyString(),
						Matchers.eq(HttpMethod.GET),
						Matchers.<HttpEntity<String>>any(),
						Matchers.<Class<String>>any())).thenReturn(new ResponseEntity<String>(TestHelper.getTestHeaderWithCSRFToken(), HttpStatus.OK));
		
		// SAP Create Interaction Request
//		Mockito.when(restTemplate.exchange(Matchers.anyString(),
//										  Matchers.eq(HttpMethod.POST),
//										  Matchers.<HttpEntity<SapreadbpRequestWrapper>>any(),
//										  Matchers.<Class<SapreadbpRequestWrapper>>any())).thenThrow(TimeoutException.class);
//
		
//		ResponseEntity<BusinessPartnerResponse> response =
//				testRestTemplate.postForEntity("http://localhost:" + port + Constants.V1.Interactions.BASE,
//											  TestHelper.getTestInteractionRequest(),
//											  BusinessPartnerResponse.class);
//
//		assertNotNull(response);
//		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
	}
}
